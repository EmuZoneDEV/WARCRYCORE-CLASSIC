﻿

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen
Imports System.Reflection
Imports System.Resources
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("NamCore Studio")>
<Assembly: AssemblyDescription("NamCore Studio")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("NamCore Studio")>
<Assembly: AssemblyCopyright("Copyright © 2016 megasus")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(True)>

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("abdcf441-3448-404f-b465-988469a7b1a3")>

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.1.10.46398")>
<Assembly: AssemblyFileVersion("0.1.10.46398")>

<Assembly: NeutralResourcesLanguage("en-US")>