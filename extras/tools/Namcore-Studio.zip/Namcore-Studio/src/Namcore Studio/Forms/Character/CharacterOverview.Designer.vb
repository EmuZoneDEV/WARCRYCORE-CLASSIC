﻿Imports NamCore_Studio.Modules.Interface
Imports NamCore_Studio.Forms.Extension

Namespace Forms.Character
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class CharacterOverview
        Inherits EventTrigger

        'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub

        'Wird vom Windows Form-Designer benötigt.
        Private components As System.ComponentModel.IContainer

        'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
        'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
        'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Me.components = New System.ComponentModel.Container()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CharacterOverview))
            Me.InventoryPanel = New System.Windows.Forms.Panel()
            Me.slot_17_enchant = New System.Windows.Forms.Label()
            Me.slot_17_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_17_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_17_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_17_color = New System.Windows.Forms.Panel()
            Me.slot_17_pic = New System.Windows.Forms.PictureBox()
            Me.slot_17_name = New System.Windows.Forms.Label()
            Me.slot_15_enchant = New System.Windows.Forms.Label()
            Me.slot_15_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_15_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_15_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_15_color = New System.Windows.Forms.Panel()
            Me.slot_15_pic = New System.Windows.Forms.PictureBox()
            Me.slot_15_name = New System.Windows.Forms.Label()
            Me.slot_16_enchant = New System.Windows.Forms.Label()
            Me.slot_16_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_16_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_16_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_16_color = New System.Windows.Forms.Panel()
            Me.slot_16_pic = New System.Windows.Forms.PictureBox()
            Me.slot_16_name = New System.Windows.Forms.Label()
            Me.slot_13_enchant = New System.Windows.Forms.Label()
            Me.slot_13_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_13_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_13_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_13_color = New System.Windows.Forms.Panel()
            Me.slot_13_pic = New System.Windows.Forms.PictureBox()
            Me.slot_13_name = New System.Windows.Forms.Label()
            Me.slot_12_enchant = New System.Windows.Forms.Label()
            Me.slot_12_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_12_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_12_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_12_color = New System.Windows.Forms.Panel()
            Me.slot_12_pic = New System.Windows.Forms.PictureBox()
            Me.slot_12_name = New System.Windows.Forms.Label()
            Me.slot_11_enchant = New System.Windows.Forms.Label()
            Me.slot_11_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_11_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_11_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_11_color = New System.Windows.Forms.Panel()
            Me.slot_11_pic = New System.Windows.Forms.PictureBox()
            Me.slot_11_name = New System.Windows.Forms.Label()
            Me.slot_10_enchant = New System.Windows.Forms.Label()
            Me.slot_10_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_10_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_10_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_10_color = New System.Windows.Forms.Panel()
            Me.slot_10_pic = New System.Windows.Forms.PictureBox()
            Me.slot_10_name = New System.Windows.Forms.Label()
            Me.slot_7_enchant = New System.Windows.Forms.Label()
            Me.slot_7_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_7_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_7_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_7_color = New System.Windows.Forms.Panel()
            Me.slot_7_pic = New System.Windows.Forms.PictureBox()
            Me.slot_7_name = New System.Windows.Forms.Label()
            Me.slot_6_enchant = New System.Windows.Forms.Label()
            Me.slot_6_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_6_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_6_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_6_color = New System.Windows.Forms.Panel()
            Me.slot_6_pic = New System.Windows.Forms.PictureBox()
            Me.slot_6_name = New System.Windows.Forms.Label()
            Me.slot_5_enchant = New System.Windows.Forms.Label()
            Me.slot_5_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_5_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_5_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_5_color = New System.Windows.Forms.Panel()
            Me.slot_5_pic = New System.Windows.Forms.PictureBox()
            Me.slot_5_name = New System.Windows.Forms.Label()
            Me.slot_9_enchant = New System.Windows.Forms.Label()
            Me.slot_9_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_9_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_9_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_9_color = New System.Windows.Forms.Panel()
            Me.slot_9_pic = New System.Windows.Forms.PictureBox()
            Me.slot_9_name = New System.Windows.Forms.Label()
            Me.slot_8_enchant = New System.Windows.Forms.Label()
            Me.slot_8_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_8_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_8_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_8_color = New System.Windows.Forms.Panel()
            Me.slot_8_pic = New System.Windows.Forms.PictureBox()
            Me.slot_8_name = New System.Windows.Forms.Label()
            Me.slot_18_enchant = New System.Windows.Forms.Label()
            Me.slot_18_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_18_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_18_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_18_color = New System.Windows.Forms.Panel()
            Me.slot_18_pic = New System.Windows.Forms.PictureBox()
            Me.slot_18_name = New System.Windows.Forms.Label()
            Me.slot_3_enchant = New System.Windows.Forms.Label()
            Me.slot_3_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_3_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_3_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_3_color = New System.Windows.Forms.Panel()
            Me.slot_3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_3_name = New System.Windows.Forms.Label()
            Me.slot_4_enchant = New System.Windows.Forms.Label()
            Me.slot_4_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_4_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_4_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_4_color = New System.Windows.Forms.Panel()
            Me.slot_4_pic = New System.Windows.Forms.PictureBox()
            Me.slot_4_name = New System.Windows.Forms.Label()
            Me.slot_14_enchant = New System.Windows.Forms.Label()
            Me.slot_14_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_14_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_14_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_14_color = New System.Windows.Forms.Panel()
            Me.slot_14_pic = New System.Windows.Forms.PictureBox()
            Me.slot_14_name = New System.Windows.Forms.Label()
            Me.slot_2_enchant = New System.Windows.Forms.Label()
            Me.slot_2_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_2_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_2_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_2_color = New System.Windows.Forms.Panel()
            Me.slot_2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_2_name = New System.Windows.Forms.Label()
            Me.slot_1_enchant = New System.Windows.Forms.Label()
            Me.slot_1_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_1_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_1_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_1_color = New System.Windows.Forms.Panel()
            Me.slot_1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_1_name = New System.Windows.Forms.Label()
            Me.slot_0_enchant = New System.Windows.Forms.Label()
            Me.slot_0_gem3_pic = New System.Windows.Forms.PictureBox()
            Me.slot_0_gem2_pic = New System.Windows.Forms.PictureBox()
            Me.slot_0_gem1_pic = New System.Windows.Forms.PictureBox()
            Me.slot_0_color = New System.Windows.Forms.Panel()
            Me.slot_0_pic = New System.Windows.Forms.PictureBox()
            Me.slot_0_name = New System.Windows.Forms.Label()
            Me.charname_lbl = New System.Windows.Forms.Label()
            Me.Label2 = New System.Windows.Forms.Label()
            Me.Label3 = New System.Windows.Forms.Label()
            Me.Label4 = New System.Windows.Forms.Label()
            Me.level_lbl = New System.Windows.Forms.Label()
            Me.race_lbl = New System.Windows.Forms.Label()
            Me.class_lbl = New System.Windows.Forms.Label()
            Me.av_bt = New System.Windows.Forms.Button()
            Me.Glyphs_bt = New System.Windows.Forms.Button()
            Me.rep_bt = New System.Windows.Forms.Button()
            Me.spellsskills_bt = New System.Windows.Forms.Button()
            Me.exit_bt = New System.Windows.Forms.Button()
            Me.savechanges_bt = New System.Windows.Forms.Button()
            Me.reset_bt = New System.Windows.Forms.Button()
            Me.changepanel = New System.Windows.Forms.Panel()
            Me.PictureBox2 = New System.Windows.Forms.PictureBox()
            Me.PictureBox1 = New System.Windows.Forms.PictureBox()
            Me.TextBox1 = New System.Windows.Forms.TextBox()
            Me.racepanel = New System.Windows.Forms.Panel()
            Me.racecombo = New System.Windows.Forms.ComboBox()
            Me.racerefresh = New System.Windows.Forms.PictureBox()
            Me.classpanel = New System.Windows.Forms.Panel()
            Me.classcombo = New System.Windows.Forms.ComboBox()
            Me.classrefresh = New System.Windows.Forms.PictureBox()
            Me.selectenchpanel = New System.Windows.Forms.Panel()
            Me.spellench = New System.Windows.Forms.Label()
            Me.itmench = New System.Windows.Forms.Label()
            Me.Label1 = New System.Windows.Forms.Label()
            Me.bank_bt = New System.Windows.Forms.Button()
            Me.bag2Panel = New NamCore_Studio.Modules.[Interface].ItemPanel()
            Me.bag2Pic = New System.Windows.Forms.PictureBox()
            Me.bag1Panel = New NamCore_Studio.Modules.[Interface].ItemPanel()
            Me.bag1Pic = New System.Windows.Forms.PictureBox()
            Me.bag4Panel = New NamCore_Studio.Modules.[Interface].ItemPanel()
            Me.PictureBox3 = New System.Windows.Forms.PictureBox()
            Me.bag4Pic = New System.Windows.Forms.PictureBox()
            Me.bag3Panel = New NamCore_Studio.Modules.[Interface].ItemPanel()
            Me.bag3Pic = New System.Windows.Forms.PictureBox()
            Me.bag5Panel = New NamCore_Studio.Modules.[Interface].ItemPanel()
            Me.bag5Pic = New System.Windows.Forms.PictureBox()
            Me.addpanel = New System.Windows.Forms.Panel()
            Me.PictureBox4 = New System.Windows.Forms.PictureBox()
            Me.TextBox2 = New System.Windows.Forms.TextBox()
            Me.Quests_bt = New System.Windows.Forms.Button()
            Me.GroupBox1 = New System.Windows.Forms.GroupBox()
            Me.Label6 = New System.Windows.Forms.Label()
            Me.gender_lbl = New System.Windows.Forms.Label()
            Me.GroupBox2 = New System.Windows.Forms.GroupBox()
            Me.InventoryLayout = New System.Windows.Forms.FlowLayoutPanel()
            Me.Label5 = New System.Windows.Forms.Label()
            Me.InfoToolTip = New System.Windows.Forms.ToolTip(Me.components)
            Me.genderpanel = New System.Windows.Forms.Panel()
            Me.genderrefresh = New System.Windows.Forms.PictureBox()
            Me.gendercombo = New System.Windows.Forms.ComboBox()
            Me.referenceItmPanel = New System.Windows.Forms.Panel()
            Me.referenceCount = New System.Windows.Forms.Label()
            Me.removeinventbox = New System.Windows.Forms.PictureBox()
            Me.referenceItmPic = New System.Windows.Forms.PictureBox()
            Me.professions_bt = New System.Windows.Forms.Button()
            Me.loadedat_lbl = New System.Windows.Forms.Label()
            Me.refreshchar = New System.Windows.Forms.PictureBox()
            Me.Label7 = New System.Windows.Forms.Label()
            Me.gold_txtbox = New System.Windows.Forms.TextBox()
            Me.refreshgold = New System.Windows.Forms.PictureBox()
            Me.InventoryPanel.SuspendLayout()
            CType(Me.slot_17_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_17_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_17_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_17_color.SuspendLayout()
            CType(Me.slot_17_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_15_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_15_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_15_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_15_color.SuspendLayout()
            CType(Me.slot_15_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_16_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_16_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_16_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_16_color.SuspendLayout()
            CType(Me.slot_16_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_13_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_13_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_13_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_13_color.SuspendLayout()
            CType(Me.slot_13_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_12_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_12_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_12_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_12_color.SuspendLayout()
            CType(Me.slot_12_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_11_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_11_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_11_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_11_color.SuspendLayout()
            CType(Me.slot_11_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_10_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_10_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_10_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_10_color.SuspendLayout()
            CType(Me.slot_10_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_7_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_7_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_7_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_7_color.SuspendLayout()
            CType(Me.slot_7_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_6_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_6_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_6_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_6_color.SuspendLayout()
            CType(Me.slot_6_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_5_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_5_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_5_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_5_color.SuspendLayout()
            CType(Me.slot_5_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_9_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_9_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_9_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_9_color.SuspendLayout()
            CType(Me.slot_9_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_8_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_8_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_8_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_8_color.SuspendLayout()
            CType(Me.slot_8_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_18_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_18_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_18_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_18_color.SuspendLayout()
            CType(Me.slot_18_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_3_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_3_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_3_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_3_color.SuspendLayout()
            CType(Me.slot_3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_4_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_4_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_4_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_4_color.SuspendLayout()
            CType(Me.slot_4_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_14_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_14_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_14_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_14_color.SuspendLayout()
            CType(Me.slot_14_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_2_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_2_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_2_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_2_color.SuspendLayout()
            CType(Me.slot_2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_1_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_1_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_1_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_1_color.SuspendLayout()
            CType(Me.slot_1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_0_gem3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_0_gem2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.slot_0_gem1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.slot_0_color.SuspendLayout()
            CType(Me.slot_0_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.changepanel.SuspendLayout()
            CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.racepanel.SuspendLayout()
            CType(Me.racerefresh, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.classpanel.SuspendLayout()
            CType(Me.classrefresh, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.selectenchpanel.SuspendLayout()
            Me.bag2Panel.SuspendLayout()
            CType(Me.bag2Pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.bag1Panel.SuspendLayout()
            CType(Me.bag1Pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.bag4Panel.SuspendLayout()
            CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.bag4Pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.bag3Panel.SuspendLayout()
            CType(Me.bag3Pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.bag5Panel.SuspendLayout()
            CType(Me.bag5Pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.addpanel.SuspendLayout()
            CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.GroupBox1.SuspendLayout()
            Me.GroupBox2.SuspendLayout()
            Me.genderpanel.SuspendLayout()
            CType(Me.genderrefresh, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.referenceItmPanel.SuspendLayout()
            CType(Me.removeinventbox, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.referenceItmPic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.refreshchar, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.refreshgold, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'InventoryPanel
            '
            Me.InventoryPanel.BackColor = System.Drawing.Color.Transparent
            Me.InventoryPanel.BackgroundImage = Global.NamCore_Studio.My.Resources.Resources.armor_bg
            Me.InventoryPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.InventoryPanel.Controls.Add(Me.slot_17_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_17_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_17_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_17_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_17_color)
            Me.InventoryPanel.Controls.Add(Me.slot_17_name)
            Me.InventoryPanel.Controls.Add(Me.slot_15_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_15_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_15_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_15_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_15_color)
            Me.InventoryPanel.Controls.Add(Me.slot_15_name)
            Me.InventoryPanel.Controls.Add(Me.slot_16_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_16_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_16_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_16_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_16_color)
            Me.InventoryPanel.Controls.Add(Me.slot_16_name)
            Me.InventoryPanel.Controls.Add(Me.slot_13_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_13_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_13_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_13_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_13_color)
            Me.InventoryPanel.Controls.Add(Me.slot_13_name)
            Me.InventoryPanel.Controls.Add(Me.slot_12_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_12_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_12_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_12_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_12_color)
            Me.InventoryPanel.Controls.Add(Me.slot_12_name)
            Me.InventoryPanel.Controls.Add(Me.slot_11_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_11_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_11_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_11_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_11_color)
            Me.InventoryPanel.Controls.Add(Me.slot_11_name)
            Me.InventoryPanel.Controls.Add(Me.slot_10_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_10_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_10_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_10_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_10_color)
            Me.InventoryPanel.Controls.Add(Me.slot_10_name)
            Me.InventoryPanel.Controls.Add(Me.slot_7_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_7_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_7_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_7_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_7_color)
            Me.InventoryPanel.Controls.Add(Me.slot_7_name)
            Me.InventoryPanel.Controls.Add(Me.slot_6_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_6_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_6_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_6_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_6_color)
            Me.InventoryPanel.Controls.Add(Me.slot_6_name)
            Me.InventoryPanel.Controls.Add(Me.slot_5_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_5_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_5_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_5_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_5_color)
            Me.InventoryPanel.Controls.Add(Me.slot_5_name)
            Me.InventoryPanel.Controls.Add(Me.slot_9_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_9_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_9_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_9_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_9_color)
            Me.InventoryPanel.Controls.Add(Me.slot_9_name)
            Me.InventoryPanel.Controls.Add(Me.slot_8_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_8_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_8_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_8_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_8_color)
            Me.InventoryPanel.Controls.Add(Me.slot_8_name)
            Me.InventoryPanel.Controls.Add(Me.slot_18_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_18_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_18_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_18_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_18_color)
            Me.InventoryPanel.Controls.Add(Me.slot_18_name)
            Me.InventoryPanel.Controls.Add(Me.slot_3_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_3_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_3_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_3_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_3_color)
            Me.InventoryPanel.Controls.Add(Me.slot_3_name)
            Me.InventoryPanel.Controls.Add(Me.slot_4_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_4_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_4_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_4_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_4_color)
            Me.InventoryPanel.Controls.Add(Me.slot_4_name)
            Me.InventoryPanel.Controls.Add(Me.slot_14_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_14_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_14_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_14_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_14_color)
            Me.InventoryPanel.Controls.Add(Me.slot_14_name)
            Me.InventoryPanel.Controls.Add(Me.slot_2_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_2_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_2_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_2_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_2_color)
            Me.InventoryPanel.Controls.Add(Me.slot_2_name)
            Me.InventoryPanel.Controls.Add(Me.slot_1_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_1_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_1_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_1_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_1_color)
            Me.InventoryPanel.Controls.Add(Me.slot_1_name)
            Me.InventoryPanel.Controls.Add(Me.slot_0_enchant)
            Me.InventoryPanel.Controls.Add(Me.slot_0_gem3_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_0_gem2_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_0_gem1_pic)
            Me.InventoryPanel.Controls.Add(Me.slot_0_color)
            Me.InventoryPanel.Controls.Add(Me.slot_0_name)
            Me.InventoryPanel.ForeColor = System.Drawing.Color.Black
            Me.InventoryPanel.Location = New System.Drawing.Point(12, 84)
            Me.InventoryPanel.Name = "InventoryPanel"
            Me.InventoryPanel.Size = New System.Drawing.Size(536, 602)
            Me.InventoryPanel.TabIndex = 0
            '
            'slot_17_enchant
            '
            Me.slot_17_enchant.AutoSize = True
            Me.slot_17_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_17_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_17_enchant.Location = New System.Drawing.Point(447, 551)
            Me.slot_17_enchant.Name = "slot_17_enchant"
            Me.slot_17_enchant.Size = New System.Drawing.Size(66, 13)
            Me.slot_17_enchant.TabIndex = 114
            Me.slot_17_enchant.Text = "Itemenchant"
            '
            'slot_17_gem3_pic
            '
            Me.slot_17_gem3_pic.Location = New System.Drawing.Point(495, 569)
            Me.slot_17_gem3_pic.Name = "slot_17_gem3_pic"
            Me.slot_17_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_17_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_17_gem3_pic.TabIndex = 113
            Me.slot_17_gem3_pic.TabStop = False
            '
            'slot_17_gem2_pic
            '
            Me.slot_17_gem2_pic.Location = New System.Drawing.Point(471, 569)
            Me.slot_17_gem2_pic.Name = "slot_17_gem2_pic"
            Me.slot_17_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_17_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_17_gem2_pic.TabIndex = 112
            Me.slot_17_gem2_pic.TabStop = False
            '
            'slot_17_gem1_pic
            '
            Me.slot_17_gem1_pic.Location = New System.Drawing.Point(447, 569)
            Me.slot_17_gem1_pic.Name = "slot_17_gem1_pic"
            Me.slot_17_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_17_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_17_gem1_pic.TabIndex = 111
            Me.slot_17_gem1_pic.TabStop = False
            '
            'slot_17_color
            '
            Me.slot_17_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_17_color.Controls.Add(Me.slot_17_pic)
            Me.slot_17_color.Location = New System.Drawing.Point(379, 530)
            Me.slot_17_color.Name = "slot_17_color"
            Me.slot_17_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_17_color.TabIndex = 110
            '
            'slot_17_pic
            '
            Me.slot_17_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_17_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_17_pic.Name = "slot_17_pic"
            Me.slot_17_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_17_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_17_pic.TabIndex = 0
            Me.slot_17_pic.TabStop = False
            '
            'slot_17_name
            '
            Me.slot_17_name.AutoSize = True
            Me.slot_17_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_17_name.Location = New System.Drawing.Point(447, 533)
            Me.slot_17_name.Name = "slot_17_name"
            Me.slot_17_name.Size = New System.Drawing.Size(71, 15)
            Me.slot_17_name.TabIndex = 109
            Me.slot_17_name.Text = "Itemname"
            '
            'slot_15_enchant
            '
            Me.slot_15_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_15_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_15_enchant.Location = New System.Drawing.Point(9, 551)
            Me.slot_15_enchant.Name = "slot_15_enchant"
            Me.slot_15_enchant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_15_enchant.Size = New System.Drawing.Size(130, 13)
            Me.slot_15_enchant.TabIndex = 108
            Me.slot_15_enchant.Text = "Itemenchant"
            Me.slot_15_enchant.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_15_gem1_pic
            '
            Me.slot_15_gem1_pic.Location = New System.Drawing.Point(121, 569)
            Me.slot_15_gem1_pic.Name = "slot_15_gem1_pic"
            Me.slot_15_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_15_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_15_gem1_pic.TabIndex = 107
            Me.slot_15_gem1_pic.TabStop = False
            '
            'slot_15_gem2_pic
            '
            Me.slot_15_gem2_pic.Location = New System.Drawing.Point(97, 569)
            Me.slot_15_gem2_pic.Name = "slot_15_gem2_pic"
            Me.slot_15_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_15_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_15_gem2_pic.TabIndex = 106
            Me.slot_15_gem2_pic.TabStop = False
            '
            'slot_15_gem3_pic
            '
            Me.slot_15_gem3_pic.Location = New System.Drawing.Point(73, 569)
            Me.slot_15_gem3_pic.Name = "slot_15_gem3_pic"
            Me.slot_15_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_15_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_15_gem3_pic.TabIndex = 105
            Me.slot_15_gem3_pic.TabStop = False
            '
            'slot_15_color
            '
            Me.slot_15_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_15_color.Controls.Add(Me.slot_15_pic)
            Me.slot_15_color.Location = New System.Drawing.Point(150, 530)
            Me.slot_15_color.Name = "slot_15_color"
            Me.slot_15_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_15_color.TabIndex = 104
            '
            'slot_15_pic
            '
            Me.slot_15_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_15_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_15_pic.Name = "slot_15_pic"
            Me.slot_15_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_15_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_15_pic.TabIndex = 0
            Me.slot_15_pic.TabStop = False
            '
            'slot_15_name
            '
            Me.slot_15_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_15_name.Location = New System.Drawing.Point(6, 533)
            Me.slot_15_name.Name = "slot_15_name"
            Me.slot_15_name.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_15_name.Size = New System.Drawing.Size(138, 15)
            Me.slot_15_name.TabIndex = 103
            Me.slot_15_name.Text = "Itemname"
            Me.slot_15_name.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_16_enchant
            '
            Me.slot_16_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_16_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_16_enchant.Location = New System.Drawing.Point(286, 551)
            Me.slot_16_enchant.Name = "slot_16_enchant"
            Me.slot_16_enchant.Size = New System.Drawing.Size(90, 13)
            Me.slot_16_enchant.TabIndex = 102
            Me.slot_16_enchant.Text = "Itemenchant"
            '
            'slot_16_gem3_pic
            '
            Me.slot_16_gem3_pic.Location = New System.Drawing.Point(334, 569)
            Me.slot_16_gem3_pic.Name = "slot_16_gem3_pic"
            Me.slot_16_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_16_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_16_gem3_pic.TabIndex = 101
            Me.slot_16_gem3_pic.TabStop = False
            '
            'slot_16_gem2_pic
            '
            Me.slot_16_gem2_pic.Location = New System.Drawing.Point(310, 569)
            Me.slot_16_gem2_pic.Name = "slot_16_gem2_pic"
            Me.slot_16_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_16_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_16_gem2_pic.TabIndex = 100
            Me.slot_16_gem2_pic.TabStop = False
            '
            'slot_16_gem1_pic
            '
            Me.slot_16_gem1_pic.Location = New System.Drawing.Point(286, 569)
            Me.slot_16_gem1_pic.Name = "slot_16_gem1_pic"
            Me.slot_16_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_16_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_16_gem1_pic.TabIndex = 99
            Me.slot_16_gem1_pic.TabStop = False
            '
            'slot_16_color
            '
            Me.slot_16_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_16_color.Controls.Add(Me.slot_16_pic)
            Me.slot_16_color.Location = New System.Drawing.Point(218, 530)
            Me.slot_16_color.Name = "slot_16_color"
            Me.slot_16_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_16_color.TabIndex = 98
            '
            'slot_16_pic
            '
            Me.slot_16_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_16_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_16_pic.Name = "slot_16_pic"
            Me.slot_16_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_16_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_16_pic.TabIndex = 0
            Me.slot_16_pic.TabStop = False
            '
            'slot_16_name
            '
            Me.slot_16_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_16_name.Location = New System.Drawing.Point(286, 533)
            Me.slot_16_name.Name = "slot_16_name"
            Me.slot_16_name.Size = New System.Drawing.Size(90, 15)
            Me.slot_16_name.TabIndex = 97
            Me.slot_16_name.Text = "Itemname"
            '
            'slot_13_enchant
            '
            Me.slot_13_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_13_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_13_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_13_enchant.Location = New System.Drawing.Point(279, 481)
            Me.slot_13_enchant.Name = "slot_13_enchant"
            Me.slot_13_enchant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_13_enchant.Size = New System.Drawing.Size(179, 13)
            Me.slot_13_enchant.TabIndex = 96
            Me.slot_13_enchant.Text = "Itemenchant"
            Me.slot_13_enchant.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_13_gem1_pic
            '
            Me.slot_13_gem1_pic.Location = New System.Drawing.Point(440, 499)
            Me.slot_13_gem1_pic.Name = "slot_13_gem1_pic"
            Me.slot_13_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_13_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_13_gem1_pic.TabIndex = 95
            Me.slot_13_gem1_pic.TabStop = False
            '
            'slot_13_gem2_pic
            '
            Me.slot_13_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_13_gem2_pic.Location = New System.Drawing.Point(416, 499)
            Me.slot_13_gem2_pic.Name = "slot_13_gem2_pic"
            Me.slot_13_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_13_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_13_gem2_pic.TabIndex = 94
            Me.slot_13_gem2_pic.TabStop = False
            '
            'slot_13_gem3_pic
            '
            Me.slot_13_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_13_gem3_pic.Location = New System.Drawing.Point(392, 499)
            Me.slot_13_gem3_pic.Name = "slot_13_gem3_pic"
            Me.slot_13_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_13_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_13_gem3_pic.TabIndex = 93
            Me.slot_13_gem3_pic.TabStop = False
            '
            'slot_13_color
            '
            Me.slot_13_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_13_color.Controls.Add(Me.slot_13_pic)
            Me.slot_13_color.Location = New System.Drawing.Point(469, 460)
            Me.slot_13_color.Name = "slot_13_color"
            Me.slot_13_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_13_color.TabIndex = 92
            '
            'slot_13_pic
            '
            Me.slot_13_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_13_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_13_pic.Name = "slot_13_pic"
            Me.slot_13_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_13_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_13_pic.TabIndex = 0
            Me.slot_13_pic.TabStop = False
            '
            'slot_13_name
            '
            Me.slot_13_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_13_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_13_name.Location = New System.Drawing.Point(279, 463)
            Me.slot_13_name.Name = "slot_13_name"
            Me.slot_13_name.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_13_name.Size = New System.Drawing.Size(184, 15)
            Me.slot_13_name.TabIndex = 91
            Me.slot_13_name.Text = "Itemname"
            Me.slot_13_name.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_12_enchant
            '
            Me.slot_12_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_12_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_12_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_12_enchant.Location = New System.Drawing.Point(279, 416)
            Me.slot_12_enchant.Name = "slot_12_enchant"
            Me.slot_12_enchant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_12_enchant.Size = New System.Drawing.Size(179, 13)
            Me.slot_12_enchant.TabIndex = 90
            Me.slot_12_enchant.Text = "Itemenchant"
            Me.slot_12_enchant.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_12_gem1_pic
            '
            Me.slot_12_gem1_pic.Location = New System.Drawing.Point(440, 434)
            Me.slot_12_gem1_pic.Name = "slot_12_gem1_pic"
            Me.slot_12_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_12_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_12_gem1_pic.TabIndex = 89
            Me.slot_12_gem1_pic.TabStop = False
            '
            'slot_12_gem2_pic
            '
            Me.slot_12_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_12_gem2_pic.Location = New System.Drawing.Point(416, 434)
            Me.slot_12_gem2_pic.Name = "slot_12_gem2_pic"
            Me.slot_12_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_12_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_12_gem2_pic.TabIndex = 88
            Me.slot_12_gem2_pic.TabStop = False
            '
            'slot_12_gem3_pic
            '
            Me.slot_12_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_12_gem3_pic.Location = New System.Drawing.Point(392, 434)
            Me.slot_12_gem3_pic.Name = "slot_12_gem3_pic"
            Me.slot_12_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_12_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_12_gem3_pic.TabIndex = 87
            Me.slot_12_gem3_pic.TabStop = False
            '
            'slot_12_color
            '
            Me.slot_12_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_12_color.Controls.Add(Me.slot_12_pic)
            Me.slot_12_color.Location = New System.Drawing.Point(469, 395)
            Me.slot_12_color.Name = "slot_12_color"
            Me.slot_12_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_12_color.TabIndex = 86
            '
            'slot_12_pic
            '
            Me.slot_12_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_12_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_12_pic.Name = "slot_12_pic"
            Me.slot_12_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_12_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_12_pic.TabIndex = 0
            Me.slot_12_pic.TabStop = False
            '
            'slot_12_name
            '
            Me.slot_12_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_12_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_12_name.Location = New System.Drawing.Point(279, 398)
            Me.slot_12_name.Name = "slot_12_name"
            Me.slot_12_name.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_12_name.Size = New System.Drawing.Size(184, 15)
            Me.slot_12_name.TabIndex = 85
            Me.slot_12_name.Text = "Itemname"
            Me.slot_12_name.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_11_enchant
            '
            Me.slot_11_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_11_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_11_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_11_enchant.Location = New System.Drawing.Point(279, 351)
            Me.slot_11_enchant.Name = "slot_11_enchant"
            Me.slot_11_enchant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_11_enchant.Size = New System.Drawing.Size(179, 13)
            Me.slot_11_enchant.TabIndex = 84
            Me.slot_11_enchant.Text = "Itemenchant"
            Me.slot_11_enchant.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_11_gem1_pic
            '
            Me.slot_11_gem1_pic.Location = New System.Drawing.Point(440, 369)
            Me.slot_11_gem1_pic.Name = "slot_11_gem1_pic"
            Me.slot_11_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_11_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_11_gem1_pic.TabIndex = 83
            Me.slot_11_gem1_pic.TabStop = False
            '
            'slot_11_gem2_pic
            '
            Me.slot_11_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_11_gem2_pic.Location = New System.Drawing.Point(416, 369)
            Me.slot_11_gem2_pic.Name = "slot_11_gem2_pic"
            Me.slot_11_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_11_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_11_gem2_pic.TabIndex = 82
            Me.slot_11_gem2_pic.TabStop = False
            '
            'slot_11_gem3_pic
            '
            Me.slot_11_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_11_gem3_pic.Location = New System.Drawing.Point(392, 369)
            Me.slot_11_gem3_pic.Name = "slot_11_gem3_pic"
            Me.slot_11_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_11_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_11_gem3_pic.TabIndex = 81
            Me.slot_11_gem3_pic.TabStop = False
            '
            'slot_11_color
            '
            Me.slot_11_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_11_color.Controls.Add(Me.slot_11_pic)
            Me.slot_11_color.Location = New System.Drawing.Point(469, 330)
            Me.slot_11_color.Name = "slot_11_color"
            Me.slot_11_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_11_color.TabIndex = 80
            '
            'slot_11_pic
            '
            Me.slot_11_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_11_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_11_pic.Name = "slot_11_pic"
            Me.slot_11_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_11_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_11_pic.TabIndex = 0
            Me.slot_11_pic.TabStop = False
            '
            'slot_11_name
            '
            Me.slot_11_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_11_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_11_name.Location = New System.Drawing.Point(279, 333)
            Me.slot_11_name.Name = "slot_11_name"
            Me.slot_11_name.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_11_name.Size = New System.Drawing.Size(184, 15)
            Me.slot_11_name.TabIndex = 79
            Me.slot_11_name.Text = "Itemname"
            Me.slot_11_name.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_10_enchant
            '
            Me.slot_10_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_10_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_10_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_10_enchant.Location = New System.Drawing.Point(279, 286)
            Me.slot_10_enchant.Name = "slot_10_enchant"
            Me.slot_10_enchant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_10_enchant.Size = New System.Drawing.Size(179, 13)
            Me.slot_10_enchant.TabIndex = 78
            Me.slot_10_enchant.Text = "Itemenchant"
            Me.slot_10_enchant.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_10_gem1_pic
            '
            Me.slot_10_gem1_pic.Location = New System.Drawing.Point(440, 304)
            Me.slot_10_gem1_pic.Name = "slot_10_gem1_pic"
            Me.slot_10_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_10_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_10_gem1_pic.TabIndex = 77
            Me.slot_10_gem1_pic.TabStop = False
            '
            'slot_10_gem2_pic
            '
            Me.slot_10_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_10_gem2_pic.Location = New System.Drawing.Point(416, 304)
            Me.slot_10_gem2_pic.Name = "slot_10_gem2_pic"
            Me.slot_10_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_10_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_10_gem2_pic.TabIndex = 76
            Me.slot_10_gem2_pic.TabStop = False
            '
            'slot_10_gem3_pic
            '
            Me.slot_10_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_10_gem3_pic.Location = New System.Drawing.Point(392, 304)
            Me.slot_10_gem3_pic.Name = "slot_10_gem3_pic"
            Me.slot_10_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_10_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_10_gem3_pic.TabIndex = 75
            Me.slot_10_gem3_pic.TabStop = False
            '
            'slot_10_color
            '
            Me.slot_10_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_10_color.Controls.Add(Me.slot_10_pic)
            Me.slot_10_color.Location = New System.Drawing.Point(469, 265)
            Me.slot_10_color.Name = "slot_10_color"
            Me.slot_10_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_10_color.TabIndex = 74
            '
            'slot_10_pic
            '
            Me.slot_10_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_10_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_10_pic.Name = "slot_10_pic"
            Me.slot_10_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_10_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_10_pic.TabIndex = 0
            Me.slot_10_pic.TabStop = False
            '
            'slot_10_name
            '
            Me.slot_10_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_10_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_10_name.Location = New System.Drawing.Point(279, 268)
            Me.slot_10_name.Name = "slot_10_name"
            Me.slot_10_name.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_10_name.Size = New System.Drawing.Size(184, 15)
            Me.slot_10_name.TabIndex = 73
            Me.slot_10_name.Text = "Itemname"
            Me.slot_10_name.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_7_enchant
            '
            Me.slot_7_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_7_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_7_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_7_enchant.Location = New System.Drawing.Point(279, 221)
            Me.slot_7_enchant.Name = "slot_7_enchant"
            Me.slot_7_enchant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_7_enchant.Size = New System.Drawing.Size(179, 13)
            Me.slot_7_enchant.TabIndex = 72
            Me.slot_7_enchant.Text = "Itemenchant"
            Me.slot_7_enchant.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_7_gem1_pic
            '
            Me.slot_7_gem1_pic.Location = New System.Drawing.Point(440, 239)
            Me.slot_7_gem1_pic.Name = "slot_7_gem1_pic"
            Me.slot_7_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_7_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_7_gem1_pic.TabIndex = 71
            Me.slot_7_gem1_pic.TabStop = False
            '
            'slot_7_gem2_pic
            '
            Me.slot_7_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_7_gem2_pic.Location = New System.Drawing.Point(416, 239)
            Me.slot_7_gem2_pic.Name = "slot_7_gem2_pic"
            Me.slot_7_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_7_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_7_gem2_pic.TabIndex = 70
            Me.slot_7_gem2_pic.TabStop = False
            '
            'slot_7_gem3_pic
            '
            Me.slot_7_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_7_gem3_pic.Location = New System.Drawing.Point(392, 239)
            Me.slot_7_gem3_pic.Name = "slot_7_gem3_pic"
            Me.slot_7_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_7_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_7_gem3_pic.TabIndex = 69
            Me.slot_7_gem3_pic.TabStop = False
            '
            'slot_7_color
            '
            Me.slot_7_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_7_color.Controls.Add(Me.slot_7_pic)
            Me.slot_7_color.Location = New System.Drawing.Point(469, 200)
            Me.slot_7_color.Name = "slot_7_color"
            Me.slot_7_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_7_color.TabIndex = 68
            '
            'slot_7_pic
            '
            Me.slot_7_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_7_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_7_pic.Name = "slot_7_pic"
            Me.slot_7_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_7_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_7_pic.TabIndex = 0
            Me.slot_7_pic.TabStop = False
            '
            'slot_7_name
            '
            Me.slot_7_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_7_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_7_name.Location = New System.Drawing.Point(279, 203)
            Me.slot_7_name.Name = "slot_7_name"
            Me.slot_7_name.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_7_name.Size = New System.Drawing.Size(184, 15)
            Me.slot_7_name.TabIndex = 67
            Me.slot_7_name.Text = "Itemname"
            Me.slot_7_name.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_6_enchant
            '
            Me.slot_6_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_6_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_6_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_6_enchant.Location = New System.Drawing.Point(279, 156)
            Me.slot_6_enchant.Name = "slot_6_enchant"
            Me.slot_6_enchant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_6_enchant.Size = New System.Drawing.Size(179, 13)
            Me.slot_6_enchant.TabIndex = 66
            Me.slot_6_enchant.Text = "Itemenchant"
            Me.slot_6_enchant.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_6_gem1_pic
            '
            Me.slot_6_gem1_pic.Location = New System.Drawing.Point(440, 174)
            Me.slot_6_gem1_pic.Name = "slot_6_gem1_pic"
            Me.slot_6_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_6_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_6_gem1_pic.TabIndex = 65
            Me.slot_6_gem1_pic.TabStop = False
            '
            'slot_6_gem2_pic
            '
            Me.slot_6_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_6_gem2_pic.Location = New System.Drawing.Point(416, 174)
            Me.slot_6_gem2_pic.Name = "slot_6_gem2_pic"
            Me.slot_6_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_6_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_6_gem2_pic.TabIndex = 64
            Me.slot_6_gem2_pic.TabStop = False
            '
            'slot_6_gem3_pic
            '
            Me.slot_6_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_6_gem3_pic.Location = New System.Drawing.Point(392, 174)
            Me.slot_6_gem3_pic.Name = "slot_6_gem3_pic"
            Me.slot_6_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_6_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_6_gem3_pic.TabIndex = 63
            Me.slot_6_gem3_pic.TabStop = False
            '
            'slot_6_color
            '
            Me.slot_6_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_6_color.Controls.Add(Me.slot_6_pic)
            Me.slot_6_color.Location = New System.Drawing.Point(469, 135)
            Me.slot_6_color.Name = "slot_6_color"
            Me.slot_6_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_6_color.TabIndex = 62
            '
            'slot_6_pic
            '
            Me.slot_6_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_6_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_6_pic.Name = "slot_6_pic"
            Me.slot_6_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_6_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_6_pic.TabIndex = 0
            Me.slot_6_pic.TabStop = False
            '
            'slot_6_name
            '
            Me.slot_6_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_6_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_6_name.Location = New System.Drawing.Point(279, 138)
            Me.slot_6_name.Name = "slot_6_name"
            Me.slot_6_name.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_6_name.Size = New System.Drawing.Size(184, 15)
            Me.slot_6_name.TabIndex = 61
            Me.slot_6_name.Text = "Itemname"
            Me.slot_6_name.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_5_enchant
            '
            Me.slot_5_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_5_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_5_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_5_enchant.Location = New System.Drawing.Point(279, 91)
            Me.slot_5_enchant.Name = "slot_5_enchant"
            Me.slot_5_enchant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_5_enchant.Size = New System.Drawing.Size(179, 13)
            Me.slot_5_enchant.TabIndex = 60
            Me.slot_5_enchant.Text = "Itemenchant"
            Me.slot_5_enchant.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_5_gem1_pic
            '
            Me.slot_5_gem1_pic.Location = New System.Drawing.Point(440, 109)
            Me.slot_5_gem1_pic.Name = "slot_5_gem1_pic"
            Me.slot_5_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_5_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_5_gem1_pic.TabIndex = 59
            Me.slot_5_gem1_pic.TabStop = False
            '
            'slot_5_gem2_pic
            '
            Me.slot_5_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_5_gem2_pic.Location = New System.Drawing.Point(416, 109)
            Me.slot_5_gem2_pic.Name = "slot_5_gem2_pic"
            Me.slot_5_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_5_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_5_gem2_pic.TabIndex = 58
            Me.slot_5_gem2_pic.TabStop = False
            '
            'slot_5_gem3_pic
            '
            Me.slot_5_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_5_gem3_pic.Location = New System.Drawing.Point(392, 109)
            Me.slot_5_gem3_pic.Name = "slot_5_gem3_pic"
            Me.slot_5_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_5_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_5_gem3_pic.TabIndex = 57
            Me.slot_5_gem3_pic.TabStop = False
            '
            'slot_5_color
            '
            Me.slot_5_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_5_color.Controls.Add(Me.slot_5_pic)
            Me.slot_5_color.Location = New System.Drawing.Point(469, 70)
            Me.slot_5_color.Name = "slot_5_color"
            Me.slot_5_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_5_color.TabIndex = 56
            '
            'slot_5_pic
            '
            Me.slot_5_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_5_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_5_pic.Name = "slot_5_pic"
            Me.slot_5_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_5_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_5_pic.TabIndex = 0
            Me.slot_5_pic.TabStop = False
            '
            'slot_5_name
            '
            Me.slot_5_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_5_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_5_name.Location = New System.Drawing.Point(279, 73)
            Me.slot_5_name.Name = "slot_5_name"
            Me.slot_5_name.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_5_name.Size = New System.Drawing.Size(184, 15)
            Me.slot_5_name.TabIndex = 55
            Me.slot_5_name.Text = "Itemname"
            Me.slot_5_name.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_9_enchant
            '
            Me.slot_9_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_9_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_9_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_9_enchant.Location = New System.Drawing.Point(279, 26)
            Me.slot_9_enchant.Name = "slot_9_enchant"
            Me.slot_9_enchant.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_9_enchant.Size = New System.Drawing.Size(179, 13)
            Me.slot_9_enchant.TabIndex = 54
            Me.slot_9_enchant.Text = "Itemenchant"
            Me.slot_9_enchant.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_9_gem1_pic
            '
            Me.slot_9_gem1_pic.Location = New System.Drawing.Point(440, 44)
            Me.slot_9_gem1_pic.Name = "slot_9_gem1_pic"
            Me.slot_9_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_9_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_9_gem1_pic.TabIndex = 53
            Me.slot_9_gem1_pic.TabStop = False
            '
            'slot_9_gem2_pic
            '
            Me.slot_9_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_9_gem2_pic.Location = New System.Drawing.Point(416, 44)
            Me.slot_9_gem2_pic.Name = "slot_9_gem2_pic"
            Me.slot_9_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_9_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_9_gem2_pic.TabIndex = 52
            Me.slot_9_gem2_pic.TabStop = False
            '
            'slot_9_gem3_pic
            '
            Me.slot_9_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_9_gem3_pic.Location = New System.Drawing.Point(392, 44)
            Me.slot_9_gem3_pic.Name = "slot_9_gem3_pic"
            Me.slot_9_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_9_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_9_gem3_pic.TabIndex = 51
            Me.slot_9_gem3_pic.TabStop = False
            '
            'slot_9_color
            '
            Me.slot_9_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_9_color.Controls.Add(Me.slot_9_pic)
            Me.slot_9_color.Location = New System.Drawing.Point(469, 5)
            Me.slot_9_color.Name = "slot_9_color"
            Me.slot_9_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_9_color.TabIndex = 50
            '
            'slot_9_pic
            '
            Me.slot_9_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_9_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_9_pic.Name = "slot_9_pic"
            Me.slot_9_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_9_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_9_pic.TabIndex = 0
            Me.slot_9_pic.TabStop = False
            '
            'slot_9_name
            '
            Me.slot_9_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_9_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_9_name.Location = New System.Drawing.Point(279, 8)
            Me.slot_9_name.Name = "slot_9_name"
            Me.slot_9_name.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.slot_9_name.Size = New System.Drawing.Size(184, 15)
            Me.slot_9_name.TabIndex = 49
            Me.slot_9_name.Text = "Itemname"
            Me.slot_9_name.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'slot_8_enchant
            '
            Me.slot_8_enchant.AutoSize = True
            Me.slot_8_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_8_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_8_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_8_enchant.Location = New System.Drawing.Point(74, 481)
            Me.slot_8_enchant.Name = "slot_8_enchant"
            Me.slot_8_enchant.Size = New System.Drawing.Size(66, 13)
            Me.slot_8_enchant.TabIndex = 48
            Me.slot_8_enchant.Text = "Itemenchant"
            '
            'slot_8_gem3_pic
            '
            Me.slot_8_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_8_gem3_pic.Location = New System.Drawing.Point(122, 499)
            Me.slot_8_gem3_pic.Name = "slot_8_gem3_pic"
            Me.slot_8_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_8_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_8_gem3_pic.TabIndex = 47
            Me.slot_8_gem3_pic.TabStop = False
            '
            'slot_8_gem2_pic
            '
            Me.slot_8_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_8_gem2_pic.Location = New System.Drawing.Point(98, 499)
            Me.slot_8_gem2_pic.Name = "slot_8_gem2_pic"
            Me.slot_8_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_8_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_8_gem2_pic.TabIndex = 46
            Me.slot_8_gem2_pic.TabStop = False
            '
            'slot_8_gem1_pic
            '
            Me.slot_8_gem1_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_8_gem1_pic.Location = New System.Drawing.Point(74, 499)
            Me.slot_8_gem1_pic.Name = "slot_8_gem1_pic"
            Me.slot_8_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_8_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_8_gem1_pic.TabIndex = 45
            Me.slot_8_gem1_pic.TabStop = False
            '
            'slot_8_color
            '
            Me.slot_8_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_8_color.Controls.Add(Me.slot_8_pic)
            Me.slot_8_color.Location = New System.Drawing.Point(6, 460)
            Me.slot_8_color.Name = "slot_8_color"
            Me.slot_8_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_8_color.TabIndex = 44
            '
            'slot_8_pic
            '
            Me.slot_8_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_8_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_8_pic.Name = "slot_8_pic"
            Me.slot_8_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_8_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_8_pic.TabIndex = 0
            Me.slot_8_pic.TabStop = False
            '
            'slot_8_name
            '
            Me.slot_8_name.AutoSize = True
            Me.slot_8_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_8_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_8_name.Location = New System.Drawing.Point(74, 463)
            Me.slot_8_name.Name = "slot_8_name"
            Me.slot_8_name.Size = New System.Drawing.Size(71, 15)
            Me.slot_8_name.TabIndex = 43
            Me.slot_8_name.Text = "Itemname"
            '
            'slot_18_enchant
            '
            Me.slot_18_enchant.AutoSize = True
            Me.slot_18_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_18_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_18_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_18_enchant.Location = New System.Drawing.Point(74, 416)
            Me.slot_18_enchant.Name = "slot_18_enchant"
            Me.slot_18_enchant.Size = New System.Drawing.Size(66, 13)
            Me.slot_18_enchant.TabIndex = 42
            Me.slot_18_enchant.Text = "Itemenchant"
            '
            'slot_18_gem3_pic
            '
            Me.slot_18_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_18_gem3_pic.Location = New System.Drawing.Point(122, 434)
            Me.slot_18_gem3_pic.Name = "slot_18_gem3_pic"
            Me.slot_18_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_18_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_18_gem3_pic.TabIndex = 41
            Me.slot_18_gem3_pic.TabStop = False
            '
            'slot_18_gem2_pic
            '
            Me.slot_18_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_18_gem2_pic.Location = New System.Drawing.Point(98, 434)
            Me.slot_18_gem2_pic.Name = "slot_18_gem2_pic"
            Me.slot_18_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_18_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_18_gem2_pic.TabIndex = 40
            Me.slot_18_gem2_pic.TabStop = False
            '
            'slot_18_gem1_pic
            '
            Me.slot_18_gem1_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_18_gem1_pic.Location = New System.Drawing.Point(74, 434)
            Me.slot_18_gem1_pic.Name = "slot_18_gem1_pic"
            Me.slot_18_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_18_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_18_gem1_pic.TabIndex = 39
            Me.slot_18_gem1_pic.TabStop = False
            '
            'slot_18_color
            '
            Me.slot_18_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_18_color.Controls.Add(Me.slot_18_pic)
            Me.slot_18_color.Location = New System.Drawing.Point(6, 395)
            Me.slot_18_color.Name = "slot_18_color"
            Me.slot_18_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_18_color.TabIndex = 38
            '
            'slot_18_pic
            '
            Me.slot_18_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_18_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_18_pic.Name = "slot_18_pic"
            Me.slot_18_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_18_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_18_pic.TabIndex = 0
            Me.slot_18_pic.TabStop = False
            '
            'slot_18_name
            '
            Me.slot_18_name.AutoSize = True
            Me.slot_18_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_18_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_18_name.Location = New System.Drawing.Point(74, 398)
            Me.slot_18_name.Name = "slot_18_name"
            Me.slot_18_name.Size = New System.Drawing.Size(71, 15)
            Me.slot_18_name.TabIndex = 37
            Me.slot_18_name.Text = "Itemname"
            '
            'slot_3_enchant
            '
            Me.slot_3_enchant.AutoSize = True
            Me.slot_3_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_3_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_3_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_3_enchant.Location = New System.Drawing.Point(74, 351)
            Me.slot_3_enchant.Name = "slot_3_enchant"
            Me.slot_3_enchant.Size = New System.Drawing.Size(66, 13)
            Me.slot_3_enchant.TabIndex = 36
            Me.slot_3_enchant.Text = "Itemenchant"
            '
            'slot_3_gem3_pic
            '
            Me.slot_3_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_3_gem3_pic.Location = New System.Drawing.Point(122, 369)
            Me.slot_3_gem3_pic.Name = "slot_3_gem3_pic"
            Me.slot_3_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_3_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_3_gem3_pic.TabIndex = 35
            Me.slot_3_gem3_pic.TabStop = False
            '
            'slot_3_gem2_pic
            '
            Me.slot_3_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_3_gem2_pic.Location = New System.Drawing.Point(98, 369)
            Me.slot_3_gem2_pic.Name = "slot_3_gem2_pic"
            Me.slot_3_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_3_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_3_gem2_pic.TabIndex = 34
            Me.slot_3_gem2_pic.TabStop = False
            '
            'slot_3_gem1_pic
            '
            Me.slot_3_gem1_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_3_gem1_pic.Location = New System.Drawing.Point(74, 369)
            Me.slot_3_gem1_pic.Name = "slot_3_gem1_pic"
            Me.slot_3_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_3_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_3_gem1_pic.TabIndex = 33
            Me.slot_3_gem1_pic.TabStop = False
            '
            'slot_3_color
            '
            Me.slot_3_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_3_color.Controls.Add(Me.slot_3_pic)
            Me.slot_3_color.Location = New System.Drawing.Point(6, 330)
            Me.slot_3_color.Name = "slot_3_color"
            Me.slot_3_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_3_color.TabIndex = 32
            '
            'slot_3_pic
            '
            Me.slot_3_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_3_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_3_pic.Name = "slot_3_pic"
            Me.slot_3_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_3_pic.TabIndex = 0
            Me.slot_3_pic.TabStop = False
            '
            'slot_3_name
            '
            Me.slot_3_name.AutoSize = True
            Me.slot_3_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_3_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_3_name.Location = New System.Drawing.Point(74, 333)
            Me.slot_3_name.Name = "slot_3_name"
            Me.slot_3_name.Size = New System.Drawing.Size(71, 15)
            Me.slot_3_name.TabIndex = 31
            Me.slot_3_name.Text = "Itemname"
            '
            'slot_4_enchant
            '
            Me.slot_4_enchant.AutoSize = True
            Me.slot_4_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_4_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_4_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_4_enchant.Location = New System.Drawing.Point(74, 286)
            Me.slot_4_enchant.Name = "slot_4_enchant"
            Me.slot_4_enchant.Size = New System.Drawing.Size(66, 13)
            Me.slot_4_enchant.TabIndex = 30
            Me.slot_4_enchant.Text = "Itemenchant"
            '
            'slot_4_gem3_pic
            '
            Me.slot_4_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_4_gem3_pic.Location = New System.Drawing.Point(122, 304)
            Me.slot_4_gem3_pic.Name = "slot_4_gem3_pic"
            Me.slot_4_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_4_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_4_gem3_pic.TabIndex = 29
            Me.slot_4_gem3_pic.TabStop = False
            '
            'slot_4_gem2_pic
            '
            Me.slot_4_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_4_gem2_pic.Location = New System.Drawing.Point(98, 304)
            Me.slot_4_gem2_pic.Name = "slot_4_gem2_pic"
            Me.slot_4_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_4_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_4_gem2_pic.TabIndex = 28
            Me.slot_4_gem2_pic.TabStop = False
            '
            'slot_4_gem1_pic
            '
            Me.slot_4_gem1_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_4_gem1_pic.Location = New System.Drawing.Point(74, 304)
            Me.slot_4_gem1_pic.Name = "slot_4_gem1_pic"
            Me.slot_4_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_4_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_4_gem1_pic.TabIndex = 27
            Me.slot_4_gem1_pic.TabStop = False
            '
            'slot_4_color
            '
            Me.slot_4_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_4_color.Controls.Add(Me.slot_4_pic)
            Me.slot_4_color.Location = New System.Drawing.Point(6, 265)
            Me.slot_4_color.Name = "slot_4_color"
            Me.slot_4_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_4_color.TabIndex = 26
            '
            'slot_4_pic
            '
            Me.slot_4_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_4_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_4_pic.Name = "slot_4_pic"
            Me.slot_4_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_4_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_4_pic.TabIndex = 0
            Me.slot_4_pic.TabStop = False
            '
            'slot_4_name
            '
            Me.slot_4_name.AutoSize = True
            Me.slot_4_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_4_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_4_name.Location = New System.Drawing.Point(74, 268)
            Me.slot_4_name.Name = "slot_4_name"
            Me.slot_4_name.Size = New System.Drawing.Size(71, 15)
            Me.slot_4_name.TabIndex = 25
            Me.slot_4_name.Text = "Itemname"
            '
            'slot_14_enchant
            '
            Me.slot_14_enchant.AutoSize = True
            Me.slot_14_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_14_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_14_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_14_enchant.Location = New System.Drawing.Point(74, 221)
            Me.slot_14_enchant.Name = "slot_14_enchant"
            Me.slot_14_enchant.Size = New System.Drawing.Size(66, 13)
            Me.slot_14_enchant.TabIndex = 24
            Me.slot_14_enchant.Text = "Itemenchant"
            '
            'slot_14_gem3_pic
            '
            Me.slot_14_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_14_gem3_pic.Location = New System.Drawing.Point(122, 239)
            Me.slot_14_gem3_pic.Name = "slot_14_gem3_pic"
            Me.slot_14_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_14_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_14_gem3_pic.TabIndex = 23
            Me.slot_14_gem3_pic.TabStop = False
            '
            'slot_14_gem2_pic
            '
            Me.slot_14_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_14_gem2_pic.Location = New System.Drawing.Point(98, 239)
            Me.slot_14_gem2_pic.Name = "slot_14_gem2_pic"
            Me.slot_14_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_14_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_14_gem2_pic.TabIndex = 22
            Me.slot_14_gem2_pic.TabStop = False
            '
            'slot_14_gem1_pic
            '
            Me.slot_14_gem1_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_14_gem1_pic.Location = New System.Drawing.Point(74, 239)
            Me.slot_14_gem1_pic.Name = "slot_14_gem1_pic"
            Me.slot_14_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_14_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_14_gem1_pic.TabIndex = 21
            Me.slot_14_gem1_pic.TabStop = False
            '
            'slot_14_color
            '
            Me.slot_14_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_14_color.Controls.Add(Me.slot_14_pic)
            Me.slot_14_color.Location = New System.Drawing.Point(6, 200)
            Me.slot_14_color.Name = "slot_14_color"
            Me.slot_14_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_14_color.TabIndex = 20
            '
            'slot_14_pic
            '
            Me.slot_14_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_14_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_14_pic.Name = "slot_14_pic"
            Me.slot_14_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_14_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_14_pic.TabIndex = 0
            Me.slot_14_pic.TabStop = False
            '
            'slot_14_name
            '
            Me.slot_14_name.AutoSize = True
            Me.slot_14_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_14_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_14_name.Location = New System.Drawing.Point(74, 203)
            Me.slot_14_name.Name = "slot_14_name"
            Me.slot_14_name.Size = New System.Drawing.Size(71, 15)
            Me.slot_14_name.TabIndex = 19
            Me.slot_14_name.Text = "Itemname"
            '
            'slot_2_enchant
            '
            Me.slot_2_enchant.AutoSize = True
            Me.slot_2_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_2_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_2_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_2_enchant.Location = New System.Drawing.Point(74, 156)
            Me.slot_2_enchant.Name = "slot_2_enchant"
            Me.slot_2_enchant.Size = New System.Drawing.Size(66, 13)
            Me.slot_2_enchant.TabIndex = 18
            Me.slot_2_enchant.Text = "Itemenchant"
            '
            'slot_2_gem3_pic
            '
            Me.slot_2_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_2_gem3_pic.Location = New System.Drawing.Point(122, 174)
            Me.slot_2_gem3_pic.Name = "slot_2_gem3_pic"
            Me.slot_2_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_2_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_2_gem3_pic.TabIndex = 17
            Me.slot_2_gem3_pic.TabStop = False
            '
            'slot_2_gem2_pic
            '
            Me.slot_2_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_2_gem2_pic.Location = New System.Drawing.Point(98, 174)
            Me.slot_2_gem2_pic.Name = "slot_2_gem2_pic"
            Me.slot_2_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_2_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_2_gem2_pic.TabIndex = 16
            Me.slot_2_gem2_pic.TabStop = False
            '
            'slot_2_gem1_pic
            '
            Me.slot_2_gem1_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_2_gem1_pic.Location = New System.Drawing.Point(74, 174)
            Me.slot_2_gem1_pic.Name = "slot_2_gem1_pic"
            Me.slot_2_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_2_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_2_gem1_pic.TabIndex = 15
            Me.slot_2_gem1_pic.TabStop = False
            '
            'slot_2_color
            '
            Me.slot_2_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_2_color.Controls.Add(Me.slot_2_pic)
            Me.slot_2_color.Location = New System.Drawing.Point(6, 135)
            Me.slot_2_color.Name = "slot_2_color"
            Me.slot_2_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_2_color.TabIndex = 14
            '
            'slot_2_pic
            '
            Me.slot_2_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_2_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_2_pic.Name = "slot_2_pic"
            Me.slot_2_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_2_pic.TabIndex = 0
            Me.slot_2_pic.TabStop = False
            '
            'slot_2_name
            '
            Me.slot_2_name.AutoSize = True
            Me.slot_2_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_2_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_2_name.Location = New System.Drawing.Point(74, 138)
            Me.slot_2_name.Name = "slot_2_name"
            Me.slot_2_name.Size = New System.Drawing.Size(71, 15)
            Me.slot_2_name.TabIndex = 13
            Me.slot_2_name.Text = "Itemname"
            '
            'slot_1_enchant
            '
            Me.slot_1_enchant.AutoSize = True
            Me.slot_1_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_1_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_1_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_1_enchant.Location = New System.Drawing.Point(74, 91)
            Me.slot_1_enchant.Name = "slot_1_enchant"
            Me.slot_1_enchant.Size = New System.Drawing.Size(66, 13)
            Me.slot_1_enchant.TabIndex = 12
            Me.slot_1_enchant.Text = "Itemenchant"
            '
            'slot_1_gem3_pic
            '
            Me.slot_1_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_1_gem3_pic.Location = New System.Drawing.Point(122, 109)
            Me.slot_1_gem3_pic.Name = "slot_1_gem3_pic"
            Me.slot_1_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_1_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_1_gem3_pic.TabIndex = 11
            Me.slot_1_gem3_pic.TabStop = False
            '
            'slot_1_gem2_pic
            '
            Me.slot_1_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_1_gem2_pic.Location = New System.Drawing.Point(98, 109)
            Me.slot_1_gem2_pic.Name = "slot_1_gem2_pic"
            Me.slot_1_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_1_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_1_gem2_pic.TabIndex = 10
            Me.slot_1_gem2_pic.TabStop = False
            '
            'slot_1_gem1_pic
            '
            Me.slot_1_gem1_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_1_gem1_pic.Location = New System.Drawing.Point(74, 109)
            Me.slot_1_gem1_pic.Name = "slot_1_gem1_pic"
            Me.slot_1_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_1_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_1_gem1_pic.TabIndex = 9
            Me.slot_1_gem1_pic.TabStop = False
            '
            'slot_1_color
            '
            Me.slot_1_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_1_color.Controls.Add(Me.slot_1_pic)
            Me.slot_1_color.Location = New System.Drawing.Point(6, 70)
            Me.slot_1_color.Name = "slot_1_color"
            Me.slot_1_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_1_color.TabIndex = 8
            '
            'slot_1_pic
            '
            Me.slot_1_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_1_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_1_pic.Name = "slot_1_pic"
            Me.slot_1_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_1_pic.TabIndex = 0
            Me.slot_1_pic.TabStop = False
            '
            'slot_1_name
            '
            Me.slot_1_name.AutoSize = True
            Me.slot_1_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_1_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_1_name.Location = New System.Drawing.Point(74, 73)
            Me.slot_1_name.Name = "slot_1_name"
            Me.slot_1_name.Size = New System.Drawing.Size(71, 15)
            Me.slot_1_name.TabIndex = 7
            Me.slot_1_name.Text = "Itemname"
            '
            'slot_0_enchant
            '
            Me.slot_0_enchant.AutoSize = True
            Me.slot_0_enchant.BackColor = System.Drawing.Color.Transparent
            Me.slot_0_enchant.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_0_enchant.ForeColor = System.Drawing.Color.Lime
            Me.slot_0_enchant.Location = New System.Drawing.Point(74, 26)
            Me.slot_0_enchant.Name = "slot_0_enchant"
            Me.slot_0_enchant.Size = New System.Drawing.Size(66, 13)
            Me.slot_0_enchant.TabIndex = 6
            Me.slot_0_enchant.Text = "Itemenchant"
            '
            'slot_0_gem3_pic
            '
            Me.slot_0_gem3_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_0_gem3_pic.Location = New System.Drawing.Point(122, 44)
            Me.slot_0_gem3_pic.Name = "slot_0_gem3_pic"
            Me.slot_0_gem3_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_0_gem3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_0_gem3_pic.TabIndex = 5
            Me.slot_0_gem3_pic.TabStop = False
            '
            'slot_0_gem2_pic
            '
            Me.slot_0_gem2_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_0_gem2_pic.Location = New System.Drawing.Point(98, 44)
            Me.slot_0_gem2_pic.Name = "slot_0_gem2_pic"
            Me.slot_0_gem2_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_0_gem2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_0_gem2_pic.TabIndex = 4
            Me.slot_0_gem2_pic.TabStop = False
            '
            'slot_0_gem1_pic
            '
            Me.slot_0_gem1_pic.BackColor = System.Drawing.Color.Transparent
            Me.slot_0_gem1_pic.Location = New System.Drawing.Point(74, 44)
            Me.slot_0_gem1_pic.Name = "slot_0_gem1_pic"
            Me.slot_0_gem1_pic.Size = New System.Drawing.Size(20, 20)
            Me.slot_0_gem1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_0_gem1_pic.TabIndex = 3
            Me.slot_0_gem1_pic.TabStop = False
            '
            'slot_0_color
            '
            Me.slot_0_color.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.slot_0_color.Controls.Add(Me.slot_0_pic)
            Me.slot_0_color.Location = New System.Drawing.Point(6, 5)
            Me.slot_0_color.Name = "slot_0_color"
            Me.slot_0_color.Size = New System.Drawing.Size(62, 62)
            Me.slot_0_color.TabIndex = 2
            '
            'slot_0_pic
            '
            Me.slot_0_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.slot_0_pic.Location = New System.Drawing.Point(3, 3)
            Me.slot_0_pic.Name = "slot_0_pic"
            Me.slot_0_pic.Size = New System.Drawing.Size(56, 56)
            Me.slot_0_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.slot_0_pic.TabIndex = 0
            Me.slot_0_pic.TabStop = False
            '
            'slot_0_name
            '
            Me.slot_0_name.AutoSize = True
            Me.slot_0_name.BackColor = System.Drawing.Color.Transparent
            Me.slot_0_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.slot_0_name.Location = New System.Drawing.Point(74, 8)
            Me.slot_0_name.Name = "slot_0_name"
            Me.slot_0_name.Size = New System.Drawing.Size(71, 15)
            Me.slot_0_name.TabIndex = 1
            Me.slot_0_name.Text = "Itemname"
            '
            'charname_lbl
            '
            Me.charname_lbl.AutoSize = True
            Me.charname_lbl.BackColor = System.Drawing.Color.Transparent
            Me.charname_lbl.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.charname_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.charname_lbl.ForeColor = System.Drawing.Color.Black
            Me.charname_lbl.Location = New System.Drawing.Point(234, 62)
            Me.charname_lbl.Name = "charname_lbl"
            Me.charname_lbl.Size = New System.Drawing.Size(132, 20)
            Me.charname_lbl.TabIndex = 1
            Me.charname_lbl.Text = "Charactername"
            '
            'Label2
            '
            Me.Label2.AutoSize = True
            Me.Label2.BackColor = System.Drawing.Color.Transparent
            Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label2.ForeColor = System.Drawing.Color.Black
            Me.Label2.Location = New System.Drawing.Point(6, 24)
            Me.Label2.Name = "Label2"
            Me.Label2.Size = New System.Drawing.Size(50, 16)
            Me.Label2.TabIndex = 2
            Me.Label2.Text = "Level:"
            '
            'Label3
            '
            Me.Label3.AutoSize = True
            Me.Label3.BackColor = System.Drawing.Color.Transparent
            Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label3.ForeColor = System.Drawing.Color.Black
            Me.Label3.Location = New System.Drawing.Point(6, 50)
            Me.Label3.Name = "Label3"
            Me.Label3.Size = New System.Drawing.Size(49, 16)
            Me.Label3.TabIndex = 3
            Me.Label3.Text = "Race:"
            '
            'Label4
            '
            Me.Label4.AutoSize = True
            Me.Label4.BackColor = System.Drawing.Color.Transparent
            Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label4.ForeColor = System.Drawing.Color.Black
            Me.Label4.Location = New System.Drawing.Point(6, 76)
            Me.Label4.Name = "Label4"
            Me.Label4.Size = New System.Drawing.Size(51, 16)
            Me.Label4.TabIndex = 4
            Me.Label4.Text = "Class:"
            '
            'level_lbl
            '
            Me.level_lbl.AutoSize = True
            Me.level_lbl.BackColor = System.Drawing.Color.Transparent
            Me.level_lbl.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.level_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.level_lbl.ForeColor = System.Drawing.Color.Black
            Me.level_lbl.Location = New System.Drawing.Point(66, 24)
            Me.level_lbl.Name = "level_lbl"
            Me.level_lbl.Size = New System.Drawing.Size(23, 15)
            Me.level_lbl.TabIndex = 5
            Me.level_lbl.Text = "80"
            '
            'race_lbl
            '
            Me.race_lbl.AutoSize = True
            Me.race_lbl.BackColor = System.Drawing.Color.Transparent
            Me.race_lbl.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.race_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.race_lbl.ForeColor = System.Drawing.Color.Black
            Me.race_lbl.Location = New System.Drawing.Point(66, 50)
            Me.race_lbl.Name = "race_lbl"
            Me.race_lbl.Size = New System.Drawing.Size(60, 15)
            Me.race_lbl.TabIndex = 6
            Me.race_lbl.Text = "Bloodelf"
            '
            'class_lbl
            '
            Me.class_lbl.AutoSize = True
            Me.class_lbl.BackColor = System.Drawing.Color.Transparent
            Me.class_lbl.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.class_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.class_lbl.ForeColor = System.Drawing.Color.Black
            Me.class_lbl.Location = New System.Drawing.Point(66, 76)
            Me.class_lbl.Name = "class_lbl"
            Me.class_lbl.Size = New System.Drawing.Size(50, 15)
            Me.class_lbl.TabIndex = 7
            Me.class_lbl.Text = "Hunter"
            '
            'av_bt
            '
            Me.av_bt.BackColor = System.Drawing.Color.DimGray
            Me.av_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.av_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.av_bt.ForeColor = System.Drawing.Color.Black
            Me.av_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.av_bt.Location = New System.Drawing.Point(677, 583)
            Me.av_bt.Name = "av_bt"
            Me.av_bt.Size = New System.Drawing.Size(104, 34)
            Me.av_bt.TabIndex = 164
            Me.av_bt.Text = "Achievements"
            Me.av_bt.UseVisualStyleBackColor = False
            '
            'Glyphs_bt
            '
            Me.Glyphs_bt.BackColor = System.Drawing.Color.DimGray
            Me.Glyphs_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.Glyphs_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.Glyphs_bt.ForeColor = System.Drawing.Color.Black
            Me.Glyphs_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.Glyphs_bt.Location = New System.Drawing.Point(788, 621)
            Me.Glyphs_bt.Name = "Glyphs_bt"
            Me.Glyphs_bt.Size = New System.Drawing.Size(104, 34)
            Me.Glyphs_bt.TabIndex = 165
            Me.Glyphs_bt.Text = "Glyphs"
            Me.Glyphs_bt.UseVisualStyleBackColor = False
            '
            'rep_bt
            '
            Me.rep_bt.BackColor = System.Drawing.Color.DimGray
            Me.rep_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.rep_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.rep_bt.ForeColor = System.Drawing.Color.Black
            Me.rep_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.rep_bt.Location = New System.Drawing.Point(568, 583)
            Me.rep_bt.Name = "rep_bt"
            Me.rep_bt.Size = New System.Drawing.Size(104, 34)
            Me.rep_bt.TabIndex = 166
            Me.rep_bt.Text = "Reputation"
            Me.rep_bt.UseVisualStyleBackColor = False
            '
            'spellsskills_bt
            '
            Me.spellsskills_bt.BackColor = System.Drawing.Color.DimGray
            Me.spellsskills_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.spellsskills_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.spellsskills_bt.ForeColor = System.Drawing.Color.Black
            Me.spellsskills_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.spellsskills_bt.Location = New System.Drawing.Point(568, 621)
            Me.spellsskills_bt.Name = "spellsskills_bt"
            Me.spellsskills_bt.Size = New System.Drawing.Size(104, 34)
            Me.spellsskills_bt.TabIndex = 168
            Me.spellsskills_bt.Text = "Spells/Skills"
            Me.spellsskills_bt.UseVisualStyleBackColor = False
            '
            'exit_bt
            '
            Me.exit_bt.BackColor = System.Drawing.Color.DimGray
            Me.exit_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.exit_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.exit_bt.ForeColor = System.Drawing.Color.Black
            Me.exit_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.exit_bt.Location = New System.Drawing.Point(737, 695)
            Me.exit_bt.Name = "exit_bt"
            Me.exit_bt.Size = New System.Drawing.Size(155, 34)
            Me.exit_bt.TabIndex = 170
            Me.exit_bt.Text = "Exit"
            Me.exit_bt.UseVisualStyleBackColor = False
            '
            'savechanges_bt
            '
            Me.savechanges_bt.BackColor = System.Drawing.Color.DimGray
            Me.savechanges_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.savechanges_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.savechanges_bt.ForeColor = System.Drawing.Color.Black
            Me.savechanges_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.savechanges_bt.Location = New System.Drawing.Point(173, 695)
            Me.savechanges_bt.Name = "savechanges_bt"
            Me.savechanges_bt.Size = New System.Drawing.Size(155, 34)
            Me.savechanges_bt.TabIndex = 171
            Me.savechanges_bt.Text = "Save changes"
            Me.savechanges_bt.UseVisualStyleBackColor = False
            '
            'reset_bt
            '
            Me.reset_bt.BackColor = System.Drawing.Color.DimGray
            Me.reset_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.reset_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.reset_bt.ForeColor = System.Drawing.Color.Black
            Me.reset_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.reset_bt.Location = New System.Drawing.Point(12, 695)
            Me.reset_bt.Name = "reset_bt"
            Me.reset_bt.Size = New System.Drawing.Size(155, 34)
            Me.reset_bt.TabIndex = 172
            Me.reset_bt.Text = "Reset"
            Me.reset_bt.UseVisualStyleBackColor = False
            '
            'changepanel
            '
            Me.changepanel.BackColor = System.Drawing.Color.Transparent
            Me.changepanel.Controls.Add(Me.PictureBox2)
            Me.changepanel.Controls.Add(Me.PictureBox1)
            Me.changepanel.Controls.Add(Me.TextBox1)
            Me.changepanel.Location = New System.Drawing.Point(1375, 168)
            Me.changepanel.Name = "changepanel"
            Me.changepanel.Size = New System.Drawing.Size(133, 24)
            Me.changepanel.TabIndex = 173
            '
            'PictureBox2
            '
            Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.PictureBox2.Image = Global.NamCore_Studio.My.Resources.Resources.trash__delete__16x16
            Me.PictureBox2.Location = New System.Drawing.Point(113, 4)
            Me.PictureBox2.Name = "PictureBox2"
            Me.PictureBox2.Size = New System.Drawing.Size(16, 16)
            Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.PictureBox2.TabIndex = 175
            Me.PictureBox2.TabStop = False
            '
            'PictureBox1
            '
            Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.PictureBox1.Image = Global.NamCore_Studio.My.Resources.Resources.Refresh_icon
            Me.PictureBox1.Location = New System.Drawing.Point(93, 4)
            Me.PictureBox1.Name = "PictureBox1"
            Me.PictureBox1.Size = New System.Drawing.Size(16, 16)
            Me.PictureBox1.TabIndex = 174
            Me.PictureBox1.TabStop = False
            '
            'TextBox1
            '
            Me.TextBox1.Location = New System.Drawing.Point(3, 2)
            Me.TextBox1.Name = "TextBox1"
            Me.TextBox1.Size = New System.Drawing.Size(86, 20)
            Me.TextBox1.TabIndex = 0
            '
            'racepanel
            '
            Me.racepanel.BackColor = System.Drawing.Color.Transparent
            Me.racepanel.Controls.Add(Me.racecombo)
            Me.racepanel.Controls.Add(Me.racerefresh)
            Me.racepanel.Location = New System.Drawing.Point(1365, 267)
            Me.racepanel.Name = "racepanel"
            Me.racepanel.Size = New System.Drawing.Size(144, 25)
            Me.racepanel.TabIndex = 174
            '
            'racecombo
            '
            Me.racecombo.FormattingEnabled = True
            Me.racecombo.Items.AddRange(New Object() {"Human", "Orc", "Dwarf", "Night Elf", "Undead", "Tauren", "Gnome", "Troll", "Goblin", "Blood Elf", "Draenei", "Worgen"})
            Me.racecombo.Location = New System.Drawing.Point(3, 2)
            Me.racecombo.Name = "racecombo"
            Me.racecombo.Size = New System.Drawing.Size(115, 21)
            Me.racecombo.TabIndex = 175
            '
            'racerefresh
            '
            Me.racerefresh.Cursor = System.Windows.Forms.Cursors.Hand
            Me.racerefresh.Image = Global.NamCore_Studio.My.Resources.Resources.Refresh_icon
            Me.racerefresh.Location = New System.Drawing.Point(122, 4)
            Me.racerefresh.Name = "racerefresh"
            Me.racerefresh.Size = New System.Drawing.Size(16, 16)
            Me.racerefresh.TabIndex = 174
            Me.racerefresh.TabStop = False
            '
            'classpanel
            '
            Me.classpanel.BackColor = System.Drawing.Color.Transparent
            Me.classpanel.Controls.Add(Me.classcombo)
            Me.classpanel.Controls.Add(Me.classrefresh)
            Me.classpanel.Location = New System.Drawing.Point(1365, 230)
            Me.classpanel.Name = "classpanel"
            Me.classpanel.Size = New System.Drawing.Size(144, 25)
            Me.classpanel.TabIndex = 175
            '
            'classcombo
            '
            Me.classcombo.FormattingEnabled = True
            Me.classcombo.Items.AddRange(New Object() {"Warrior", "Paladin", "Hunter", "Rogue", "Priest", "Death Knight", "Shaman", "Mage", "Warlock", "Druid"})
            Me.classcombo.Location = New System.Drawing.Point(3, 2)
            Me.classcombo.Name = "classcombo"
            Me.classcombo.Size = New System.Drawing.Size(115, 21)
            Me.classcombo.TabIndex = 175
            '
            'classrefresh
            '
            Me.classrefresh.Cursor = System.Windows.Forms.Cursors.Hand
            Me.classrefresh.Image = Global.NamCore_Studio.My.Resources.Resources.Refresh_icon
            Me.classrefresh.Location = New System.Drawing.Point(122, 4)
            Me.classrefresh.Name = "classrefresh"
            Me.classrefresh.Size = New System.Drawing.Size(16, 16)
            Me.classrefresh.TabIndex = 174
            Me.classrefresh.TabStop = False
            '
            'selectenchpanel
            '
            Me.selectenchpanel.BackColor = System.Drawing.SystemColors.AppWorkspace
            Me.selectenchpanel.Controls.Add(Me.spellench)
            Me.selectenchpanel.Controls.Add(Me.itmench)
            Me.selectenchpanel.Controls.Add(Me.Label1)
            Me.selectenchpanel.Location = New System.Drawing.Point(1353, 56)
            Me.selectenchpanel.Name = "selectenchpanel"
            Me.selectenchpanel.Size = New System.Drawing.Size(156, 86)
            Me.selectenchpanel.TabIndex = 176
            '
            'spellench
            '
            Me.spellench.AutoSize = True
            Me.spellench.Location = New System.Drawing.Point(8, 68)
            Me.spellench.Name = "spellench"
            Me.spellench.Size = New System.Drawing.Size(39, 13)
            Me.spellench.TabIndex = 2
            Me.spellench.Text = "Label6"
            '
            'itmench
            '
            Me.itmench.AutoSize = True
            Me.itmench.Location = New System.Drawing.Point(8, 49)
            Me.itmench.Name = "itmench"
            Me.itmench.Size = New System.Drawing.Size(39, 13)
            Me.itmench.TabIndex = 1
            Me.itmench.Text = "Label5"
            '
            'Label1
            '
            Me.Label1.AutoSize = True
            Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label1.ForeColor = System.Drawing.Color.Red
            Me.Label1.Location = New System.Drawing.Point(6, 3)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(146, 39)
            Me.Label1.TabIndex = 0
            Me.Label1.Text = "NamCore has found two " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "matching enchantments:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(Select one!)"
            '
            'bank_bt
            '
            Me.bank_bt.BackColor = System.Drawing.Color.DimGray
            Me.bank_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.bank_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.bank_bt.ForeColor = System.Drawing.Color.Black
            Me.bank_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.bank_bt.Location = New System.Drawing.Point(788, 583)
            Me.bank_bt.Name = "bank_bt"
            Me.bank_bt.Size = New System.Drawing.Size(104, 34)
            Me.bank_bt.TabIndex = 177
            Me.bank_bt.Text = "Bank"
            Me.bank_bt.UseVisualStyleBackColor = False
            '
            'bag2Panel
            '
            Me.bag2Panel.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.bag2Panel.Controls.Add(Me.bag2Pic)
            Me.bag2Panel.Location = New System.Drawing.Point(66, 46)
            Me.bag2Panel.Name = "bag2Panel"
            Me.bag2Panel.Size = New System.Drawing.Size(56, 56)
            Me.bag2Panel.TabIndex = 180
            '
            'bag2Pic
            '
            Me.bag2Pic.BackgroundImage = CType(resources.GetObject("bag2Pic.BackgroundImage"), System.Drawing.Image)
            Me.bag2Pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.bag2Pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.bag2Pic.Location = New System.Drawing.Point(3, 3)
            Me.bag2Pic.Name = "bag2Pic"
            Me.bag2Pic.Size = New System.Drawing.Size(50, 50)
            Me.bag2Pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.bag2Pic.TabIndex = 0
            Me.bag2Pic.TabStop = False
            '
            'bag1Panel
            '
            Me.bag1Panel.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.bag1Panel.Controls.Add(Me.bag1Pic)
            Me.bag1Panel.Location = New System.Drawing.Point(9, 46)
            Me.bag1Panel.Name = "bag1Panel"
            Me.bag1Panel.Size = New System.Drawing.Size(56, 56)
            Me.bag1Panel.TabIndex = 179
            '
            'bag1Pic
            '
            Me.bag1Pic.BackgroundImage = Global.NamCore_Studio.My.Resources.Resources.inv_misc_bag_08
            Me.bag1Pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.bag1Pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.bag1Pic.Location = New System.Drawing.Point(3, 3)
            Me.bag1Pic.Name = "bag1Pic"
            Me.bag1Pic.Size = New System.Drawing.Size(50, 50)
            Me.bag1Pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.bag1Pic.TabIndex = 0
            Me.bag1Pic.TabStop = False
            '
            'bag4Panel
            '
            Me.bag4Panel.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.bag4Panel.Controls.Add(Me.PictureBox3)
            Me.bag4Panel.Controls.Add(Me.bag4Pic)
            Me.bag4Panel.Location = New System.Drawing.Point(180, 46)
            Me.bag4Panel.Name = "bag4Panel"
            Me.bag4Panel.Size = New System.Drawing.Size(56, 56)
            Me.bag4Panel.TabIndex = 182
            '
            'PictureBox3
            '
            Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
            Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.PictureBox3.Location = New System.Drawing.Point(-114, 4)
            Me.PictureBox3.Name = "PictureBox3"
            Me.PictureBox3.Size = New System.Drawing.Size(50, 50)
            Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.PictureBox3.TabIndex = 0
            Me.PictureBox3.TabStop = False
            '
            'bag4Pic
            '
            Me.bag4Pic.BackgroundImage = CType(resources.GetObject("bag4Pic.BackgroundImage"), System.Drawing.Image)
            Me.bag4Pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.bag4Pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.bag4Pic.Location = New System.Drawing.Point(3, 3)
            Me.bag4Pic.Name = "bag4Pic"
            Me.bag4Pic.Size = New System.Drawing.Size(50, 50)
            Me.bag4Pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.bag4Pic.TabIndex = 0
            Me.bag4Pic.TabStop = False
            '
            'bag3Panel
            '
            Me.bag3Panel.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.bag3Panel.Controls.Add(Me.bag3Pic)
            Me.bag3Panel.Location = New System.Drawing.Point(123, 46)
            Me.bag3Panel.Name = "bag3Panel"
            Me.bag3Panel.Size = New System.Drawing.Size(56, 56)
            Me.bag3Panel.TabIndex = 181
            '
            'bag3Pic
            '
            Me.bag3Pic.BackgroundImage = CType(resources.GetObject("bag3Pic.BackgroundImage"), System.Drawing.Image)
            Me.bag3Pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.bag3Pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.bag3Pic.Location = New System.Drawing.Point(3, 3)
            Me.bag3Pic.Name = "bag3Pic"
            Me.bag3Pic.Size = New System.Drawing.Size(50, 50)
            Me.bag3Pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.bag3Pic.TabIndex = 0
            Me.bag3Pic.TabStop = False
            '
            'bag5Panel
            '
            Me.bag5Panel.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.bag5Panel.Controls.Add(Me.bag5Pic)
            Me.bag5Panel.Location = New System.Drawing.Point(237, 46)
            Me.bag5Panel.Name = "bag5Panel"
            Me.bag5Panel.Size = New System.Drawing.Size(56, 56)
            Me.bag5Panel.TabIndex = 183
            '
            'bag5Pic
            '
            Me.bag5Pic.BackgroundImage = CType(resources.GetObject("bag5Pic.BackgroundImage"), System.Drawing.Image)
            Me.bag5Pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.bag5Pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.bag5Pic.Location = New System.Drawing.Point(3, 3)
            Me.bag5Pic.Name = "bag5Pic"
            Me.bag5Pic.Size = New System.Drawing.Size(50, 50)
            Me.bag5Pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.bag5Pic.TabIndex = 0
            Me.bag5Pic.TabStop = False
            '
            'addpanel
            '
            Me.addpanel.BackColor = System.Drawing.Color.Transparent
            Me.addpanel.Controls.Add(Me.PictureBox4)
            Me.addpanel.Controls.Add(Me.TextBox2)
            Me.addpanel.Location = New System.Drawing.Point(1378, 313)
            Me.addpanel.Name = "addpanel"
            Me.addpanel.Size = New System.Drawing.Size(118, 24)
            Me.addpanel.TabIndex = 185
            '
            'PictureBox4
            '
            Me.PictureBox4.Cursor = System.Windows.Forms.Cursors.Hand
            Me.PictureBox4.Image = Global.NamCore_Studio.My.Resources.Resources.plusico
            Me.PictureBox4.Location = New System.Drawing.Point(94, 4)
            Me.PictureBox4.Name = "PictureBox4"
            Me.PictureBox4.Size = New System.Drawing.Size(16, 16)
            Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.PictureBox4.TabIndex = 174
            Me.PictureBox4.TabStop = False
            '
            'TextBox2
            '
            Me.TextBox2.Location = New System.Drawing.Point(3, 2)
            Me.TextBox2.Name = "TextBox2"
            Me.TextBox2.Size = New System.Drawing.Size(86, 20)
            Me.TextBox2.TabIndex = 0
            '
            'Quests_bt
            '
            Me.Quests_bt.BackColor = System.Drawing.Color.DimGray
            Me.Quests_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.Quests_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.Quests_bt.ForeColor = System.Drawing.Color.Black
            Me.Quests_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.Quests_bt.Location = New System.Drawing.Point(677, 621)
            Me.Quests_bt.Name = "Quests_bt"
            Me.Quests_bt.Size = New System.Drawing.Size(104, 34)
            Me.Quests_bt.TabIndex = 186
            Me.Quests_bt.Text = "Quests"
            Me.Quests_bt.UseVisualStyleBackColor = False
            '
            'GroupBox1
            '
            Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
            Me.GroupBox1.Controls.Add(Me.Label6)
            Me.GroupBox1.Controls.Add(Me.gender_lbl)
            Me.GroupBox1.Controls.Add(Me.Label2)
            Me.GroupBox1.Controls.Add(Me.Label3)
            Me.GroupBox1.Controls.Add(Me.Label4)
            Me.GroupBox1.Controls.Add(Me.level_lbl)
            Me.GroupBox1.Controls.Add(Me.race_lbl)
            Me.GroupBox1.Controls.Add(Me.class_lbl)
            Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.GroupBox1.ForeColor = System.Drawing.Color.Black
            Me.GroupBox1.Location = New System.Drawing.Point(558, 58)
            Me.GroupBox1.Name = "GroupBox1"
            Me.GroupBox1.Size = New System.Drawing.Size(155, 130)
            Me.GroupBox1.TabIndex = 222
            Me.GroupBox1.TabStop = False
            Me.GroupBox1.Text = "General"
            '
            'Label6
            '
            Me.Label6.AutoSize = True
            Me.Label6.BackColor = System.Drawing.Color.Transparent
            Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label6.ForeColor = System.Drawing.Color.Black
            Me.Label6.Location = New System.Drawing.Point(6, 101)
            Me.Label6.Name = "Label6"
            Me.Label6.Size = New System.Drawing.Size(63, 16)
            Me.Label6.TabIndex = 8
            Me.Label6.Text = "Gender:"
            '
            'gender_lbl
            '
            Me.gender_lbl.AutoSize = True
            Me.gender_lbl.BackColor = System.Drawing.Color.Transparent
            Me.gender_lbl.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.gender_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.gender_lbl.ForeColor = System.Drawing.Color.Black
            Me.gender_lbl.Location = New System.Drawing.Point(66, 101)
            Me.gender_lbl.Name = "gender_lbl"
            Me.gender_lbl.Size = New System.Drawing.Size(39, 15)
            Me.gender_lbl.TabIndex = 9
            Me.gender_lbl.Text = "Male"
            '
            'GroupBox2
            '
            Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
            Me.GroupBox2.Controls.Add(Me.InventoryLayout)
            Me.GroupBox2.Controls.Add(Me.Label5)
            Me.GroupBox2.Controls.Add(Me.bag1Panel)
            Me.GroupBox2.Controls.Add(Me.bag2Panel)
            Me.GroupBox2.Controls.Add(Me.bag3Panel)
            Me.GroupBox2.Controls.Add(Me.bag4Panel)
            Me.GroupBox2.Controls.Add(Me.bag5Panel)
            Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.GroupBox2.ForeColor = System.Drawing.Color.Black
            Me.GroupBox2.Location = New System.Drawing.Point(558, 188)
            Me.GroupBox2.Name = "GroupBox2"
            Me.GroupBox2.Size = New System.Drawing.Size(338, 122)
            Me.GroupBox2.TabIndex = 223
            Me.GroupBox2.TabStop = False
            Me.GroupBox2.Text = "Inventory"
            '
            'InventoryLayout
            '
            Me.InventoryLayout.AutoSize = True
            Me.InventoryLayout.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
            Me.InventoryLayout.Location = New System.Drawing.Point(4, 105)
            Me.InventoryLayout.MaximumSize = New System.Drawing.Size(329, 10000)
            Me.InventoryLayout.MinimumSize = New System.Drawing.Size(329, 10)
            Me.InventoryLayout.Name = "InventoryLayout"
            Me.InventoryLayout.Size = New System.Drawing.Size(329, 10)
            Me.InventoryLayout.TabIndex = 229
            '
            'Label5
            '
            Me.Label5.AutoSize = True
            Me.Label5.BackColor = System.Drawing.Color.Transparent
            Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label5.ForeColor = System.Drawing.Color.Black
            Me.Label5.Location = New System.Drawing.Point(6, 23)
            Me.Label5.Name = "Label5"
            Me.Label5.Size = New System.Drawing.Size(48, 16)
            Me.Label5.TabIndex = 2
            Me.Label5.Text = "Bags:"
            '
            'genderpanel
            '
            Me.genderpanel.BackColor = System.Drawing.Color.Transparent
            Me.genderpanel.Controls.Add(Me.genderrefresh)
            Me.genderpanel.Controls.Add(Me.gendercombo)
            Me.genderpanel.Location = New System.Drawing.Point(1365, 360)
            Me.genderpanel.Name = "genderpanel"
            Me.genderpanel.Size = New System.Drawing.Size(144, 25)
            Me.genderpanel.TabIndex = 226
            '
            'genderrefresh
            '
            Me.genderrefresh.Cursor = System.Windows.Forms.Cursors.Hand
            Me.genderrefresh.Image = Global.NamCore_Studio.My.Resources.Resources.Refresh_icon
            Me.genderrefresh.Location = New System.Drawing.Point(122, 4)
            Me.genderrefresh.Name = "genderrefresh"
            Me.genderrefresh.Size = New System.Drawing.Size(16, 16)
            Me.genderrefresh.TabIndex = 174
            Me.genderrefresh.TabStop = False
            '
            'gendercombo
            '
            Me.gendercombo.FormattingEnabled = True
            Me.gendercombo.Items.AddRange(New Object() {"Male", "Female"})
            Me.gendercombo.Location = New System.Drawing.Point(3, 2)
            Me.gendercombo.Name = "gendercombo"
            Me.gendercombo.Size = New System.Drawing.Size(115, 21)
            Me.gendercombo.TabIndex = 175
            '
            'referenceItmPanel
            '
            Me.referenceItmPanel.BackColor = System.Drawing.SystemColors.ActiveBorder
            Me.referenceItmPanel.Controls.Add(Me.referenceCount)
            Me.referenceItmPanel.Controls.Add(Me.removeinventbox)
            Me.referenceItmPanel.Controls.Add(Me.referenceItmPic)
            Me.referenceItmPanel.Location = New System.Drawing.Point(1419, 438)
            Me.referenceItmPanel.Margin = New System.Windows.Forms.Padding(1)
            Me.referenceItmPanel.Name = "referenceItmPanel"
            Me.referenceItmPanel.Size = New System.Drawing.Size(45, 45)
            Me.referenceItmPanel.TabIndex = 228
            '
            'referenceCount
            '
            Me.referenceCount.AutoSize = True
            Me.referenceCount.Location = New System.Drawing.Point(23, 3)
            Me.referenceCount.Name = "referenceCount"
            Me.referenceCount.Size = New System.Drawing.Size(19, 13)
            Me.referenceCount.TabIndex = 232
            Me.referenceCount.Text = "20"
            '
            'removeinventbox
            '
            Me.removeinventbox.BackColor = System.Drawing.Color.Transparent
            Me.removeinventbox.BackgroundImage = Global.NamCore_Studio.My.Resources.Resources.inv_misc_gem_01
            Me.removeinventbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.removeinventbox.Cursor = System.Windows.Forms.Cursors.Hand
            Me.removeinventbox.Location = New System.Drawing.Point(2, 2)
            Me.removeinventbox.Name = "removeinventbox"
            Me.removeinventbox.Size = New System.Drawing.Size(16, 16)
            Me.removeinventbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.removeinventbox.TabIndex = 230
            Me.removeinventbox.TabStop = False
            '
            'referenceItmPic
            '
            Me.referenceItmPic.BackgroundImage = Global.NamCore_Studio.My.Resources.Resources.bank_empty
            Me.referenceItmPic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.referenceItmPic.Location = New System.Drawing.Point(3, 3)
            Me.referenceItmPic.Name = "referenceItmPic"
            Me.referenceItmPic.Size = New System.Drawing.Size(39, 39)
            Me.referenceItmPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.referenceItmPic.TabIndex = 0
            Me.referenceItmPic.TabStop = False
            '
            'professions_bt
            '
            Me.professions_bt.BackColor = System.Drawing.Color.DimGray
            Me.professions_bt.Cursor = System.Windows.Forms.Cursors.Hand
            Me.professions_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.professions_bt.ForeColor = System.Drawing.Color.Black
            Me.professions_bt.ImeMode = System.Windows.Forms.ImeMode.NoControl
            Me.professions_bt.Location = New System.Drawing.Point(568, 659)
            Me.professions_bt.Name = "professions_bt"
            Me.professions_bt.Size = New System.Drawing.Size(104, 34)
            Me.professions_bt.TabIndex = 229
            Me.professions_bt.Text = "Professions"
            Me.professions_bt.UseVisualStyleBackColor = False
            '
            'loadedat_lbl
            '
            Me.loadedat_lbl.BackColor = System.Drawing.Color.Transparent
            Me.loadedat_lbl.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.loadedat_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.loadedat_lbl.ForeColor = System.Drawing.Color.Black
            Me.loadedat_lbl.Location = New System.Drawing.Point(378, 65)
            Me.loadedat_lbl.Name = "loadedat_lbl"
            Me.loadedat_lbl.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.loadedat_lbl.Size = New System.Drawing.Size(157, 18)
            Me.loadedat_lbl.TabIndex = 230
            Me.loadedat_lbl.Text = "11.02.2014 - 20:42"
            Me.loadedat_lbl.TextAlign = System.Drawing.ContentAlignment.TopRight
            '
            'refreshchar
            '
            Me.refreshchar.BackColor = System.Drawing.Color.Transparent
            Me.refreshchar.BackgroundImage = Global.NamCore_Studio.My.Resources.Resources.refresh
            Me.refreshchar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.refreshchar.Cursor = System.Windows.Forms.Cursors.Hand
            Me.refreshchar.Location = New System.Drawing.Point(533, 61)
            Me.refreshchar.Name = "refreshchar"
            Me.refreshchar.Size = New System.Drawing.Size(22, 22)
            Me.refreshchar.TabIndex = 231
            Me.refreshchar.TabStop = False
            '
            'Label7
            '
            Me.Label7.AutoSize = True
            Me.Label7.BackColor = System.Drawing.Color.Transparent
            Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label7.ForeColor = System.Drawing.Color.Black
            Me.Label7.Location = New System.Drawing.Point(717, 159)
            Me.Label7.Name = "Label7"
            Me.Label7.Size = New System.Drawing.Size(45, 16)
            Me.Label7.TabIndex = 232
            Me.Label7.Text = "Gold:"
            '
            'gold_txtbox
            '
            Me.gold_txtbox.Location = New System.Drawing.Point(768, 157)
            Me.gold_txtbox.Name = "gold_txtbox"
            Me.gold_txtbox.Size = New System.Drawing.Size(100, 20)
            Me.gold_txtbox.TabIndex = 233
            '
            'refreshgold
            '
            Me.refreshgold.BackColor = System.Drawing.Color.Transparent
            Me.refreshgold.BackgroundImage = Global.NamCore_Studio.My.Resources.Resources.refresh
            Me.refreshgold.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.refreshgold.Cursor = System.Windows.Forms.Cursors.Hand
            Me.refreshgold.Location = New System.Drawing.Point(870, 156)
            Me.refreshgold.Name = "refreshgold"
            Me.refreshgold.Size = New System.Drawing.Size(22, 22)
            Me.refreshgold.TabIndex = 234
            Me.refreshgold.TabStop = False
            '
            'CharacterOverview
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackgroundImage = Global.NamCore_Studio.My.Resources.Resources.HUD_bg
            Me.ClientSize = New System.Drawing.Size(902, 736)
            Me.Controls.Add(Me.genderpanel)
            Me.Controls.Add(Me.refreshgold)
            Me.Controls.Add(Me.gold_txtbox)
            Me.Controls.Add(Me.Label7)
            Me.Controls.Add(Me.refreshchar)
            Me.Controls.Add(Me.loadedat_lbl)
            Me.Controls.Add(Me.professions_bt)
            Me.Controls.Add(Me.referenceItmPanel)
            Me.Controls.Add(Me.addpanel)
            Me.Controls.Add(Me.selectenchpanel)
            Me.Controls.Add(Me.classpanel)
            Me.Controls.Add(Me.racepanel)
            Me.Controls.Add(Me.changepanel)
            Me.Controls.Add(Me.GroupBox2)
            Me.Controls.Add(Me.GroupBox1)
            Me.Controls.Add(Me.Quests_bt)
            Me.Controls.Add(Me.bank_bt)
            Me.Controls.Add(Me.reset_bt)
            Me.Controls.Add(Me.savechanges_bt)
            Me.Controls.Add(Me.exit_bt)
            Me.Controls.Add(Me.spellsskills_bt)
            Me.Controls.Add(Me.rep_bt)
            Me.Controls.Add(Me.Glyphs_bt)
            Me.Controls.Add(Me.av_bt)
            Me.Controls.Add(Me.charname_lbl)
            Me.Controls.Add(Me.InventoryPanel)
            Me.DoubleBuffered = True
            Me.ForeColor = System.Drawing.Color.Black
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.Name = "CharacterOverview"
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.Text = "CharacterOverview"
            Me.Controls.SetChildIndex(Me.InventoryPanel, 0)
            Me.Controls.SetChildIndex(Me.charname_lbl, 0)
            Me.Controls.SetChildIndex(Me.av_bt, 0)
            Me.Controls.SetChildIndex(Me.Glyphs_bt, 0)
            Me.Controls.SetChildIndex(Me.rep_bt, 0)
            Me.Controls.SetChildIndex(Me.spellsskills_bt, 0)
            Me.Controls.SetChildIndex(Me.exit_bt, 0)
            Me.Controls.SetChildIndex(Me.savechanges_bt, 0)
            Me.Controls.SetChildIndex(Me.reset_bt, 0)
            Me.Controls.SetChildIndex(Me.bank_bt, 0)
            Me.Controls.SetChildIndex(Me.Quests_bt, 0)
            Me.Controls.SetChildIndex(Me.GroupBox1, 0)
            Me.Controls.SetChildIndex(Me.GroupBox2, 0)
            Me.Controls.SetChildIndex(Me.changepanel, 0)
            Me.Controls.SetChildIndex(Me.racepanel, 0)
            Me.Controls.SetChildIndex(Me.classpanel, 0)
            Me.Controls.SetChildIndex(Me.selectenchpanel, 0)
            Me.Controls.SetChildIndex(Me.addpanel, 0)
            Me.Controls.SetChildIndex(Me.referenceItmPanel, 0)
            Me.Controls.SetChildIndex(Me.professions_bt, 0)
            Me.Controls.SetChildIndex(Me.loadedat_lbl, 0)
            Me.Controls.SetChildIndex(Me.refreshchar, 0)
            Me.Controls.SetChildIndex(Me.Label7, 0)
            Me.Controls.SetChildIndex(Me.gold_txtbox, 0)
            Me.Controls.SetChildIndex(Me.refreshgold, 0)
            Me.Controls.SetChildIndex(Me.genderpanel, 0)
            Me.InventoryPanel.ResumeLayout(False)
            Me.InventoryPanel.PerformLayout()
            CType(Me.slot_17_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_17_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_17_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_17_color.ResumeLayout(False)
            CType(Me.slot_17_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_15_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_15_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_15_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_15_color.ResumeLayout(False)
            CType(Me.slot_15_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_16_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_16_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_16_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_16_color.ResumeLayout(False)
            CType(Me.slot_16_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_13_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_13_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_13_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_13_color.ResumeLayout(False)
            CType(Me.slot_13_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_12_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_12_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_12_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_12_color.ResumeLayout(False)
            CType(Me.slot_12_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_11_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_11_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_11_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_11_color.ResumeLayout(False)
            CType(Me.slot_11_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_10_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_10_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_10_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_10_color.ResumeLayout(False)
            CType(Me.slot_10_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_7_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_7_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_7_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_7_color.ResumeLayout(False)
            CType(Me.slot_7_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_6_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_6_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_6_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_6_color.ResumeLayout(False)
            CType(Me.slot_6_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_5_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_5_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_5_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_5_color.ResumeLayout(False)
            CType(Me.slot_5_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_9_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_9_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_9_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_9_color.ResumeLayout(False)
            CType(Me.slot_9_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_8_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_8_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_8_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_8_color.ResumeLayout(False)
            CType(Me.slot_8_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_18_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_18_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_18_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_18_color.ResumeLayout(False)
            CType(Me.slot_18_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_3_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_3_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_3_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_3_color.ResumeLayout(False)
            CType(Me.slot_3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_4_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_4_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_4_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_4_color.ResumeLayout(False)
            CType(Me.slot_4_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_14_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_14_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_14_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_14_color.ResumeLayout(False)
            CType(Me.slot_14_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_2_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_2_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_2_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_2_color.ResumeLayout(False)
            CType(Me.slot_2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_1_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_1_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_1_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_1_color.ResumeLayout(False)
            CType(Me.slot_1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_0_gem3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_0_gem2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.slot_0_gem1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.slot_0_color.ResumeLayout(False)
            CType(Me.slot_0_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.changepanel.ResumeLayout(False)
            Me.changepanel.PerformLayout()
            CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.racepanel.ResumeLayout(False)
            CType(Me.racerefresh, System.ComponentModel.ISupportInitialize).EndInit()
            Me.classpanel.ResumeLayout(False)
            CType(Me.classrefresh, System.ComponentModel.ISupportInitialize).EndInit()
            Me.selectenchpanel.ResumeLayout(False)
            Me.selectenchpanel.PerformLayout()
            Me.bag2Panel.ResumeLayout(False)
            CType(Me.bag2Pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.bag1Panel.ResumeLayout(False)
            CType(Me.bag1Pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.bag4Panel.ResumeLayout(False)
            CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.bag4Pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.bag3Panel.ResumeLayout(False)
            CType(Me.bag3Pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.bag5Panel.ResumeLayout(False)
            CType(Me.bag5Pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.addpanel.ResumeLayout(False)
            Me.addpanel.PerformLayout()
            CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
            Me.GroupBox1.ResumeLayout(False)
            Me.GroupBox1.PerformLayout()
            Me.GroupBox2.ResumeLayout(False)
            Me.GroupBox2.PerformLayout()
            Me.genderpanel.ResumeLayout(False)
            CType(Me.genderrefresh, System.ComponentModel.ISupportInitialize).EndInit()
            Me.referenceItmPanel.ResumeLayout(False)
            Me.referenceItmPanel.PerformLayout()
            CType(Me.removeinventbox, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.referenceItmPic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.refreshchar, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.refreshgold, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub
        Friend WithEvents InventoryPanel As System.Windows.Forms.Panel
        Friend WithEvents slot_0_name As System.Windows.Forms.Label
        Friend WithEvents slot_0_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_0_color As System.Windows.Forms.Panel
        Friend WithEvents slot_13_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_13_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_13_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_13_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_13_color As System.Windows.Forms.Panel
        Friend WithEvents slot_13_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_13_name As System.Windows.Forms.Label
        Friend WithEvents slot_12_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_12_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_12_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_12_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_12_color As System.Windows.Forms.Panel
        Friend WithEvents slot_12_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_12_name As System.Windows.Forms.Label
        Friend WithEvents slot_11_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_11_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_11_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_11_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_11_color As System.Windows.Forms.Panel
        Friend WithEvents slot_11_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_11_name As System.Windows.Forms.Label
        Friend WithEvents slot_10_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_10_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_10_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_10_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_10_color As System.Windows.Forms.Panel
        Friend WithEvents slot_10_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_10_name As System.Windows.Forms.Label
        Friend WithEvents slot_7_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_7_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_7_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_7_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_7_color As System.Windows.Forms.Panel
        Friend WithEvents slot_7_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_7_name As System.Windows.Forms.Label
        Friend WithEvents slot_6_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_6_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_6_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_6_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_6_color As System.Windows.Forms.Panel
        Friend WithEvents slot_6_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_6_name As System.Windows.Forms.Label
        Friend WithEvents slot_5_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_5_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_5_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_5_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_5_color As System.Windows.Forms.Panel
        Friend WithEvents slot_5_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_5_name As System.Windows.Forms.Label
        Friend WithEvents slot_9_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_9_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_9_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_9_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_9_color As System.Windows.Forms.Panel
        Friend WithEvents slot_9_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_9_name As System.Windows.Forms.Label
        Friend WithEvents slot_8_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_8_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_8_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_8_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_8_color As System.Windows.Forms.Panel
        Friend WithEvents slot_8_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_8_name As System.Windows.Forms.Label
        Friend WithEvents slot_18_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_18_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_18_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_18_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_18_color As System.Windows.Forms.Panel
        Friend WithEvents slot_18_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_18_name As System.Windows.Forms.Label
        Friend WithEvents slot_3_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_3_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_3_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_3_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_3_color As System.Windows.Forms.Panel
        Friend WithEvents slot_3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_3_name As System.Windows.Forms.Label
        Friend WithEvents slot_4_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_4_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_4_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_4_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_4_color As System.Windows.Forms.Panel
        Friend WithEvents slot_4_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_4_name As System.Windows.Forms.Label
        Friend WithEvents slot_14_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_14_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_14_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_14_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_14_color As System.Windows.Forms.Panel
        Friend WithEvents slot_14_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_14_name As System.Windows.Forms.Label
        Friend WithEvents slot_2_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_2_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_2_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_2_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_2_color As System.Windows.Forms.Panel
        Friend WithEvents slot_2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_2_name As System.Windows.Forms.Label
        Friend WithEvents slot_1_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_1_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_1_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_1_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_1_color As System.Windows.Forms.Panel
        Friend WithEvents slot_1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_1_name As System.Windows.Forms.Label
        Friend WithEvents slot_0_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_0_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_0_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_0_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_17_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_17_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_17_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_17_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_17_color As System.Windows.Forms.Panel
        Friend WithEvents slot_17_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_17_name As System.Windows.Forms.Label
        Friend WithEvents slot_15_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_15_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_15_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_15_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_15_color As System.Windows.Forms.Panel
        Friend WithEvents slot_15_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_15_name As System.Windows.Forms.Label
        Friend WithEvents slot_16_enchant As System.Windows.Forms.Label
        Friend WithEvents slot_16_gem3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_16_gem2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_16_gem1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_16_color As System.Windows.Forms.Panel
        Friend WithEvents slot_16_pic As System.Windows.Forms.PictureBox
        Friend WithEvents slot_16_name As System.Windows.Forms.Label
        Friend WithEvents charname_lbl As System.Windows.Forms.Label
        Friend WithEvents Label2 As System.Windows.Forms.Label
        Friend WithEvents Label3 As System.Windows.Forms.Label
        Friend WithEvents Label4 As System.Windows.Forms.Label
        Friend WithEvents level_lbl As System.Windows.Forms.Label
        Friend WithEvents race_lbl As System.Windows.Forms.Label
        Friend WithEvents class_lbl As System.Windows.Forms.Label
        Friend WithEvents av_bt As System.Windows.Forms.Button
        Friend WithEvents Glyphs_bt As System.Windows.Forms.Button
        Friend WithEvents rep_bt As System.Windows.Forms.Button
        Friend WithEvents spellsskills_bt As System.Windows.Forms.Button
        Friend WithEvents exit_bt As System.Windows.Forms.Button
        Friend WithEvents savechanges_bt As System.Windows.Forms.Button
        Friend WithEvents reset_bt As System.Windows.Forms.Button
        Friend WithEvents changepanel As System.Windows.Forms.Panel
        Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
        Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
        Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
        Friend WithEvents racepanel As System.Windows.Forms.Panel
        Friend WithEvents racecombo As System.Windows.Forms.ComboBox
        Friend WithEvents racerefresh As System.Windows.Forms.PictureBox
        Friend WithEvents classpanel As System.Windows.Forms.Panel
        Friend WithEvents classcombo As System.Windows.Forms.ComboBox
        Friend WithEvents classrefresh As System.Windows.Forms.PictureBox
        Friend WithEvents selectenchpanel As System.Windows.Forms.Panel
        Friend WithEvents spellench As System.Windows.Forms.Label
        Friend WithEvents itmench As System.Windows.Forms.Label
        Friend WithEvents Label1 As System.Windows.Forms.Label
        Friend WithEvents bank_bt As System.Windows.Forms.Button
        Friend WithEvents bag2Pic As System.Windows.Forms.PictureBox
        Friend WithEvents bag1Pic As System.Windows.Forms.PictureBox
        Friend WithEvents bag4Pic As System.Windows.Forms.PictureBox
        Friend WithEvents bag3Pic As System.Windows.Forms.PictureBox
        Friend WithEvents bag5Pic As System.Windows.Forms.PictureBox
        Friend WithEvents addpanel As System.Windows.Forms.Panel
        Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
        Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
        Friend WithEvents Quests_bt As System.Windows.Forms.Button
        Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
        Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
        Friend WithEvents Label5 As System.Windows.Forms.Label
        Friend WithEvents InfoToolTip As System.Windows.Forms.ToolTip
        Friend WithEvents Label6 As System.Windows.Forms.Label
        Friend WithEvents gender_lbl As System.Windows.Forms.Label
        Friend WithEvents genderpanel As System.Windows.Forms.Panel
        Friend WithEvents gendercombo As System.Windows.Forms.ComboBox
        Friend WithEvents genderrefresh As System.Windows.Forms.PictureBox
        Friend WithEvents referenceItmPanel As System.Windows.Forms.Panel
        Friend WithEvents referenceItmPic As System.Windows.Forms.PictureBox
        Friend WithEvents InventoryLayout As System.Windows.Forms.FlowLayoutPanel
        Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
        Friend WithEvents professions_bt As System.Windows.Forms.Button
        Friend WithEvents removeinventbox As System.Windows.Forms.PictureBox
        Friend WithEvents loadedat_lbl As System.Windows.Forms.Label
        Friend WithEvents refreshchar As System.Windows.Forms.PictureBox
        Friend WithEvents referenceCount As System.Windows.Forms.Label
        Friend WithEvents Label7 As System.Windows.Forms.Label
        Friend WithEvents gold_txtbox As System.Windows.Forms.TextBox
        Friend WithEvents refreshgold As System.Windows.Forms.PictureBox
        Friend WithEvents bag2Panel As NamCore_Studio.Modules.Interface.ItemPanel
        Friend WithEvents bag1Panel As NamCore_Studio.Modules.Interface.ItemPanel
        Friend WithEvents bag4Panel As NamCore_Studio.Modules.Interface.ItemPanel
        Friend WithEvents bag3Panel As NamCore_Studio.Modules.Interface.ItemPanel
        Friend WithEvents bag5Panel As NamCore_Studio.Modules.Interface.ItemPanel
    End Class
End Namespace