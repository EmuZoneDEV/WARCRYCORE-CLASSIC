﻿Imports NamCore_Studio.Forms.Extension

Namespace Forms.Character
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
    Partial Class GlyphsInterface
        Inherits EventTrigger

        'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
        <System.Diagnostics.DebuggerNonUserCode()> _
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub

        'Wird vom Windows Form-Designer benötigt.
        Private components As System.ComponentModel.IContainer

        'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
        'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
        'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
        <System.Diagnostics.DebuggerStepThrough()> _
        Private Sub InitializeComponent()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GlyphsInterface))
            Me.prim_1_pic = New System.Windows.Forms.PictureBox()
            Me.prim_1_name = New System.Windows.Forms.Label()
            Me.Label1 = New System.Windows.Forms.Label()
            Me.Label2 = New System.Windows.Forms.Label()
            Me.Label3 = New System.Windows.Forms.Label()
            Me.prim_2_pic = New System.Windows.Forms.PictureBox()
            Me.prim_2_name = New System.Windows.Forms.Label()
            Me.prim_3_pic = New System.Windows.Forms.PictureBox()
            Me.prim_3_name = New System.Windows.Forms.Label()
            Me.major_1_pic = New System.Windows.Forms.PictureBox()
            Me.major_1_name = New System.Windows.Forms.Label()
            Me.major_2_pic = New System.Windows.Forms.PictureBox()
            Me.major_2_name = New System.Windows.Forms.Label()
            Me.major_3_pic = New System.Windows.Forms.PictureBox()
            Me.major_3_name = New System.Windows.Forms.Label()
            Me.minor_3_pic = New System.Windows.Forms.PictureBox()
            Me.minor_3_name = New System.Windows.Forms.Label()
            Me.minor_2_pic = New System.Windows.Forms.PictureBox()
            Me.minor_2_name = New System.Windows.Forms.Label()
            Me.minor_1_pic = New System.Windows.Forms.PictureBox()
            Me.minor_1_name = New System.Windows.Forms.Label()
            Me.sec_minor_3_pic = New System.Windows.Forms.PictureBox()
            Me.sec_minor_3_name = New System.Windows.Forms.Label()
            Me.sec_minor_2_pic = New System.Windows.Forms.PictureBox()
            Me.sec_minor_2_name = New System.Windows.Forms.Label()
            Me.sec_minor_1_pic = New System.Windows.Forms.PictureBox()
            Me.sec_minor_1_name = New System.Windows.Forms.Label()
            Me.sec_major_3_pic = New System.Windows.Forms.PictureBox()
            Me.sec_major_3_name = New System.Windows.Forms.Label()
            Me.sec_major_2_pic = New System.Windows.Forms.PictureBox()
            Me.sec_major_2_name = New System.Windows.Forms.Label()
            Me.sec_major_1_pic = New System.Windows.Forms.PictureBox()
            Me.sec_major_1_name = New System.Windows.Forms.Label()
            Me.sec_prim_3_pic = New System.Windows.Forms.PictureBox()
            Me.sec_prim_3_name = New System.Windows.Forms.Label()
            Me.sec_prim_2_pic = New System.Windows.Forms.PictureBox()
            Me.sec_prim_2_name = New System.Windows.Forms.Label()
            Me.sec_prim_1_pic = New System.Windows.Forms.PictureBox()
            Me.Label12 = New System.Windows.Forms.Label()
            Me.Label13 = New System.Windows.Forms.Label()
            Me.Label14 = New System.Windows.Forms.Label()
            Me.sec_prim_1_name = New System.Windows.Forms.Label()
            Me.changepanel = New System.Windows.Forms.Panel()
            Me.PictureBox2 = New System.Windows.Forms.PictureBox()
            Me.PictureBox1 = New System.Windows.Forms.PictureBox()
            Me.TextBox1 = New System.Windows.Forms.TextBox()
            Me.addpanel = New System.Windows.Forms.Panel()
            Me.PictureBox4 = New System.Windows.Forms.PictureBox()
            Me.TextBox2 = New System.Windows.Forms.TextBox()
            Me.glyph_panel = New System.Windows.Forms.Panel()
            CType(Me.prim_1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.prim_2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.prim_3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.major_1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.major_2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.major_3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.minor_3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.minor_2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.minor_1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.sec_minor_3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.sec_minor_2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.sec_minor_1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.sec_major_3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.sec_major_2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.sec_major_1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.sec_prim_3_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.sec_prim_2_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.sec_prim_1_pic, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.changepanel.SuspendLayout()
            CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.addpanel.SuspendLayout()
            CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.glyph_panel.SuspendLayout()
            Me.SuspendLayout()
            '
            'prim_1_pic
            '
            Me.prim_1_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.prim_1_pic.Location = New System.Drawing.Point(29, 66)
            Me.prim_1_pic.Name = "prim_1_pic"
            Me.prim_1_pic.Size = New System.Drawing.Size(56, 56)
            Me.prim_1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.prim_1_pic.TabIndex = 0
            Me.prim_1_pic.TabStop = False
            '
            'prim_1_name
            '
            Me.prim_1_name.AutoSize = True
            Me.prim_1_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.prim_1_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.prim_1_name.ForeColor = System.Drawing.Color.Black
            Me.prim_1_name.Location = New System.Drawing.Point(91, 66)
            Me.prim_1_name.Name = "prim_1_name"
            Me.prim_1_name.Size = New System.Drawing.Size(71, 15)
            Me.prim_1_name.TabIndex = 7
            Me.prim_1_name.Text = "Itemname"
            '
            'Label1
            '
            Me.Label1.AutoSize = True
            Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label1.ForeColor = System.Drawing.Color.Black
            Me.Label1.Location = New System.Drawing.Point(309, 33)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(53, 20)
            Me.Label1.TabIndex = 10
            Me.Label1.Text = "Major"
            '
            'Label2
            '
            Me.Label2.AutoSize = True
            Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label2.ForeColor = System.Drawing.Color.Black
            Me.Label2.Location = New System.Drawing.Point(25, 33)
            Me.Label2.Name = "Label2"
            Me.Label2.Size = New System.Drawing.Size(54, 20)
            Me.Label2.TabIndex = 11
            Me.Label2.Text = "Prime"
            '
            'Label3
            '
            Me.Label3.AutoSize = True
            Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label3.ForeColor = System.Drawing.Color.Black
            Me.Label3.Location = New System.Drawing.Point(577, 33)
            Me.Label3.Name = "Label3"
            Me.Label3.Size = New System.Drawing.Size(53, 20)
            Me.Label3.TabIndex = 12
            Me.Label3.Text = "Minor"
            '
            'prim_2_pic
            '
            Me.prim_2_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.prim_2_pic.Location = New System.Drawing.Point(29, 128)
            Me.prim_2_pic.Name = "prim_2_pic"
            Me.prim_2_pic.Size = New System.Drawing.Size(56, 56)
            Me.prim_2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.prim_2_pic.TabIndex = 13
            Me.prim_2_pic.TabStop = False
            '
            'prim_2_name
            '
            Me.prim_2_name.AutoSize = True
            Me.prim_2_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.prim_2_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.prim_2_name.ForeColor = System.Drawing.Color.Black
            Me.prim_2_name.Location = New System.Drawing.Point(91, 128)
            Me.prim_2_name.Name = "prim_2_name"
            Me.prim_2_name.Size = New System.Drawing.Size(71, 15)
            Me.prim_2_name.TabIndex = 14
            Me.prim_2_name.Text = "Itemname"
            '
            'prim_3_pic
            '
            Me.prim_3_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.prim_3_pic.Location = New System.Drawing.Point(29, 190)
            Me.prim_3_pic.Name = "prim_3_pic"
            Me.prim_3_pic.Size = New System.Drawing.Size(56, 56)
            Me.prim_3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.prim_3_pic.TabIndex = 15
            Me.prim_3_pic.TabStop = False
            '
            'prim_3_name
            '
            Me.prim_3_name.AutoSize = True
            Me.prim_3_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.prim_3_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.prim_3_name.ForeColor = System.Drawing.Color.Black
            Me.prim_3_name.Location = New System.Drawing.Point(91, 190)
            Me.prim_3_name.Name = "prim_3_name"
            Me.prim_3_name.Size = New System.Drawing.Size(71, 15)
            Me.prim_3_name.TabIndex = 16
            Me.prim_3_name.Text = "Itemname"
            '
            'major_1_pic
            '
            Me.major_1_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.major_1_pic.Location = New System.Drawing.Point(313, 66)
            Me.major_1_pic.Name = "major_1_pic"
            Me.major_1_pic.Size = New System.Drawing.Size(56, 56)
            Me.major_1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.major_1_pic.TabIndex = 17
            Me.major_1_pic.TabStop = False
            '
            'major_1_name
            '
            Me.major_1_name.AutoSize = True
            Me.major_1_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.major_1_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.major_1_name.ForeColor = System.Drawing.Color.Black
            Me.major_1_name.Location = New System.Drawing.Point(375, 66)
            Me.major_1_name.Name = "major_1_name"
            Me.major_1_name.Size = New System.Drawing.Size(71, 15)
            Me.major_1_name.TabIndex = 18
            Me.major_1_name.Text = "Itemname"
            '
            'major_2_pic
            '
            Me.major_2_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.major_2_pic.Location = New System.Drawing.Point(313, 128)
            Me.major_2_pic.Name = "major_2_pic"
            Me.major_2_pic.Size = New System.Drawing.Size(56, 56)
            Me.major_2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.major_2_pic.TabIndex = 19
            Me.major_2_pic.TabStop = False
            '
            'major_2_name
            '
            Me.major_2_name.AutoSize = True
            Me.major_2_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.major_2_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.major_2_name.ForeColor = System.Drawing.Color.Black
            Me.major_2_name.Location = New System.Drawing.Point(375, 128)
            Me.major_2_name.Name = "major_2_name"
            Me.major_2_name.Size = New System.Drawing.Size(71, 15)
            Me.major_2_name.TabIndex = 20
            Me.major_2_name.Text = "Itemname"
            '
            'major_3_pic
            '
            Me.major_3_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.major_3_pic.Location = New System.Drawing.Point(313, 190)
            Me.major_3_pic.Name = "major_3_pic"
            Me.major_3_pic.Size = New System.Drawing.Size(56, 56)
            Me.major_3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.major_3_pic.TabIndex = 21
            Me.major_3_pic.TabStop = False
            '
            'major_3_name
            '
            Me.major_3_name.AutoSize = True
            Me.major_3_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.major_3_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.major_3_name.ForeColor = System.Drawing.Color.Black
            Me.major_3_name.Location = New System.Drawing.Point(375, 190)
            Me.major_3_name.Name = "major_3_name"
            Me.major_3_name.Size = New System.Drawing.Size(71, 15)
            Me.major_3_name.TabIndex = 22
            Me.major_3_name.Text = "Itemname"
            '
            'minor_3_pic
            '
            Me.minor_3_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.minor_3_pic.Location = New System.Drawing.Point(581, 190)
            Me.minor_3_pic.Name = "minor_3_pic"
            Me.minor_3_pic.Size = New System.Drawing.Size(56, 56)
            Me.minor_3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.minor_3_pic.TabIndex = 27
            Me.minor_3_pic.TabStop = False
            '
            'minor_3_name
            '
            Me.minor_3_name.AutoSize = True
            Me.minor_3_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.minor_3_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.minor_3_name.ForeColor = System.Drawing.Color.Black
            Me.minor_3_name.Location = New System.Drawing.Point(643, 190)
            Me.minor_3_name.Name = "minor_3_name"
            Me.minor_3_name.Size = New System.Drawing.Size(71, 15)
            Me.minor_3_name.TabIndex = 28
            Me.minor_3_name.Text = "Itemname"
            '
            'minor_2_pic
            '
            Me.minor_2_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.minor_2_pic.Location = New System.Drawing.Point(581, 128)
            Me.minor_2_pic.Name = "minor_2_pic"
            Me.minor_2_pic.Size = New System.Drawing.Size(56, 56)
            Me.minor_2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.minor_2_pic.TabIndex = 25
            Me.minor_2_pic.TabStop = False
            '
            'minor_2_name
            '
            Me.minor_2_name.AutoSize = True
            Me.minor_2_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.minor_2_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.minor_2_name.ForeColor = System.Drawing.Color.Black
            Me.minor_2_name.Location = New System.Drawing.Point(643, 128)
            Me.minor_2_name.Name = "minor_2_name"
            Me.minor_2_name.Size = New System.Drawing.Size(71, 15)
            Me.minor_2_name.TabIndex = 26
            Me.minor_2_name.Text = "Itemname"
            '
            'minor_1_pic
            '
            Me.minor_1_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.minor_1_pic.Location = New System.Drawing.Point(581, 66)
            Me.minor_1_pic.Name = "minor_1_pic"
            Me.minor_1_pic.Size = New System.Drawing.Size(56, 56)
            Me.minor_1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.minor_1_pic.TabIndex = 23
            Me.minor_1_pic.TabStop = False
            '
            'minor_1_name
            '
            Me.minor_1_name.AutoSize = True
            Me.minor_1_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.minor_1_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.minor_1_name.ForeColor = System.Drawing.Color.Black
            Me.minor_1_name.Location = New System.Drawing.Point(643, 66)
            Me.minor_1_name.Name = "minor_1_name"
            Me.minor_1_name.Size = New System.Drawing.Size(71, 15)
            Me.minor_1_name.TabIndex = 24
            Me.minor_1_name.Text = "Itemname"
            '
            'sec_minor_3_pic
            '
            Me.sec_minor_3_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.sec_minor_3_pic.Location = New System.Drawing.Point(577, 448)
            Me.sec_minor_3_pic.Name = "sec_minor_3_pic"
            Me.sec_minor_3_pic.Size = New System.Drawing.Size(56, 56)
            Me.sec_minor_3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.sec_minor_3_pic.TabIndex = 48
            Me.sec_minor_3_pic.TabStop = False
            '
            'sec_minor_3_name
            '
            Me.sec_minor_3_name.AutoSize = True
            Me.sec_minor_3_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.sec_minor_3_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.sec_minor_3_name.ForeColor = System.Drawing.Color.Black
            Me.sec_minor_3_name.Location = New System.Drawing.Point(639, 448)
            Me.sec_minor_3_name.Name = "sec_minor_3_name"
            Me.sec_minor_3_name.Size = New System.Drawing.Size(71, 15)
            Me.sec_minor_3_name.TabIndex = 49
            Me.sec_minor_3_name.Text = "Itemname"
            '
            'sec_minor_2_pic
            '
            Me.sec_minor_2_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.sec_minor_2_pic.Location = New System.Drawing.Point(577, 386)
            Me.sec_minor_2_pic.Name = "sec_minor_2_pic"
            Me.sec_minor_2_pic.Size = New System.Drawing.Size(56, 56)
            Me.sec_minor_2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.sec_minor_2_pic.TabIndex = 46
            Me.sec_minor_2_pic.TabStop = False
            '
            'sec_minor_2_name
            '
            Me.sec_minor_2_name.AutoSize = True
            Me.sec_minor_2_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.sec_minor_2_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.sec_minor_2_name.ForeColor = System.Drawing.Color.Black
            Me.sec_minor_2_name.Location = New System.Drawing.Point(639, 386)
            Me.sec_minor_2_name.Name = "sec_minor_2_name"
            Me.sec_minor_2_name.Size = New System.Drawing.Size(71, 15)
            Me.sec_minor_2_name.TabIndex = 47
            Me.sec_minor_2_name.Text = "Itemname"
            '
            'sec_minor_1_pic
            '
            Me.sec_minor_1_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.sec_minor_1_pic.Location = New System.Drawing.Point(577, 324)
            Me.sec_minor_1_pic.Name = "sec_minor_1_pic"
            Me.sec_minor_1_pic.Size = New System.Drawing.Size(56, 56)
            Me.sec_minor_1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.sec_minor_1_pic.TabIndex = 44
            Me.sec_minor_1_pic.TabStop = False
            '
            'sec_minor_1_name
            '
            Me.sec_minor_1_name.AutoSize = True
            Me.sec_minor_1_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.sec_minor_1_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.sec_minor_1_name.ForeColor = System.Drawing.Color.Black
            Me.sec_minor_1_name.Location = New System.Drawing.Point(639, 324)
            Me.sec_minor_1_name.Name = "sec_minor_1_name"
            Me.sec_minor_1_name.Size = New System.Drawing.Size(71, 15)
            Me.sec_minor_1_name.TabIndex = 45
            Me.sec_minor_1_name.Text = "Itemname"
            '
            'sec_major_3_pic
            '
            Me.sec_major_3_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.sec_major_3_pic.Location = New System.Drawing.Point(309, 448)
            Me.sec_major_3_pic.Name = "sec_major_3_pic"
            Me.sec_major_3_pic.Size = New System.Drawing.Size(56, 56)
            Me.sec_major_3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.sec_major_3_pic.TabIndex = 42
            Me.sec_major_3_pic.TabStop = False
            '
            'sec_major_3_name
            '
            Me.sec_major_3_name.AutoSize = True
            Me.sec_major_3_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.sec_major_3_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.sec_major_3_name.ForeColor = System.Drawing.Color.Black
            Me.sec_major_3_name.Location = New System.Drawing.Point(371, 448)
            Me.sec_major_3_name.Name = "sec_major_3_name"
            Me.sec_major_3_name.Size = New System.Drawing.Size(71, 15)
            Me.sec_major_3_name.TabIndex = 43
            Me.sec_major_3_name.Text = "Itemname"
            '
            'sec_major_2_pic
            '
            Me.sec_major_2_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.sec_major_2_pic.Location = New System.Drawing.Point(309, 386)
            Me.sec_major_2_pic.Name = "sec_major_2_pic"
            Me.sec_major_2_pic.Size = New System.Drawing.Size(56, 56)
            Me.sec_major_2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.sec_major_2_pic.TabIndex = 40
            Me.sec_major_2_pic.TabStop = False
            '
            'sec_major_2_name
            '
            Me.sec_major_2_name.AutoSize = True
            Me.sec_major_2_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.sec_major_2_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.sec_major_2_name.ForeColor = System.Drawing.Color.Black
            Me.sec_major_2_name.Location = New System.Drawing.Point(371, 386)
            Me.sec_major_2_name.Name = "sec_major_2_name"
            Me.sec_major_2_name.Size = New System.Drawing.Size(71, 15)
            Me.sec_major_2_name.TabIndex = 41
            Me.sec_major_2_name.Text = "Itemname"
            '
            'sec_major_1_pic
            '
            Me.sec_major_1_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.sec_major_1_pic.Location = New System.Drawing.Point(309, 324)
            Me.sec_major_1_pic.Name = "sec_major_1_pic"
            Me.sec_major_1_pic.Size = New System.Drawing.Size(56, 56)
            Me.sec_major_1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.sec_major_1_pic.TabIndex = 38
            Me.sec_major_1_pic.TabStop = False
            '
            'sec_major_1_name
            '
            Me.sec_major_1_name.AutoSize = True
            Me.sec_major_1_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.sec_major_1_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.sec_major_1_name.ForeColor = System.Drawing.Color.Black
            Me.sec_major_1_name.Location = New System.Drawing.Point(371, 324)
            Me.sec_major_1_name.Name = "sec_major_1_name"
            Me.sec_major_1_name.Size = New System.Drawing.Size(71, 15)
            Me.sec_major_1_name.TabIndex = 39
            Me.sec_major_1_name.Text = "Itemname"
            '
            'sec_prim_3_pic
            '
            Me.sec_prim_3_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.sec_prim_3_pic.Location = New System.Drawing.Point(25, 448)
            Me.sec_prim_3_pic.Name = "sec_prim_3_pic"
            Me.sec_prim_3_pic.Size = New System.Drawing.Size(56, 56)
            Me.sec_prim_3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.sec_prim_3_pic.TabIndex = 36
            Me.sec_prim_3_pic.TabStop = False
            '
            'sec_prim_3_name
            '
            Me.sec_prim_3_name.AutoSize = True
            Me.sec_prim_3_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.sec_prim_3_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.sec_prim_3_name.ForeColor = System.Drawing.Color.Black
            Me.sec_prim_3_name.Location = New System.Drawing.Point(87, 448)
            Me.sec_prim_3_name.Name = "sec_prim_3_name"
            Me.sec_prim_3_name.Size = New System.Drawing.Size(71, 15)
            Me.sec_prim_3_name.TabIndex = 37
            Me.sec_prim_3_name.Text = "Itemname"
            '
            'sec_prim_2_pic
            '
            Me.sec_prim_2_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.sec_prim_2_pic.Location = New System.Drawing.Point(25, 386)
            Me.sec_prim_2_pic.Name = "sec_prim_2_pic"
            Me.sec_prim_2_pic.Size = New System.Drawing.Size(56, 56)
            Me.sec_prim_2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.sec_prim_2_pic.TabIndex = 34
            Me.sec_prim_2_pic.TabStop = False
            '
            'sec_prim_2_name
            '
            Me.sec_prim_2_name.AutoSize = True
            Me.sec_prim_2_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.sec_prim_2_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.sec_prim_2_name.ForeColor = System.Drawing.Color.Black
            Me.sec_prim_2_name.Location = New System.Drawing.Point(87, 386)
            Me.sec_prim_2_name.Name = "sec_prim_2_name"
            Me.sec_prim_2_name.Size = New System.Drawing.Size(71, 15)
            Me.sec_prim_2_name.TabIndex = 35
            Me.sec_prim_2_name.Text = "Itemname"
            '
            'sec_prim_1_pic
            '
            Me.sec_prim_1_pic.Cursor = System.Windows.Forms.Cursors.Hand
            Me.sec_prim_1_pic.Location = New System.Drawing.Point(25, 324)
            Me.sec_prim_1_pic.Name = "sec_prim_1_pic"
            Me.sec_prim_1_pic.Size = New System.Drawing.Size(56, 56)
            Me.sec_prim_1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.sec_prim_1_pic.TabIndex = 29
            Me.sec_prim_1_pic.TabStop = False
            '
            'Label12
            '
            Me.Label12.AutoSize = True
            Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label12.ForeColor = System.Drawing.Color.Black
            Me.Label12.Location = New System.Drawing.Point(573, 291)
            Me.Label12.Name = "Label12"
            Me.Label12.Size = New System.Drawing.Size(53, 20)
            Me.Label12.TabIndex = 33
            Me.Label12.Text = "Minor"
            '
            'Label13
            '
            Me.Label13.AutoSize = True
            Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label13.ForeColor = System.Drawing.Color.Black
            Me.Label13.Location = New System.Drawing.Point(21, 291)
            Me.Label13.Name = "Label13"
            Me.Label13.Size = New System.Drawing.Size(54, 20)
            Me.Label13.TabIndex = 32
            Me.Label13.Text = "Prime"
            '
            'Label14
            '
            Me.Label14.AutoSize = True
            Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Label14.ForeColor = System.Drawing.Color.Black
            Me.Label14.Location = New System.Drawing.Point(305, 291)
            Me.Label14.Name = "Label14"
            Me.Label14.Size = New System.Drawing.Size(53, 20)
            Me.Label14.TabIndex = 31
            Me.Label14.Text = "Major"
            '
            'sec_prim_1_name
            '
            Me.sec_prim_1_name.AutoSize = True
            Me.sec_prim_1_name.Cursor = System.Windows.Forms.Cursors.IBeam
            Me.sec_prim_1_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.sec_prim_1_name.ForeColor = System.Drawing.Color.Black
            Me.sec_prim_1_name.Location = New System.Drawing.Point(87, 324)
            Me.sec_prim_1_name.Name = "sec_prim_1_name"
            Me.sec_prim_1_name.Size = New System.Drawing.Size(71, 15)
            Me.sec_prim_1_name.TabIndex = 30
            Me.sec_prim_1_name.Text = "Itemname"
            '
            'changepanel
            '
            Me.changepanel.BackColor = System.Drawing.Color.Transparent
            Me.changepanel.Controls.Add(Me.PictureBox2)
            Me.changepanel.Controls.Add(Me.PictureBox1)
            Me.changepanel.Controls.Add(Me.TextBox1)
            Me.changepanel.Location = New System.Drawing.Point(1095, 364)
            Me.changepanel.Name = "changepanel"
            Me.changepanel.Size = New System.Drawing.Size(133, 24)
            Me.changepanel.TabIndex = 174
            '
            'PictureBox2
            '
            Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
            Me.PictureBox2.Image = Global.NamCore_Studio.My.Resources.Resources.trash__delete__16x16
            Me.PictureBox2.Location = New System.Drawing.Point(113, 4)
            Me.PictureBox2.Name = "PictureBox2"
            Me.PictureBox2.Size = New System.Drawing.Size(16, 16)
            Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.PictureBox2.TabIndex = 175
            Me.PictureBox2.TabStop = False
            '
            'PictureBox1
            '
            Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
            Me.PictureBox1.Image = Global.NamCore_Studio.My.Resources.Resources.Refresh_icon
            Me.PictureBox1.Location = New System.Drawing.Point(93, 4)
            Me.PictureBox1.Name = "PictureBox1"
            Me.PictureBox1.Size = New System.Drawing.Size(16, 16)
            Me.PictureBox1.TabIndex = 174
            Me.PictureBox1.TabStop = False
            '
            'TextBox1
            '
            Me.TextBox1.Location = New System.Drawing.Point(3, 2)
            Me.TextBox1.Name = "TextBox1"
            Me.TextBox1.Size = New System.Drawing.Size(86, 20)
            Me.TextBox1.TabIndex = 0
            '
            'addpanel
            '
            Me.addpanel.BackColor = System.Drawing.Color.Transparent
            Me.addpanel.Controls.Add(Me.PictureBox4)
            Me.addpanel.Controls.Add(Me.TextBox2)
            Me.addpanel.Location = New System.Drawing.Point(1095, 394)
            Me.addpanel.Name = "addpanel"
            Me.addpanel.Size = New System.Drawing.Size(118, 24)
            Me.addpanel.TabIndex = 175
            '
            'PictureBox4
            '
            Me.PictureBox4.Cursor = System.Windows.Forms.Cursors.Hand
            Me.PictureBox4.Image = Global.NamCore_Studio.My.Resources.Resources.plusico
            Me.PictureBox4.Location = New System.Drawing.Point(94, 4)
            Me.PictureBox4.Name = "PictureBox4"
            Me.PictureBox4.Size = New System.Drawing.Size(16, 16)
            Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.PictureBox4.TabIndex = 174
            Me.PictureBox4.TabStop = False
            '
            'TextBox2
            '
            Me.TextBox2.Location = New System.Drawing.Point(3, 2)
            Me.TextBox2.Name = "TextBox2"
            Me.TextBox2.Size = New System.Drawing.Size(86, 20)
            Me.TextBox2.TabIndex = 0
            '
            'glyph_panel
            '
            Me.glyph_panel.BackColor = System.Drawing.Color.Transparent
            Me.glyph_panel.BackgroundImage = Global.NamCore_Studio.My.Resources.Resources.glyphs_bg
            Me.glyph_panel.Controls.Add(Me.Label2)
            Me.glyph_panel.Controls.Add(Me.prim_1_name)
            Me.glyph_panel.Controls.Add(Me.Label1)
            Me.glyph_panel.Controls.Add(Me.sec_minor_3_pic)
            Me.glyph_panel.Controls.Add(Me.Label3)
            Me.glyph_panel.Controls.Add(Me.sec_minor_3_name)
            Me.glyph_panel.Controls.Add(Me.prim_1_pic)
            Me.glyph_panel.Controls.Add(Me.sec_minor_2_pic)
            Me.glyph_panel.Controls.Add(Me.prim_2_name)
            Me.glyph_panel.Controls.Add(Me.sec_minor_2_name)
            Me.glyph_panel.Controls.Add(Me.prim_2_pic)
            Me.glyph_panel.Controls.Add(Me.sec_minor_1_pic)
            Me.glyph_panel.Controls.Add(Me.prim_3_name)
            Me.glyph_panel.Controls.Add(Me.sec_minor_1_name)
            Me.glyph_panel.Controls.Add(Me.prim_3_pic)
            Me.glyph_panel.Controls.Add(Me.sec_major_3_pic)
            Me.glyph_panel.Controls.Add(Me.major_1_name)
            Me.glyph_panel.Controls.Add(Me.sec_major_3_name)
            Me.glyph_panel.Controls.Add(Me.major_1_pic)
            Me.glyph_panel.Controls.Add(Me.sec_major_2_pic)
            Me.glyph_panel.Controls.Add(Me.major_2_name)
            Me.glyph_panel.Controls.Add(Me.sec_major_2_name)
            Me.glyph_panel.Controls.Add(Me.major_2_pic)
            Me.glyph_panel.Controls.Add(Me.sec_major_1_pic)
            Me.glyph_panel.Controls.Add(Me.major_3_name)
            Me.glyph_panel.Controls.Add(Me.sec_major_1_name)
            Me.glyph_panel.Controls.Add(Me.major_3_pic)
            Me.glyph_panel.Controls.Add(Me.sec_prim_3_pic)
            Me.glyph_panel.Controls.Add(Me.minor_1_name)
            Me.glyph_panel.Controls.Add(Me.sec_prim_3_name)
            Me.glyph_panel.Controls.Add(Me.minor_1_pic)
            Me.glyph_panel.Controls.Add(Me.sec_prim_2_pic)
            Me.glyph_panel.Controls.Add(Me.minor_2_name)
            Me.glyph_panel.Controls.Add(Me.sec_prim_2_name)
            Me.glyph_panel.Controls.Add(Me.minor_2_pic)
            Me.glyph_panel.Controls.Add(Me.sec_prim_1_pic)
            Me.glyph_panel.Controls.Add(Me.minor_3_name)
            Me.glyph_panel.Controls.Add(Me.Label12)
            Me.glyph_panel.Controls.Add(Me.minor_3_pic)
            Me.glyph_panel.Controls.Add(Me.Label13)
            Me.glyph_panel.Controls.Add(Me.sec_prim_1_name)
            Me.glyph_panel.Controls.Add(Me.Label14)
            Me.glyph_panel.Location = New System.Drawing.Point(8, 84)
            Me.glyph_panel.Name = "glyph_panel"
            Me.glyph_panel.Size = New System.Drawing.Size(859, 516)
            Me.glyph_panel.TabIndex = 176
            '
            'GlyphsInterface
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackgroundImage = Global.NamCore_Studio.My.Resources.Resources.HUD_bg
            Me.ClientSize = New System.Drawing.Size(872, 603)
            Me.Controls.Add(Me.addpanel)
            Me.Controls.Add(Me.changepanel)
            Me.Controls.Add(Me.glyph_panel)
            Me.Cursor = System.Windows.Forms.Cursors.Default
            Me.DoubleBuffered = True
            Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
            Me.Name = "GlyphsInterface"
            Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
            Me.Text = "Glyphs_interface"
            Me.Controls.SetChildIndex(Me.glyph_panel, 0)
            Me.Controls.SetChildIndex(Me.changepanel, 0)
            Me.Controls.SetChildIndex(Me.addpanel, 0)
            CType(Me.prim_1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.prim_2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.prim_3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.major_1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.major_2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.major_3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.minor_3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.minor_2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.minor_1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.sec_minor_3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.sec_minor_2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.sec_minor_1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.sec_major_3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.sec_major_2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.sec_major_1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.sec_prim_3_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.sec_prim_2_pic, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.sec_prim_1_pic, System.ComponentModel.ISupportInitialize).EndInit()
            Me.changepanel.ResumeLayout(False)
            Me.changepanel.PerformLayout()
            CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
            Me.addpanel.ResumeLayout(False)
            Me.addpanel.PerformLayout()
            CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
            Me.glyph_panel.ResumeLayout(False)
            Me.glyph_panel.PerformLayout()
            Me.ResumeLayout(False)

        End Sub
        Friend WithEvents prim_1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents prim_1_name As System.Windows.Forms.Label
        Friend WithEvents Label1 As System.Windows.Forms.Label
        Friend WithEvents Label2 As System.Windows.Forms.Label
        Friend WithEvents Label3 As System.Windows.Forms.Label
        Friend WithEvents prim_2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents prim_2_name As System.Windows.Forms.Label
        Friend WithEvents prim_3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents prim_3_name As System.Windows.Forms.Label
        Friend WithEvents major_1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents major_1_name As System.Windows.Forms.Label
        Friend WithEvents major_2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents major_2_name As System.Windows.Forms.Label
        Friend WithEvents major_3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents major_3_name As System.Windows.Forms.Label
        Friend WithEvents minor_3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents minor_3_name As System.Windows.Forms.Label
        Friend WithEvents minor_2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents minor_2_name As System.Windows.Forms.Label
        Friend WithEvents minor_1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents minor_1_name As System.Windows.Forms.Label
        Friend WithEvents sec_minor_3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents sec_minor_3_name As System.Windows.Forms.Label
        Friend WithEvents sec_minor_2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents sec_minor_2_name As System.Windows.Forms.Label
        Friend WithEvents sec_minor_1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents sec_minor_1_name As System.Windows.Forms.Label
        Friend WithEvents sec_major_3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents sec_major_3_name As System.Windows.Forms.Label
        Friend WithEvents sec_major_2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents sec_major_2_name As System.Windows.Forms.Label
        Friend WithEvents sec_major_1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents sec_major_1_name As System.Windows.Forms.Label
        Friend WithEvents sec_prim_3_pic As System.Windows.Forms.PictureBox
        Friend WithEvents sec_prim_3_name As System.Windows.Forms.Label
        Friend WithEvents sec_prim_2_pic As System.Windows.Forms.PictureBox
        Friend WithEvents sec_prim_2_name As System.Windows.Forms.Label
        Friend WithEvents sec_prim_1_pic As System.Windows.Forms.PictureBox
        Friend WithEvents Label12 As System.Windows.Forms.Label
        Friend WithEvents Label13 As System.Windows.Forms.Label
        Friend WithEvents Label14 As System.Windows.Forms.Label
        Friend WithEvents sec_prim_1_name As System.Windows.Forms.Label
        Friend WithEvents changepanel As System.Windows.Forms.Panel
        Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
        Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
        Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
        Friend WithEvents addpanel As System.Windows.Forms.Panel
        Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
        Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
        Friend WithEvents glyph_panel As System.Windows.Forms.Panel
    End Class
End Namespace