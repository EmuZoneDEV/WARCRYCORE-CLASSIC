﻿Imports System.Resources

Imports System.Reflection
Imports System.Runtime.InteropServices

' Allgemeine Informationen über eine Assembly werden über die folgenden 
' Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
' die mit einer Assembly verknüpft sind.

' Die Werte der Assemblyattribute überprüfen

<Assembly: AssemblyTitle("NamcoreDirectAccess")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("NamcoreDirectAccess")> 
<Assembly: AssemblyCopyright("Copyright ©  2015 megasus")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
<Assembly: Guid("385da9b5-cfc4-44dd-8701-855013c6321f")> 

' Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
'
'      Hauptversion
'      Nebenversion 
'      Buildnummer
'      Revision
'
' Sie können alle Werte angeben oder die standardmäßigen Build- und Revisionsnummern 
' übernehmen, indem Sie "*" eingeben:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.0.14.44")> 
<Assembly: AssemblyFileVersion("0.0.14.44")> 

<Assembly: NeutralResourcesLanguageAttribute("en-US")> 