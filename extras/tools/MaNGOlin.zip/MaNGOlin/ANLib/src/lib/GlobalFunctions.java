/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.plaf.FontUIResource;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class GlobalFunctions {

    static private GlobalFunctions _instance;
    private static final Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    private static final String VTESC = "\u001b";
    private static final String VTBELL = "\u0007";
    // Variables for General Functions
    public static final int CANCEL = 0;
    public static final int OK = 1;
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss:SS");
    private String appname = "Not Set";
    private String appver = "Not Set";
    private String company = "Not Set";
    private String homepage = "Not Set";
    private String homepagessl = "Not Set";
    private String appseries = null;
    private int intProcessIdColumn = 0;
    private String kdepreffile = null;
    private String notifyApp = null;
    private String strNotificationIconPath = null;
    private ImageIcon imgIcon = null;
    private ArrayList<String> currentprocesses = null;
    private TrayIcon trayIcon = null;

    /**
     * Class constructor
     */
    private GlobalFunctions() {
    }

    /**
     * Get instance of Globalfunctions uses singleton pattern
     *
     * @return GlobalFunctions
     */
    public static GlobalFunctions getInstance() {
        if (_instance == null) {
            synchronized (GlobalFunctions.class) {
                if (_instance == null) {
                    _instance = new GlobalFunctions();
                }
            }
        }
        return _instance;
    }

    /**
     * Convenience method for Thread sleep in milliseconds
     *
     * @param ms
     */
    public void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ex) {
        }
    }

    /**
     * Check system tray support
     *
     * @return boolean True is tray is supported
     */
    public boolean isTraySupported() {
        return SystemTray.isSupported();
    }

    public boolean isTrayLoaded() {
        return (trayIcon != null);
    }

    /**
     * Initialise our system tray functionality, convenience method
     *
     * @param guiframe
     * @param popup
     */
    public void loadSystemTray(final JFrame guiframe, PopupMenu popup) {
        loadSystemTray(guiframe, popup, null, null);
    }

    /**
     * Initialise our system tray functionality
     *
     * @param guiframe
     * @param popup
     * @param image
     * @param tooltip
     */
    public void loadSystemTray(final JFrame guiframe, PopupMenu popup, Image image, String tooltip) {

        try {
            SystemTray st = SystemTray.getSystemTray();
            if (st != null) {
                if (image == null) {
                    image = getAppIconImage();
                }
                if (tooltip == null) {
                    tooltip = getAppName() + " " + getAppVersion();
                }
                trayIcon = new TrayIcon(image, tooltip);
                trayIcon.setImageAutoSize(true);
                trayIcon.setPopupMenu(popup);
                trayIcon.addMouseListener(new java.awt.event.MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        if (e.getButton() == MouseEvent.BUTTON1) {
                            setFrameVisible(guiframe, !guiframe.isVisible());
                        }
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                    }
                });
                st.add(trayIcon);
            }
            return;
        } catch (Exception ex) {
        }
        trayIcon = null;
    }

    /**
     * Unloads any system tray
     */
    public void unloadSystemTray() {

        if (trayIcon == null) {
            return;
        }
        try {
            SystemTray st = SystemTray.getSystemTray();
            trayIcon.setPopupMenu(null);
            st.remove(trayIcon);
        } catch (Exception ex) {
        }
        trayIcon = null;
    }

    /**
     * Update the trayicon tooltip text
     *
     * @param text
     */
    public void updateTrayIcon(String text) {
        if (trayIcon == null) {
            return;
        }
        if (text.compareTo(trayIcon.getToolTip()) == 0) {
            return;
        }
        trayIcon.setToolTip(text);
    }

    /**
     * Send desktop notification
     *
     * @param text
     */
    public void desktopNotify(String text) {

        String title = getAppName() + " Notification";

        if (isWindows()) {
            if (trayIcon != null) {
                trayIcon.displayMessage(title, text, TrayIcon.MessageType.INFO);
            }
            return;
        }

        if (notifyApp == null) {
            notifyApp = findLinuxApp("notify-send");
            if (notifyApp == null) {
                notifyApp = findLinuxApp("zenity");
            }
        }
        if (notifyApp == null) {
            return;
        }

        if (notifyApp.contains("zenity")) {
            try {
                Process p = launchProcess(notifyApp + " --notification --listen");
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));
                bw.write("message:" + title + "         " + text);
                bw.close();
            } catch (Exception ex) {
            }
        }
        if (notifyApp.contains("notify-send")) {
            if (strNotificationIconPath == null) {
                launchProcess(notifyApp, "-u", "normal", title, text);
            } else {
                launchProcess(notifyApp, "-u", "normal", "-i", strNotificationIconPath, title, text);
            }
        }
    }

    public void setFrameVisible(JFrame frame, boolean visible) {
        if (visible) {
            frame.setFocusableWindowState(true);
            frame.setVisible(true);
            frame.setExtendedState(Frame.NORMAL);
            frame.toFront();
        } else {
            frame.setVisible(false);
        }
    }

    public void setFrameMinimised(JFrame frame) {
        frame.setExtendedState(Frame.ICONIFIED);
        frame.setVisible(true);
    }

    public void setFrameMaximised(JFrame frame) {
        frame.setExtendedState(Frame.MAXIMIZED_BOTH);
        frame.setVisible(true);
    }

    /**
     * Converts a resultset to a string output
     *
     * @param rs
     * @return String
     */
    public String resultSetToString(ResultSet rs) {
        StringBuilder sb = new StringBuilder();
        try {
            if (rs == null) {
                return "null";
            }
            ResultSetMetaData rsm = rs.getMetaData();
            for (int idx = 0; idx < rsm.getColumnCount(); idx++) {
                sb.append('\n');
                sb.append(rsm.getColumnLabel(idx + 1));
            }
            return sb.toString();
        } catch (Exception ex) {
        }
        return null;
    }

    /**
     * Converts objects to a string output
     *
     * @param oarray
     * @return String
     */
    public String objectsToString(Object[] oarray) {
        StringBuilder sb = new StringBuilder();
        for (Object o : oarray) {
            sb.append('\n');
            sb.append(o);
        }
        return sb.toString();
    }

    /**
     * Converts object to a string output
     *
     * @param object
     * @return String
     */
    public String objectToString(Object object) {
        StringBuilder sb = new StringBuilder();
        if (object instanceof ArrayList) {
            ArrayList al = (ArrayList) object;
            for (Object o : al) {
                sb.append('\n');
                sb.append(o);
            }
            return sb.toString();
        }
        return object.toString();
    }

    /**
     * Strip out or replace special control codes will strip out if true
     *
     * @param text
     * @param strip
     * @return String
     */
    public String stripSpecials(String text, boolean strip) {
        String temp;
        if (strip) {
            temp = text.replace(VTESC, "");
            temp = temp.replace("\r", "");
            temp = temp.replace("\n", "");
            temp = temp.replace(VTBELL, "");
            temp = temp.replace("\t", "");
        } else {
            temp = text.replace(VTESC, "{ESC}");
            temp = temp.replace("\r", "{CR}");
            temp = temp.replace("\n", "{NL}");
            temp = temp.replace(VTBELL, "{BELL}");
            temp = temp.replace("\t", "{TAB}");
            if (temp.isEmpty()) {
                temp = "{EMPTY}";
            }
        }
        return temp;
    }

    /**
     * Set notification icon file path
     *
     * @param iconpath
     */
    public void setNotificationIconPath(String iconpath) {
        strNotificationIconPath = iconpath;
    }

    /**
     * Get application icon as an Image
     *
     * @return Image
     */
    public Image getAppIconImage() {
        return imgIcon.getImage();
    }

    /**
     * Set application icon from its image icon
     *
     * @param imgicon
     */
    public void setAppIcon(ImageIcon imgicon) {
        imgIcon = imgicon;
    }

    /**
     * Set user interface fontsize adjust for dpi
     *
     * @param fontSize
     * @param dpi
     */
    public void setUIFontSize(int fontSize, int dpi) {

        UIDefaults defaults = UIManager.getLookAndFeelDefaults();
        Enumeration keys = defaults.keys();
        int intFontSize;

        Font font = new JLabel().getFont();
        if (fontSize < 0) {
            fontSize = font.getSize();
        }
        int screenDpi = Toolkit.getDefaultToolkit().getScreenResolution();
        if (dpi > 0) {
            intFontSize = (int) Math.round(fontSize * screenDpi / dpi);
        } else {
            intFontSize = fontSize;
        }
        try {
            defaults.put("defaultFont", new FontUIResource(font.getFontName(), font.getStyle(), intFontSize));
        } catch (Exception ex) {
        }
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            if ((key instanceof String) && (((String) key).endsWith(".font"))) {
                font = (Font) UIManager.get(key);
                defaults.put(key, new FontUIResource(font.getFontName(), font.getStyle(), intFontSize));
            }
        }
    }

    /**
     * Set global application name
     *
     * @param name
     */
    public void setAppName(String name) {
        appname = name;
    }

    /**
     * Get application name
     *
     * @return String
     */
    public String getAppName() {
        return appname;
    }

    /**
     * Set global application series
     *
     * @param series
     */
    public void setAppSeries(String series) {
        appseries = series;
    }

    /**
     * Get application series
     *
     * @return String
     */
    public String getAppSeries() {
        return appseries;
    }

    /**
     * Set global company name
     *
     * @param name
     */
    public void setCompanyName(String name) {
        company = name;
    }

    /**
     * Get company name
     *
     * @return String
     */
    public String getCompanyName() {
        return company;
    }

    /**
     * Set global application version
     *
     * @param version
     */
    public void setAppVersion(String version) {
        appver = version;
    }

    /**
     * Get application version
     *
     * @return String version
     */
    public String getAppVersion() {
        return appver;
    }

    /**
     * Set global application homepage
     *
     * @param url
     */
    public void setHomepage(String url) {
        homepage = url;
    }

    /**
     * Set global application secure homepage
     *
     * @param url
     */
    public void setHomepageSSL(String url) {
        homepagessl = url;
    }

    /**
     * Get application homepage
     *
     * @return String url
     */
    public String getHomepage() {
        return homepage;
    }

    /**
     * Get application secure homepage
     *
     * @return String url
     */
    public String getHomepageSSL() {
        return homepagessl;
    }

    /**
     * Convenience method to determine if String is a valid numerical value
     *
     * @param n
     * @return boolean
     */
    public boolean isNumber(String n) {
        boolean result = false;
        try {
            Double.parseDouble(n);
            result = true;
        } catch (Exception ex) {
        }
        return result;
    }

    /**
     * Opens java file chooser dialog, convenience method. Returns filepath if
     * successful and null if not
     *
     * @param parent
     * @param folder
     * @param filter Extension filter
     * @param mode Fileselection mode
     * @return String Filepath
     */
    public String openFileChooser(Frame parent, String folder, FileFilter filter, int mode) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(mode);
        fileChooser.setCurrentDirectory(new File(folder));
        if (filter != null) {
            fileChooser.addChoosableFileFilter(filter);
        }
        int intReturn = fileChooser.showOpenDialog(parent);
        if (intReturn == JFileChooser.APPROVE_OPTION) {
            return fileChooser.getSelectedFile().getAbsolutePath();
        } else {
            return null;
        }
    }

    /**
     * Test to see if supplied time is older in minutes, returns true if it is
     *
     * @param time
     * @param minutes
     * @return boolean
     */
    public boolean isMinutesOlder(long time, long minutes) {
        long lngAge = System.currentTimeMillis() - time;
        return lngAge > (60000 * minutes);
    }

    /**
     * Test to see if supplied time is older in hours, returns true if it is
     *
     * @param time
     * @param hours
     * @return boolean
     */
    public boolean isHoursOlder(long time, long hours) {
        long lngAge = System.currentTimeMillis() - time;
        return lngAge > (60000 * 60 * hours);
    }

    /**
     * Test to see if supplied time is older in days, returns true if it is
     *
     * @param time
     * @param days
     * @return boolean
     */
    public boolean isDaysOlder(long time, long days) {
        long lngAge = System.currentTimeMillis() - time;
        return lngAge > (60000 * 60 * 24 * days);
    }

    /**
     * Get date convenience method
     *
     * @return Date
     */
    @Deprecated
    public Date getDate() {
        return new Date();
    }

    /**
     * Get date as a formatted string with given format
     *
     * @param date
     * @param format
     * @return String
     */
    public String getDateAsString(Date date, String format) {

        if (format == null) {
            format = "HH:mm:ss dd/MM/yyyy";
        }
        if (date == null) {
            date = new Date();
        }
        sdf.applyPattern(format);
        return sdf.format(date);
    }

    /**
     * Get OS name, convenience method
     *
     * @return String
     */
    public String getOSName() {
        return System.getProperty("os.name").toLowerCase();
    }

    /**
     * Get OS architecture, convenience method
     *
     * @return String
     */
    public String getOSArch() {
        return System.getProperty("os.arch");
    }

    /**
     * Generic test for Windows platform
     *
     * @return boolean True if Windows
     */
    public boolean isWindows() {
        return getOSName().contains("windows");
    }

    /**
     * Specific test for Win 7
     *
     * @return boolean True if Win 7
     */
    public boolean isWin7() {
        return getOSName().startsWith("windows 7");
    }

    /**
     * Specific test for Win 8
     *
     * @return boolean True if Win 8
     */
    public boolean isWin8() {
        return getOSName().startsWith("windows 8");
    }

    /**
     * Specific test for Win 10
     *
     * @return boolean True if Win 10
     */
    public boolean isWin10() {
        return getOSName().startsWith("windows 10");
    }

    /**
     * Specific test for Win XP
     *
     * @return boolean True if Win XP
     */
    public boolean isWinXP() {
        return getOSName().contentEquals("windows");
    }

    /**
     * Generic test for Linux platform
     *
     * @return boolean True if Linux
     */
    public boolean isLinux() {
        return getOSName().contains("linux");
    }

    /**
     * Get OS version
     *
     * @return String OS version
     */
    public String getOSVersion() {
        return System.getProperty("os.version");
    }

    /**
     * Get user name
     *
     * @return String User name
     */
    public String getUserName() {
        return System.getProperty("user.name");
    }

    /**
     * Get users home folder
     *
     * @return String path to home folder
     */
    public String getUsersHomeFolder() {
        return System.getProperty("user.home");
    }

    /**
     * Get users documents folder (Windows only)
     *
     * @return String path to documents folder
     */
    public String getUsersDocFolder() {

        String strReturn = getUsersHomeFolder() + "\\Documents";
        if (isWinXP()) {
            strReturn = getUsersHomeFolder() + "\\My Documents";
        }
        return strReturn;
    }

    /**
     * Get user settings path
     *
     * @return String path to user settings folder
     */
    public String getUserSettingsPath() {

        String userSettingsPath;
        if (isWindows()) {
            userSettingsPath = getUsersHomeFolder() + "\\Application Data\\";
        } else {
            userSettingsPath = getUsersHomeFolder() + "/";
        }
        return userSettingsPath;
    }

    /**
     * Get this applications settings path, convenience method Requires that app
     * name has been set
     *
     * @return String Path to application settings folder
     */
    public String getAppSettingsPath() {
        return getAppSettingsPath(null);
    }

    /**
     * Get a specified application's settings folder, if null return this
     * applications setting folder
     *
     * @param appname Application settings folder name
     * @return String Path to the applications setting folder
     */
    public String getAppSettingsPath(String appname) {

        String appSettingsPath = getUserSettingsPath();
        if (isWindows()) {
            if (appname == null) {
                appSettingsPath += this.appname + "\\";
                if (appseries != null) {
                    appSettingsPath += appseries + "\\";
                }
            } else {
                appSettingsPath += appname + "\\";
            }
        } else {
            if (appname == null) {
                appSettingsPath += "." + this.appname + "/";
                if (appseries != null) {
                    appSettingsPath += appseries + "/";
                }
            } else {
                appSettingsPath += "." + appname + "/";
            }
        }
        return appSettingsPath;
    }

    /**
     * Get users current folder
     *
     * @return String Path to current folder
     */
    public String getUsersCurrentFolder() {
        return System.getProperty("user.dir");
    }

    /**
     * Get users temp folder
     *
     * @return String Path to users temp folder
     */
    public String getTempFolder() {
        return System.getProperty("java.io.tmpdir");
    }

    /**
     * Get the systems file path separator, varies depending on
     *
     * @return String file separator
     */
    public String getFileSeparator() {
        return File.separator;
    }

    /**
     * Generic refresh of internal list of active system processes
     */
    public void refreshActiveProcesses() {
        if (isWindows()) {
            currentprocesses = refreshActiveProcessesWindows();
        } else {
            currentprocesses = refreshActiveProcessesLinux();
        }
    }

    /**
     * Windows specific refresh or internal list of active system processes
     */
    private ArrayList<String> refreshActiveProcessesWindows() {
        String strTemp;
        ArrayList<String> arrListResults;

        try {
            logger.info("refreshActiveProcessesWindows()");
            Process processWmi = Runtime.getRuntime().exec("wmic.exe");
            OutputStreamWriter tempWriter = new OutputStreamWriter(processWmi.getOutputStream());
            tempWriter.write("process get commandline,processid");
            tempWriter.flush();
            tempWriter.close();
            arrListResults = getProcessResults(processWmi);
            strTemp = (String) arrListResults.get(1);
            intProcessIdColumn = strTemp.indexOf("ProcessId");
            // Remove our aggregate string
            arrListResults.remove(0);
            // Remove CommandLine & ProcessID
            arrListResults.remove(0);
            // Remove last entry
            arrListResults.remove(arrListResults.size() - 1);
            File cleanup = new File("TempWmicBatchFile.bat");
            cleanup.delete();
            return arrListResults;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "refreshActiveProcessesWindows()", ex);
            return null;
        }
    }

    /**
     * Linux specific refresh or internal list of active system processes
     */
    private ArrayList<String> refreshActiveProcessesLinux() {
        String strTemp;
        ArrayList<String> arrListResults;

        try {
            Process process = Runtime.getRuntime().exec("ps ax");
            arrListResults = getProcessResults(process);
            // Remove our aggregate string
            arrListResults.remove(0);
            // Remove last entry
            arrListResults.remove(arrListResults.size() - 1);
            strTemp = (String) arrListResults.get(0);
            intProcessIdColumn = strTemp.indexOf("  PID");
            return arrListResults;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "refreshActiveProcessesLinux()", ex);
            return null;
        }
    }

    /**
     * Get pid of first occurrence of the contents of filter
     *
     * @param filter
     * @return String Pid if found else null
     */
    public String getPid(String filter) {
        String[] strResult;
        Pattern pattern = Pattern.compile(" ");
        for (String s : currentprocesses) {
            if (s.contains(filter)) {
                s = s.trim().substring(intProcessIdColumn);
                strResult = pattern.split(s);
                return strResult[0];
            }
        }
        return null;
    }

    /**
     * Get no of process instances based on contents of filter
     *
     * @param filter
     * @return int Number of instances
     */
    public int getNoOfInstances(String filter) {
        int intCount = 0;
        if (currentprocesses == null) {
            return intCount;
        }
        for (String s : currentprocesses) {
            if (s.contains(filter)) {
                intCount++;
            }
        }
        return intCount;
    }

    /**
     * Kill all processes that match contents filter
     *
     * @param filter
     */
    public void killAllProcess(String filter) {
        ArrayList<String> list;
        int loopCount = 0;
        while (true) {
            if (loopCount++ > 10) {
                break;
            }
            list = findProcesses(filter);
            if (list.isEmpty()) {
                break;
            }
            for (String s : list) {
                killProcess(s);
            }
        }
    }

    /**
     * Find a specific linux application
     *
     * @param app
     * @return String path to application or null
     */
    public String findLinuxApp(String app) {

        if (isLinux()) {
            Pattern pattern = Pattern.compile(" ");
            try {
                Process process = Runtime.getRuntime().exec("whereis " + app);
                String[] results = pattern.split(getProcessResults(process).get(0));
                if (results.length > 1) {
                    return results[1].trim();
                } else {
                    return null;
                }
            } catch (Exception ex) {
            }
        }
        return null;
    }

    /**
     * Find a specific Windows application, requires a series of search paths to
     * be provided=
     *
     * @param appname
     * @param paths
     * @return String path to application or null
     */
    public String findWindowsApp(String appname, String... paths) {
        SimpleFileIO myFileIO = new SimpleFileIO();
        for (String s : paths) {
            if (myFileIO.exists(s + appname)) {
                return s + appname;
            }
        }
        return null;
    }

    /**
     * Find processes matching the contents of filter
     *
     * @param filter
     * @return ArrayList<String> of matching processes
     */
    public ArrayList<String> findProcesses(String filter) {
        String[] strResult;
        Pattern pattern = Pattern.compile(" ");
        ArrayList<String> result = new ArrayList<>();
        for (String s : currentprocesses) {
            if (s.contains(filter)) {
                s = s.trim().substring(intProcessIdColumn);
                strResult = pattern.split(s);
                result.add(strResult[0]);
            }
        }
        return result;
    }

    /**
     * Generic kill process with matching pid
     *
     * @param pid
     * @return String kill result or null if failed
     */
    public String killProcess(String pid) {
        if (isWindows()) {
            return killProcessWindows(pid);
        }
        if (isLinux()) {
            return killProcessLinux(pid);
        }
        return null;
    }

    /**
     * Windows specific kill process with matching pid
     *
     * @param pid
     * @return String kill result or null if failed
     */
    private String killProcessWindows(String pid) {
        Process processKill;
        try {
            processKill = Runtime.getRuntime().exec("taskkill /pid " + pid);
            return getProcessResult(processKill);
        } catch (IOException ex) {
            logger.throwing(this.getClass().getName(), "killProcessWindows(int pid) taskkill", ex);
        }
        try {
            processKill = Runtime.getRuntime().exec("tskill " + pid);
            return getProcessResult(processKill);
        } catch (IOException ex) {
            logger.throwing(this.getClass().getName(), "killProcessWindows(int pid) tskill", ex);
        }
        return null;
    }

    /**
     * Linux specific specific kill process with matching pid
     *
     * @param pid
     * @return String kill result or null if failed
     */
    private String killProcessLinux(String pid) {
        Process processKill = null;
        try {
            processKill = Runtime.getRuntime().exec("kill -9 " + pid);
        } catch (IOException ex) {
            logger.throwing(this.getClass().getName(), "killProcessLinux(String pid)", ex);
        }
        return getProcessResult(processKill);
    }

    /**
     * Set a files hidden status (Windows only)
     *
     * @param filepath Path to file includes filename
     * @param hidden True/False
     */
    public void setFileHidden(String filepath, boolean hidden) {

        if (isWindows()) {
            try {
                if (hidden) {
                    Runtime.getRuntime().exec("Attrib.exe +H " + filepath).waitFor();
                } else {
                    Runtime.getRuntime().exec("Attrib.exe -H " + filepath).waitFor();
                }
            } catch (IOException | InterruptedException ex) {
                logger.throwing(this.getClass().getName(), "setFileHidden(" + filepath + ")", ex);
            }
        }
    }

    /**
     * Test for Gconftool installed (Linux only)
     *
     * @return String path to gconftool
     */
    public String isGconfInstalled() {
        // Verify if gsettings is installed then if needs verify dconf
        return findLinuxApp("gconftool");
    }

    /**
     * Test if gsettings installed (Linux only)
     *
     * @return String path to gsetttings
     */
    public String isGsettingsInstalled() {
        // Verify if gsettings is installed then if needs verify dconf
        return findLinuxApp("gsettings");
    }

    /**
     * Test if Dconf is installed (Linux only)
     *
     * @return String path to dconf
     */
    public String isDconfInstalled() {
        // Verify if dconf is installed then if needs verify dconf
        return findLinuxApp("dconf");
    }

    /**
     * Test for notify-send (libnotify) is installed (Linux only)
     *
     * @return String path to notify-send
     */
    public String isLibNotifyInstalled() {
        return findLinuxApp("notify-send");
    }

    public String findAfterString(String astring, String search) {
        try {
            return astring.substring(astring.indexOf(search) + search.length());
        } catch (Exception ex) {
            return null;
        }
    }

    public String findBetweenString(String astring, String search1, String search2) {
        try {
            astring = findAfterString(astring, search1);
            return astring.substring(0, astring.indexOf(search2));
        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * Convenience method to get the first resultant output of an executed
     * process as a String
     *
     * @param aprocess
     * @return String Process result
     */
    public String getProcessResult(Process aprocess) {
        if (aprocess == null) {
            return null;
        }
        return (String) getProcessResults(aprocess, null, null).get(0);
    }

    /**
     * Get the first resultant output of an executed process using exitOK or
     * exitFail matches to abort. Use null's for exitOK/exitFail to let process
     * come to a natural conclusion
     *
     * @param aprocess
     * @param exitOK
     * @param exitFail
     * @return String Process result
     */
    public String getProcessResult(Process aprocess, String exitOK, String exitFail) {
        if (aprocess == null) {
            return null;
        }
        return (String) getProcessResults(aprocess, exitOK, exitFail).get(0);
    }

    /**
     * Convenience method to obtain all output of an executed process.
     *
     * @param aprocess
     * @return ArrayList<String> List of Strings containing all generated output
     */
    public ArrayList<String> getProcessResults(Process aprocess) {
        return getProcessResults(aprocess, null, null);
    }

    /**
     * Obtain all output of an executed process. using exitOK or exitFail
     * matches to abort. Use null's for exitOK/exitFail to let process come to a
     * natural conclusion
     *
     * @param aprocess
     * @param exitOK
     * @param exitFail
     * @return ArrayList<String> List of Strings containing all generated output
     */
    public ArrayList<String> getProcessResults(Process aprocess, String exitOK, String exitFail) {

        String results = "";
        String line;
        ArrayList<String> arrList = new ArrayList<>();

        arrList.add(results);
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(aprocess.getInputStream()));
            while ((line = input.readLine()) != null) {
                if (line.isEmpty()) {
                    continue;
                }
                arrList.add(line);
                results += (line + "\n");
                if (exitOK != null) {
                    if (line.contains(exitOK)) {
                        break;
                    }
                }
                if (exitFail != null) {
                    if (line.contains(exitFail)) {
                        input.close();
                        return null;
                    }
                }
            }
            input.close();
            arrList.set(0, results);
            return arrList;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getResultsList(Process aprocess, String exitOK, String exitFail)", ex);
            return null;
        }
    }

    /**
     * Retrieve an image from a specified image file
     *
     * @param filepath
     * @return Image
     */
    public Image getImageFromFile(String filepath) {

        try {
            BufferedImage bi = ImageIO.read(new File(filepath));
            return bi.getScaledInstance(bi.getWidth(), bi.getHeight(), Image.SCALE_DEFAULT);
        } catch (Exception ex) {
        }
        return null;
    }

    /**
     * Retrieve text from a resource text file
     *
     * @param resourcepath
     * @return String text
     */
    public String getTextResource(String resourcepath) {
        SimpleFileIO sfio = new SimpleFileIO();
        String text = "";
        try {
            sfio.openBufferedRead(getClass().getResource(resourcepath).openStream());
            text = sfio.readEntireFile();
            sfio.closeBufferedRead();
        } catch (Exception ex) {
        }
        return text;
    }

    /**
     * Copy a text resource file to a file
     *
     * @param resourcepath
     * @param destfolder
     * @param overwrite
     */
    public void copyTextResource(String resourcepath, String destfolder, boolean overwrite) {
        SimpleFileIO sfio = new SimpleFileIO();
        try {
            sfio.createFolder(destfolder);
            sfio.setReadFilename(resourcepath);
            sfio.openBufferedRead(getClass().getResource(resourcepath).openStream());
            sfio.setWriteFilename(destfolder + File.separator + sfio.getReadFile().getName());
            if (!sfio.getWriteFile().exists() || overwrite) {
                sfio.openBufferedWrite();
                sfio.writeToFile(sfio.readEntireFile(), 0);
                sfio.closeBufferedWrite();
            }
            sfio.closeBufferedRead();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "copyTextResource", ex);
        }
    }

    /**
     * Create a Linux desktop shortcut
     *
     * @param name
     * @param scriptPath
     * @param iconPath
     * @param destPath
     */
    public void createLinuxShortcut(String name, String scriptPath, String iconPath, String destPath) {
        SimpleFileIO sfio = new SimpleFileIO();
        try {
            // Ensure destination folder exists, if it doesnt then create it.
            if (!sfio.exists(getUsersHomeFolder() + "/" + destPath)) {
                sfio.createFolder(getUsersHomeFolder() + "/" + destPath);
            }
            sfio.setWriteFilename(getUsersHomeFolder() + "/" + destPath + "/" + name + ".desktop");
            sfio.deleteWriteFile();
            sfio.openBufferedAppend();
            sfio.writeToFile("[Desktop Entry]", 1);
            sfio.writeToFile("Name=" + name, 1);
            sfio.writeToFile("Name[en]=" + name, 1);
            sfio.writeToFile("Exec=" + scriptPath, 1);
            sfio.writeToFile("Icon=" + iconPath, 1);
            sfio.writeToFile("Terminal=false", 1);
            sfio.writeToFile("StartupNotify=false", 1);
            sfio.writeToFile("Encoding=UTF-8", 1);
            sfio.writeToFile("Type=Application", 1);
            sfio.closeBufferedWrite();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "createLinuxShortcut", ex);
        }
    }

    /**
     * Launch an external process with arguments
     *
     * @param commands
     * @return Process
     */
    public Process launchProcess(String... commands) {
        try {
            if (commands.length == 1) {
                return Runtime.getRuntime().exec(commands[0].trim());
            } else {
                return Runtime.getRuntime().exec(commands);
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "launchProcess", ex);
        }
        return null;
    }

    /**
     * Open the desktop default file editor
     *
     * @param path Path to file
     */
    public void editFile(String path) {
        if (isLinux()) {
            launchProcess("xdg-open " + path);
        }
        if (isWindows()) {
            launchProcess("notepad " + path);
        }
    }

    /**
     * Check web for updates and return version string if an update is available
     *
     * @param sourceurl URL to check
     * @return String new version number
     */
    public String checkWebForAppUpdates(String sourceurl) {

        NetFunctions nf = new NetFunctions();
        BufferedReader br;
        String appVersion;

        try {
            br = nf.createURLReader(nf.createConnectionToURL(sourceurl, null, 10000));
            if (br == null) {
                return null;
            }
            appVersion = br.readLine();

            // Check for new application.
            if (appVersion != null && !appVersion.isEmpty()) {
                if (convertVersionToFloat(appVersion) > convertVersionToFloat(appver)) {
                    return appVersion;
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    /**
     * Check for a newer remote file, returns true if file is newer
     *
     *
     * @param remoteurl
     * @param localfile
     * @return boolean True if remote is newer
     */
    public boolean checkWebForNewerFile(String remoteurl, String localfile) {
        NetFunctions nf = new NetFunctions();
        try {
            URLConnection uconn = nf.createConnectionToURL(remoteurl, null, 1000);
            File f = new File(localfile);
            return (uconn.getLastModified() > f.lastModified());
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "checkWebForNewerFile", ex);
        }
        return false;
    }

    /**
     * Convert an application version number into a number
     *
     * @param version
     * @return Float version
     */
    private float convertVersionToFloat(String version) {

        int c;
        float f;
        version = version.toLowerCase();
        if (version.startsWith("v")) {
            version = version.substring(1);
        }
        c = (int) version.charAt(version.length() - 1);
        if (c > 96) {
            version = version.substring(0, version.length() - 1);
            f = Float.parseFloat(version) + Float.parseFloat(String.valueOf(c - 96)) / 100;
        } else {
            f = Float.parseFloat(version);
        }
        return f;
    }

    /**
     * Launch the desktops default web browser
     *
     * @param strUrl
     */
    public void launchBrowser(String strUrl) {

        if (strUrl == null) {
            return;
        }
        if (isLinux()) {
            launchProcess("xdg-open " + strUrl);
            return;
        }
        Desktop deskSupport;
        if (Desktop.isDesktopSupported()) {
            deskSupport = Desktop.getDesktop();
            try {
                deskSupport.browse(new URI(strUrl));
            } catch (URISyntaxException | IOException ex) {
                logger.throwing(this.getClass().getName(), "launchBrowser", ex);
            }
        }
    }

    /**
     * Gets a keys value, from keydata in the form of key=value
     *
     * @param keydata
     * @param delim
     * @return String value
     */
    public String getKeyValue(String keydata, String delim) {
        String[] result = keydata.split(delim);
        if (result.length > 1) {
            return result[1];
        } else {
            return null;
        }
    }

    /**
     * Get gnome 3 preference using schema name and key name
     *
     * @param schema
     * @param key
     * @return String preference value
     */
    public String getGnome3Pref(String schema, String key) {
        String result = getProcessResult(launchProcess("gsettings get " + schema + " " + key));
        if (result != null) {
            result = result.trim();
            result = result.replace("'", "");
        }
        return result;
    }

    /**
     * Set a gnome 3 boolean value using schema name and key name
     *
     * @param schema
     * @param key
     * @param value
     */
    public void setGnome3Pref(String schema, String key, boolean value) {
        launchProcess("gsettings set " + schema + " " + key + " '" + String.valueOf(value) + "'");
    }

    /**
     * Set a gnome 3 string value using schema name and key name
     *
     * @param schema
     * @param key
     * @param value
     */
    public void setGnome3Pref(String schema, String key, String value) {
        if (value.isEmpty()) {
            launchProcess("gsettings set " + schema + " " + key + " ''");
        } else {
            launchProcess("gsettings set " + schema + " " + key + " '" + value + "'");
        }
    }

    /**
     * Get a gnome 2 string preference value using keyname
     *
     * @param key
     * @return String Preference value
     */
    public String getGnome2Pref(String key) {
        String result = getProcessResult(launchProcess("gconftool -g " + key));
        if (result != null) {
            result = result.trim();
        }
        return result;
    }

    /**
     * Get gnome 2 sub preferences using key name
     *
     * @param key
     * @return ArrayList<String> A list of sub prefs
     */
    public ArrayList<String> getGnome2SubPrefs(String key) {
        ArrayList<String> list = getProcessResults(launchProcess("gconftool -R " + key));
        list.remove(0);
        return list;
    }

    /**
     * Set a gnome 2 string preference value using key name
     *
     * @param key
     * @param value
     */
    public void setGnome2Pref(String key, String value) {
        if (value.isEmpty()) {
            launchProcess("gconftool -u " + key);
        } else {
            launchProcess("gconftool -s " + key + " -t string " + value);
        }
    }

    /**
     * Set a gnome 2 boolean preference value using key name
     *
     * @param key
     * @param value
     */
    public void setGnome2Pref(String key, boolean value) {
        launchProcess("gconftool -s " + key + " -t bool " + String.valueOf(value));
    }

    /**
     * Set a gnome 2 integer preference value using key name
     *
     * @param key
     * @param value
     */
    public void setGnome2Pref(String key, int value) {
        launchProcess("gconftool -s " + key + " -t int " + String.valueOf(value));
    }

    /**
     * Set the KDE Preference file to use for subsequent sets and gets
     *
     * @param filename
     * @return String Path to preference file
     */
    public String setKDEPrefFile(String filename) {
        kdepreffile = filename;
        SimpleFileIO sfio = new SimpleFileIO();
        // Check to see if file actually exists
        String strFilename = getUsersHomeFolder() + getFileSeparator() + kdepreffile;
        if (sfio.exists(strFilename)) {
            return kdepreffile = strFilename;
        }
        return kdepreffile = null;
    }

    /**
     * Get a kde preference string value using group name, key name and return
     * contents of def on failure
     *
     * @param group
     * @param key
     * @param def
     * @return String Preference value
     */
    public String getKDEPref(String group, String key, String def) {

        // If exists read the file contents and find the matching key
        if (kdepreffile == null) {
            return null;
        }

        String strTemp = null;
        SimpleFileIO sfio = new SimpleFileIO();
        sfio.setReadFilename(kdepreffile);
        sfio.openBufferedRead();
        while ((strTemp = sfio.readFromFile()) != null) {
            if (strTemp.contains("[" + group + "]")) {
                break;
            }
        }
        if (strTemp == null) {
            return def;
        }
        while ((strTemp = sfio.readFromFile()) != null) {
            if (strTemp.contains(key)) {
                break;
            }
        }
        sfio.closeBufferedRead();
        if (strTemp == null) {
            return def;
        }
        strTemp = strTemp.substring(strTemp.indexOf("=") + 1);
        return strTemp;
    }

    /**
     * Set a kde string preference value using group name, key name
     *
     * @param group
     * @param key
     * @param value
     */
    public void setKDEPref(String group, String key, String value) {

        // If exists read the file contents and find the matching key
        if (kdepreffile == null) {
            return;
        }

        SimpleFileIO sfio = new SimpleFileIO();
        // Get file contents into a array list for further processing
        String strTemp;
        ArrayList<String> listContents = new ArrayList<>();
        sfio.setReadFilename(kdepreffile);
        sfio.openBufferedRead();
        while ((strTemp = sfio.readFromFile()) != null) {
            listContents.add(strTemp);
        }
        sfio.closeBufferedRead();

        // Process contents of file and write it back out
        sfio.setWriteFilename(kdepreffile);
        sfio.openBufferedWrite();
        // Find Group entry
        boolean entryfound = false;
        while (!listContents.isEmpty()) {
            strTemp = listContents.get(0);
            sfio.writeToFile(strTemp, 1);
            listContents.remove(0);
            if (strTemp.contentEquals("[" + group + "]")) {
                entryfound = true;
                break;
            }
        }

        // If no group entry found then write one
        if (!entryfound) {
            sfio.writeToFile("", 1);
            sfio.writeToFile("[" + group + "]", 1);
        }

        // Find key entry
        while (!listContents.isEmpty()) {
            strTemp = listContents.get(0);
            listContents.remove(0);
            if (strTemp.contains(key)) {
                break;
            }
            sfio.writeToFile(strTemp, 1);
        }

        sfio.writeToFile(key + "=" + value, 1);

        // Write out rest of file
        while (!listContents.isEmpty()) {
            strTemp = listContents.get(0);
            listContents.remove(0);
            sfio.writeToFile(strTemp, 1);
        }

        sfio.closeBufferedWrite();
    }

    /**
     * Set a kde boolean preference value using group name, key name
     *
     * @param group
     * @param key
     * @param value
     */
    public void setKDEPref(String group, String key, boolean value) {
        setKDEPref(group, key, String.valueOf(value));
    }

    /**
     * Set a kde integer preference value using group name, key name
     *
     * @param group
     * @param key
     * @param value
     */
    public void setKDEPref(String group, String key, int value) {
        setKDEPref(group, key, String.valueOf(value));
    }

    public void pause(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ex) {
        }
    }
}
