/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import javax.swing.SwingWorker;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class NetFunctions {

    private static final Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    public static final long LATENCY_FAIL = 9999;
    public static final long LATENCY_UNKNOWN = 0;
    private final GlobalFunctions gf = GlobalFunctions.getInstance();
    private String strUserAgent = "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20110814 Firefox/6.0";
    private boolean boolFollowRedirect = false;

    public NetFunctions() {
    }

    /**
     * Set user agent sent to any website
     *
     * @param agent
     */
    public void setUserAgent(String agent) {
        strUserAgent = agent;
    }

    /**
     * Enable or disable any web redirects
     *
     * @param enabled
     */
    public void setFollowRedirects(boolean enabled) {
        boolFollowRedirect = enabled;
    }

    /**
     * Save the contents of a URL to a file
     *
     * @param destfile File destination path
     * @param strURL URL
     * @param proxy Specify a proxy, null == no proxy
     * @param timeout Specify a timeout before declaring failure
     * @return boolean True if successful
     */
    public boolean saveURLToFile(String destfile, String strURL, Proxy proxy, int timeout) {

        int noOfChars;
        char[] cb = new char[1024];
        SimpleFileIO sfio = new SimpleFileIO();
        sfio.setWriteFilename(destfile);
        sfio.openBufferedWrite();
        BufferedReader br = createURLReader(createConnectionToURL(strURL, proxy, timeout));
        try {
            while (true) {
                noOfChars = br.read(cb);
                if (noOfChars == -1) {
                    break;
                }
                sfio.writeToFile(String.valueOf(cb, 0, noOfChars), 0);
            }
            br.close();
            sfio.fileFlush();
            sfio.closeBufferedWrite();
            return true;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "saveURLToFile", ex);
            return false;
        }
    }

    /**
     * Read the contents of a URL and store in a list
     *
     * @param strURL URL
     * @param proxy Specify a proxy, null == no proxy
     * @param timeout Specify a timeout before declaring failure
     * @return ArrayList<String> A list or null if failed
     */
    public ArrayList<String> readURLAsList(String strURL, Proxy proxy, int timeout) {

        BufferedReader br = createURLReader(createConnectionToURL(strURL, proxy, timeout));
        ArrayList<String> result = new ArrayList<>();
        String line;
        try {
            while (true) {
                line = br.readLine();
                if (line == null) {
                    break;
                }
                result.add(line);
            }
            br.close();
            return result;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "readURLAsList", ex);
        }
        return null;
    }

    /**
     * Read the contents of a URL and store in a string
     *
     * @param strURL URL
     * @param proxy Specify a proxy, null == no proxy
     * @param timeout Specify a timeout before declaring failure
     * @return String or null
     */
    public String readURLAsString(String strURL, Proxy proxy, int timeout) {
        BufferedReader br = createURLReader(createConnectionToURL(strURL, proxy, timeout));
        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while (true) {
                line = br.readLine();
                if (line == null) {
                    break;
                }
                sb.append(line);
                sb.append("\n");
            }
            br.close();
            return sb.toString();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "readURLAsString", ex);
        }
        return null;
    }

    /**
     * Create a URLConnection
     *
     * @param strURL URL
     * @param proxy Specify a proxy, null == no proxy
     * @param timeout Specify a timeout before declaring failure
     * @return Http or Https connection
     */
    public URLConnection createConnectionToURL(String strURL, Proxy proxy, int timeout) {
        HttpsURLConnection httpsConn;
        HttpURLConnection httpConn;

        try {
            URL aURL = new URL(strURL);
            if (strURL.startsWith("https")) {
                if (proxy == null) {
                    httpsConn = (HttpsURLConnection) aURL.openConnection();
                } else {
                    httpsConn = (HttpsURLConnection) aURL.openConnection(proxy);
                }
                httpsConn.setInstanceFollowRedirects(boolFollowRedirect);
                httpsConn.addRequestProperty("user-agent", strUserAgent);
                httpsConn.setSSLSocketFactory(getSocketFactory());
                httpsConn.setConnectTimeout(timeout);
                httpsConn.setReadTimeout(timeout);
                httpsConn.setDoInput(true);
                httpsConn.connect();
                return httpsConn;
            } else {
                if (proxy == null) {
                    httpConn = (HttpURLConnection) aURL.openConnection();
                } else {
                    httpConn = (HttpURLConnection) aURL.openConnection(proxy);
                }
                httpConn.setInstanceFollowRedirects(boolFollowRedirect);
                httpConn.addRequestProperty("user-agent", strUserAgent);
                httpConn.setConnectTimeout(timeout);
                httpConn.setReadTimeout(timeout);
                httpConn.setDoInput(true);
                httpConn.connect();
                return httpConn;
            }
        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * Create a buffered reader to a given URLConnection
     *
     * @param conn
     * @return BufferedReader
     */
    public BufferedReader createURLReader(URLConnection conn) {

        InputStream inStream;
        try {
            inStream = conn.getInputStream();
            return new BufferedReader(new InputStreamReader(inStream));
        } catch (Exception ex) {
        }
        return null;
    }

    /**
     * Get an ssl socket factory, Uses a dummy trust manager so not to be relied
     * on for security
     *
     * @return SSLSocketFactory
     */
    public SSLSocketFactory getSocketFactory() {
        SSLSocketFactory socketFactory = null;
        try {
            SSLContext context = SSLContext.getInstance("SSLv3");
            context.init(null, new X509TrustManager[]{new DummyTrustManager()}, null);
            socketFactory = context.getSocketFactory();
        } catch (NoSuchAlgorithmException | KeyManagementException ex) {
            logger.throwing(this.getClass().getName(), "getSocketFactory()", ex);
        }

        return socketFactory;
    }

    /**
     * Get latency non threaded version
     *
     * @param strUrl URL
     * @param proxy Specify a proxy, null == no proxy
     * @param timeout Specify a timeout before declaring failure
     * @return long latency in milliseconds
     */
    public long getLatencyNonThreaded(String strUrl, Proxy proxy, int timeout) {

        long lngStart;
        long lngResult = LATENCY_FAIL;
        HttpURLConnection conn;

        try {
            URL url = new URL(strUrl);
            if (proxy == null) {
                conn = (HttpURLConnection) url.openConnection();
            } else {
                conn = (HttpURLConnection) url.openConnection(proxy);

            }
            conn.setDoInput(false);
            conn.setDefaultUseCaches(false);
            conn.setConnectTimeout(timeout);
            lngStart = System.currentTimeMillis();
            conn.connect();
            lngResult = System.currentTimeMillis() - lngStart;
            conn.disconnect();
        } catch (Exception ex) {
            logger.log(Level.INFO, "getLatency {0}", ex.getMessage());
        }
        return lngResult;
    }

    /**
     * Get latency threaded version
     *
     * @param strRemoteURL URL
     * @param proxy Specify a proxy, null == no proxy
     * @param timeout Specify a timeout before declaring failure
     * @return long latency in milliseconds
     */
    public long getLatency(final String strRemoteURL, final Proxy proxy, final int timeout) {

        long lngResult = LATENCY_FAIL;

        SwingWorker sw = new SwingWorker() {
            @Override
            protected Long doInBackground() throws Exception {
                long lngStart;
                long lngResult = LATENCY_FAIL;
                HttpURLConnection conn;

                try {
                    URL url = new URL(strRemoteURL);
                    if (proxy == null) {
                        conn = (HttpURLConnection) url.openConnection();
                    } else {
                        conn = (HttpURLConnection) url.openConnection(proxy);

                    }
                    conn.setDoInput(false);
                    conn.setDefaultUseCaches(false);
                    lngStart = System.currentTimeMillis();
                    conn.connect();
                    lngResult = System.currentTimeMillis() - lngStart;
                    conn.disconnect();
                } catch (Exception ex) {
                    logger.throwing(this.getClass().getName(), "getLatency() doInBackground()", ex);
                }
                return lngResult;
            }
        };
        sw.execute();
        try {
            lngResult = (Long) sw.get(timeout + 5, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            logger.throwing(this.getClass().getName(), "getLatency()", ex);
        }
        return lngResult;
    }

    /**
     * This just creates a socks connection, then terminates to provide a simple
     * keep alive pulse
     *
     * @param socksaddr Socks ip address
     * @param socksport Socks port
     * @param hostURL Remote URL
     */
    public void socksKeepAlivePulse(final String socksaddr, final int socksport, final String hostURL) {
        Socket s = createSocks4aSocket(socksaddr, socksport, gf.findBetweenString(hostURL, "://", "/"), 80);
    }

    /**
     * Get Socks latency
     *
     * @param socksaddr Socks ip address
     * @param socksport Socks port
     * @param hostURL Remote URL
     * @param timeout Specify a timeout before declaring failure
     * @return long latency in milliseconds
     */
    public long getSocksLatency(final String socksaddr, final int socksport, final String hostURL, final int timeout) {

        long lngResult = LATENCY_FAIL;

        SwingWorker sw = new SwingWorker() {
            @Override
            protected Long doInBackground() throws Exception {
                long lngStart;
                long lngResult = LATENCY_FAIL;

                try {
                    Socket s = createSocks4aSocket(socksaddr, socksport, gf.findBetweenString(hostURL, "://", "/"), 80);
                    DataInputStream is = new DataInputStream(s.getInputStream());
                    lngStart = System.currentTimeMillis();
                    is.readByte();
                    lngResult = System.currentTimeMillis() - lngStart;
                    is.close();
                    s.close();
                } catch (Exception ex) {
                    //                   logger.error(this, ex, "getTorLatency()");
                }
                return lngResult;
            }
        };
        sw.execute();
        try {
            lngResult = (Long) sw.get(timeout, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
        }
        return lngResult;
    }

    /*
     * Taken from Wikipedia SOCKS4a is a simple extension to SOCKS4 protocol
     * that allows a client that cannot resolve the destination host's domain
     * name to specify it.
     *
     * The client should set the first three bytes of DSTIP to NULL and the last
     * byte to a non-zero value. (This corresponds to IP address 0.0.0.x, with x
     * nonzero, an inadmissible destination address and thus should never occur
     * if the client can resolve the domain name.) Following the NULL byte
     * terminating USERID, the client must send the destination domain name and
     * terminate it with another NULL byte. This is used for both "connect" and
     * "bind" requests.
     *
     * Client to SOCKS server: field 1: SOCKS version number, 1 byte, must be
     * 0x04 for this version field 2: command code, 1 byte: 0x01 = establish a
     * TCP/IP stream connection 0x02 = establish a TCP/IP port binding field 3:
     * network byte order port number, 2 bytes field 4: deliberate invalid IP
     * address, 4 bytes, first three must be 0x00 and the last one must not be
     * 0x00 field 5: the user ID string, variable length, terminated with a null
     * (0x00) field 6: the domain name of the host we want to contact, variable
     * length, terminated with a null (0x00)
     *
     *
     * Server to SOCKS client: field 1: null byte field 2: status, 1 byte: 0x5a
     * = request granted 0x5b = request rejected or failed 0x5c = request failed
     * because client is not running identd (or not reachable from the server)
     * 0x5d = request failed because client's identd could not confirm the user
     * ID string in the request field 3: network byte order port number, 2 bytes
     * field 4: network byte order IP address, 4 bytes
     *
     * A server using protocol SOCKS4A must check the DSTIP in the request
     * packet. If it represents address 0.0.0.x with nonzero x, the server must
     * read in the domain name that the client sends in the packet. The server
     * should resolve the domain name and make connection to the destination
     * host if it can.
     */
    /**
     * Create a Socks4a socket
     *
     * @param socksaddr Socks ip address
     * @param socksport Socks port
     * @param remotehost Remote host
     * @param remoteport Remote port
     * @return Socket
     */
    public Socket createSocks4aSocket(String socksaddr, int socksport, String remotehost, int remoteport) {
        try {
            Socket s = new Socket(socksaddr, socksport);
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            dos.writeByte(0x04);            // Version 4 Socks
            dos.writeByte(0x01);            // Connect command code
            dos.writeShort(remoteport);     // Remote Port number
            dos.writeInt(0x01);             // IP address of 0.0.0.1 means use Socks 4a
            dos.writeByte(0x00);            // Null terminator
            dos.writeBytes(remotehost);     // Remote host IP address
            dos.writeByte(0x00);            // Null terminator
            return s;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "createTorSocket()", ex);
            return null;
        }
    }

    /**
     * Test to see if a host site is reachable
     *
     * @param remotehost Host site
     * @param timeout Specify a timeout before declaring failure
     * @return boolean True if reachable
     */
    public boolean isHostReachable(String remotehost, int timeout) {

        long lngResult;
        if (remotehost == null) {
            remotehost = "http://www.google.com";
        }
        try {
            lngResult = getLatency(remotehost, null, timeout);
        } catch (Exception ex) {
            lngResult = LATENCY_FAIL;
            logger.throwing(this.getClass().getName(), "isHostReachable()", ex);
        }
        return (lngResult < LATENCY_FAIL);
    }

    /**
     * Test to see if internet is reachable
     *
     * @return boolean True if reachable
     */
    public boolean isNetReachable() {
        if (isHostReachable(null, 1000)) {
            return true;
        }
        if (isHostReachable("http://www.ibiblio.org", 1000)) {
            return true;
        }
        return isHostReachable("http://www.bing.com", 1000);




    }

    /**
     * Used for accessing SSL sites and bypassing certificate authentification
     */
    private class DummyTrustManager implements X509TrustManager {

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[]{};
        }
    }
}
