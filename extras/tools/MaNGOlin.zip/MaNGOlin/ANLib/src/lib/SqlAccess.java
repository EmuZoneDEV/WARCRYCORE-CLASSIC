/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.io.InputStream;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class SqlAccess {

    private static final Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    private static final String DRIVERDRIZZLE = "org.drizzle.jdbc.DrizzleDriver";
    private static final String DRIVERMYSQL = "com.mysql.jdbc.Driver";
    private static final String DRIVERCLASSNAME = DRIVERMYSQL;
    private final Hashtable<String, Statement> hashStatements = new Hashtable<>(10);
    private final Hashtable<String, String> hashCatalogs = new Hashtable<>(10);
    private Connection dbConn = null;
    private ResultSet rs = null;
    private ResultSetMetaData meta = null;
    private Statement stmt = null;
    private boolean bulkinsert = true;
    private final SimpleFileIO fileIO = new SimpleFileIO();
    private int percentComplete = 0;
    private String actionTable = null;
    private String actionFile = null;
    private boolean resultsetempty = false;
    private String hostname = null;
    private String tempStr = null;
    private String stmtKey = null;
    private String dbversion = null;
    private String generatedby = null;

    public SqlAccess() {
    }
    /**
     * Utility field used by bound properties.
     */
    private final java.beans.PropertyChangeSupport propertyChangeSupport = new java.beans.PropertyChangeSupport(this);

    /**
     * Adds a PropertyChangeListener to the listener list.
     *
     * @param l The listener to add.
     */
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l) {
        propertyChangeSupport.addPropertyChangeListener(l);
    }

    /**
     * Removes a PropertyChangeListener from the listener list.
     *
     * @param l The listener to remove.
     */
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l) {
        propertyChangeSupport.removePropertyChangeListener(l);
    }

    /**
     * Attempts to make a connection to the database with the given params
     *
     * @param host Host IP or Name of server.
     * @param port Port MySql is listening on.
     * @param username The username of the person who has access rights to the
     * database.
     * @param password The password of the person of the supplied username.
     * @return Returns "Connected" if successfull else returns error message
     */
    public String openDB(String host, String port, String username, String password) {

        // Register sql driver
        try {
            Class.forName(DRIVERCLASSNAME);
            if (host.isEmpty()) {
                host = "127.0.0.1";
            }
            if (DRIVERCLASSNAME.contains("Drizzle")) {
                dbConn = DriverManager.getConnection("jdbc:mysql:thin://" + username + ":" + password + "@" + host + ":" + port);
            } else {
                dbConn = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/", username, password);
            }
            hostname = host;
            return "Connected";
        } catch (ClassNotFoundException | SQLException ex) {
            logger.throwing(this.getClass().getName(), "openDB", ex);
            return ex.toString();
        }
    }

    /**
     * Close Database connection
     */
    public void closeDB() {

        String key;
        Enumeration enumKeys = hashStatements.keys();
        try {
            if (dbConn == null) {
                return;
            }
            dbConn.close();
            if (rs != null) {
                rs.close();
            }
            // Remove Statements
            while (enumKeys.hasMoreElements()) {
                key = (String) enumKeys.nextElement();
                stmt = hashStatements.get(key);
                stmt.close();
                hashStatements.remove(key);
                hashCatalogs.remove(key);
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "closeDB", ex);
        }
    }

    /**
     * Creates a database with the given name
     *
     * @param name Name of the database
     */
    public void createDatabase(String name) {
        try {
            stmt = dbConn.createStatement();
            stmt.executeUpdate("create database " + name);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "createDatabase(" + name + ")", ex);
        }
    }

    /**
     * Creates a comma separated list of the available databases
     *
     * @return Returns comma separated list of the available databases
     */
    public String getDatabasesAsCsv() {
        String result = "";
        try {
            stmt = dbConn.createStatement();
            rs = stmt.executeQuery("show databases");
            while (rs.next()) {
                result += rs.getString(1) + ",";
            }
            return result;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getDatabasesAsCsv", ex);
            return null;
        }
    }

    /**
     * Gets the current database connection status
     *
     * @return Returns true if we have a valid connection
     */
    public boolean getCurrentConnectionStatus() {
        return (dbConn != null);
    }

    /**
     * Sets the default backup path for the sql files
     *
     * @param path
     */
    public void setBackupPath(String path) {
        fileIO.createFolder(path);
        fileIO.setDefaultFilePath(path);
    }

    /**
     * @return Returns the default backup path as a String for the sql files
     *
     */
    public String getBackupPath() {
        return fileIO.getDefaultFilePath();
    }

    /**
     * Get the database connection
     *
     * @return Return the connection to the database
     */
    public Connection getConnection() {
        return dbConn;
    }

    public String getHostname() {
        return hostname;
    }

    public String createStatement(String key) {
        try {
            hashStatements.put(key, dbConn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE));
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "createStatement(" + key + ")", ex);
            return key;
        }
        return null;
    }

    public String createStatement(String key, String dbname) {
        try {
            setCatalog(dbname);
            hashStatements.put(key, dbConn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE));
            hashCatalogs.put(key, dbname);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "createStatement(" + key + "," + dbname + ")", ex);
            return key;
        }
        return null;
    }

    public void removeStatement(String key) {
        try {
            hashStatements.remove(key);
            hashCatalogs.remove(key);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "removeStatement(" + key + ")", ex);
        }
    }

    public void setStatement(String key) {

        String dbname;
        try {
            dbname = hashCatalogs.get(key);
            if (dbname != null) {
                setCatalog(dbname);
            }
            stmt = hashStatements.get(key);
            rs = stmt.getResultSet();
            if (rs != null) {
                meta = rs.getMetaData();
            }
            stmtKey = key;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "setStatement(" + key + ")", ex);
        }
    }

    public String getCurrentStatementKey() {
        return stmtKey;
    }

    public void setCatalog(String dbname) throws Exception {
        dbConn.setCatalog(dbname);
        dbConn.createStatement().executeUpdate("USE " + dbname);
    }

    public String getCatalog() {
        try {
            return dbConn.getCatalog();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getCatalog()", ex);
        }
        return "";
    }

    /**
     * Populates the supplied JComboBox with results of a single column in a
     * result set
     *
     * @param acombo The combobox to be populated
     * @param col The resultset column
     */
    public void populateCombo(JComboBox acombo, int col) {
        acombo.removeAllItems();
        try {
            while (rs.next()) {
                acombo.addItem(rs.getString(col));
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "populateCombo", ex);
        }
    }

    public String[] getColumnHeaders() {

        String[] result;
        int colcount;
        try {
            colcount = meta.getColumnCount();
            result = new String[colcount];
            for (int i = 0; i < colcount; i++) {
                result[i] = meta.getColumnName(i + 1);
            }
            return result;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getColumnHeaders", ex);
            return null;
        }
    }

    public String[] getRowData() {
        String[] result;
        int colcount;
        try {
            colcount = meta.getColumnCount();
            result = new String[colcount];
            for (int i = 0; i < colcount; i++) {
                result[i] = getString(i + 1);
            }
            return result;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getRowData", ex);
            return null;
        }

    }

    /**
     * Sets the current progress information
     *
     * @param value The percentage value 0 - 100
     * @param filename The filename being actioned
     * @param tablename The table being actioned
     */
    private void setProgress(int value, String filename, String tablename) {

        if (filename != null) {
            actionFile = filename;
        }
        if (tablename != null) {
            actionTable = tablename;
        }
        if (percentComplete != value || value == 0) {
            if (value > 100) {
                value = 100;
            }
            propertyChangeSupport.firePropertyChange("progress", percentComplete, value);
            percentComplete = value;
        }
    }

    /**
     * @return Returns the current progress percentage as an integer value from
     * 0 - 100
     */
    public int getProgress() {
        return percentComplete;
    }

    /**
     * @return Returns the current tablename being actioned
     */
    public String getActionTableName() {
        return actionTable;
    }

    /**
     * @return Returns the current filename being actioned
     */
    public String getActionFileName() {
        return actionFile;
    }

    /**
     * Sets whether bulk inserts are enabled
     *
     * @param enabled
     */
    public void setBulkInsertEnabled(boolean enabled) {
        bulkinsert = enabled;
    }

    public boolean deleteRow() {
        try {
            rs.deleteRow();
            return true;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "deleteRow", ex);
            return false;
        }
    }

    public void setUpdateMode() {

        resultsetempty = isResultSetEmpty();
        if (resultsetempty) {
            try {
                rs.moveToInsertRow();
            } catch (Exception ex) {
                logger.throwing(this.getClass().getName(), "setUpdateMode", ex);
            }
        }
    }

    public void finaliseUpdate() {

        try {
            if (resultsetempty) {
                rs.insertRow();
                rs.moveToCurrentRow();
            } else {
                rs.updateRow();
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "finaliseUpdate", ex);
        }
        resultsetempty = false;
    }

    /**
     * @return Returns the next in sequence index from a specified column within
     * a table
     * @param tablename The table name
     * @param columnname The column name
     */
    public int getNextIndex(String tablename, String columnname) {

        String query = "select DISTINCT " + columnname + " from " + tablename;
        try {
            executeQuery(query);
            last();
            return getInt(columnname) + 1;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getNextGuid", ex);
            return -1;
        }

    }

    public long getAutoIncrement(String tablename) {

        String query = "SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = '" + getCatalog() + "' AND TABLE_NAME = '" + tablename + "'";
        try {
            executeQuery(query);
            next();
            return rs.getLong("AUTO_INCREMENT");
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getAutoIncrement", ex);
            return -1;
        }
    }

    public boolean updateColumn(String columnName, String value) {
        int idx;
        int type;
        float afloat;
        double adouble;
        long along;
        int anint;

        try {
            idx = rs.findColumn(columnName);
            type = meta.getColumnType(idx);
            switch (type) {
                case java.sql.Types.REAL:
                    afloat = Float.parseFloat(value);
                    rs.updateFloat(idx, afloat);
                    break;
                case java.sql.Types.FLOAT:
                    afloat = Float.parseFloat(value);
                    rs.updateFloat(idx, afloat);
                    break;
                case java.sql.Types.DOUBLE:
                    adouble = Double.parseDouble(value);
                    rs.updateDouble(idx, adouble);
                    break;
                case java.sql.Types.BIGINT:
                    along = Long.parseLong(value);
                    rs.updateLong(idx, along);
                case java.sql.Types.SMALLINT:
                    anint = Integer.parseInt(value);
                    rs.updateInt(idx, anint);
                case java.sql.Types.TINYINT:
                    anint = Integer.parseInt(value);
                    rs.updateInt(idx, anint);
                case java.sql.Types.VARCHAR:
                    rs.updateString(idx, value);
                case java.sql.Types.LONGVARCHAR:
                    rs.updateString(idx, value);
                    break;
                case java.sql.Types.TIMESTAMP:
                    rs.updateTimestamp(idx, Timestamp.valueOf(value));
                    break;
                case java.sql.Types.DATE:
                    rs.updateDate(idx, Date.valueOf(value));
                    break;
                case java.sql.Types.TIME:
                    rs.updateTime(idx, Time.valueOf(value));
                    break;
                default:
                    System.out.println(type);
                    break;
            }
            return true;
        } catch (SQLException | NumberFormatException ex) {
            logger.throwing(this.getClass().getName(), "updateColumn(" + columnName + ")", ex);
            return false;
        }

    }

    /**
     * @param query The SQL query
     * @return Returns true if successful
     */
    public boolean execute(String query) {
        try {
            logger.log(Level.INFO, "execute {0}", query);
            return stmt.execute(query);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "execute(" + query + ")", ex);
            return false;
        }
    }

    /**
     * Execute a query that returns results
     *
     * @param query The SQL query
     * @return Returns a resultset
     */
    public ResultSet executeQuery(String query) {
        try {
            logger.log(Level.INFO, "executeQuery {0}", query);
            rs = stmt.executeQuery(query);
            meta = rs.getMetaData();
            return rs;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "executeQuery(" + query + ")", ex);
            return null;
        }
    }

    /**
     * Execute an update query
     *
     * @param query The SQL query
     * @return Returns either row count for data manipulation queries or 0, or
     * -1 if error
     */
    public int executeUpdate(String query) {
        try {
            logger.log(Level.INFO, "executeUpdate {0}", query);
            return stmt.executeUpdate(query);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "updateQuery(" + query + ")", ex);
            return -1;
        }
    }

    /**
     * Get resultset
     *
     * @return Returns the resultset of the last executeQuery
     */
    public ResultSet getResultSet() {
        return rs;
    }

    /**
     * Get MetaData
     *
     * @return Returns the resultset meta data of the last executeQuery
     */
    public ResultSetMetaData getMetaData() {
        return meta;
    }

    public String getString(String columnLabel) {
        try {
            tempStr = rs.getString(columnLabel);
            if (tempStr == null) {
                tempStr = "";
            }
            return tempStr;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getString(" + columnLabel + ")", ex);
            return "NotFound";
        }
    }

    public boolean isResultSetEmpty() {
        try {
            rs.getString(1);
            return false;
        } catch (Exception ex) {
            return true;
        }
    }

    /**
     * Get data from resultset as string
     *
     * @param column
     * @return Returns a value as a string
     */
    public String getString(int column) {
        try {
            tempStr = rs.getString(column);
            if (tempStr == null) {
                tempStr = "";
            }
            return tempStr;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getString(" + String.valueOf(column) + ")", ex);
            return "NotFound";
        }
    }

    public int getInt(String columnLabel) {
        try {
            return rs.getInt(columnLabel);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getInt(" + columnLabel + ")", ex);
            return 0;
        }
    }

    public int getInt(int column) {
        try {
            return rs.getInt(column);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getInt(" + String.valueOf(column) + ")", ex);
            return 0;
        }
    }

    public boolean next() {
        try {
            return rs.next();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "next", ex);
            return false;
        }
    }

    public boolean last() {
        try {
            return rs.last();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "last", ex);
            return false;
        }
    }

    /**
     * @return Returns a vector with a list of data for a single column of a
     * resultset
     * @param columnname The column name
     */
    public Vector getColumnData(String columnname) {

        Vector<String> cache = new Vector<>(0);
        try {
            while (rs.next()) {
                cache.add(rs.getString(columnname));
            }
            return cache;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getColumnData", ex);
            return null;
        }
    }

    public void optimiseDatabase(Object progress) {
        ArrayList<String> la = new ArrayList<>();
        try {
            rs = stmt.executeQuery("show tables");
            while (rs.next()) {
                la.add(rs.getString(1));
            }
            rs.close();
            for (String s : la) {
                if (progress != null) {
                    if (progress instanceof InfoDialog) {
                        ((InfoDialog) progress).appendInfoText(s + "\n");
                    }
                }
                logger.log(Level.INFO, "optimiseDatabase() {0}", s);
                stmt.execute("optimize table " + s);
                stmt.execute("alter table " + s + " AUTO_INCREMENT = 1");
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "optimiseDatabase()", ex);
        }
    }

    /**
     * Writes an entire database
     *
     * @param dataonly If true only data is saved
     */
    public void writeSQLDatabase(boolean dataonly) {
        writeSQLDatabase(hostname + "_", dataonly);
    }

    /**
     * Writes an entire database
     *
     * @param partialname Forms the first part of the filename
     * @param dataonly If true only data is saved
     */
    public void writeSQLDatabase(String partialname, boolean dataonly) {

        Vector<String> tablenames = new Vector<>(0);
        String filename;
        int noinserts = 1;
        String dataOnly = "";

        if (partialname == null) {
            partialname = "";
        }

        if (bulkinsert) {
            noinserts = 500;
        }

        if (dataonly) {
            dataOnly = "_dataonly";
        }

        filename = createUniqueFilename(partialname, dataOnly);
        fileIO.setWriteFilename(filename);
        fileIO.openBufferedWrite();
        writeVersionInfo();
        fileIO.writeToFile("USE `" + getCatalog() + "`;", 2);

        try {
            rs = stmt.executeQuery("show tables");
            while (rs.next()) {
                tablenames.add(rs.getString(1));
            }

            for (int i = 0; i < tablenames.size(); i++) {
                writeSQLTable((String) tablenames.get(i), dataonly, noinserts, null);
                // Do a garbage collection
                System.gc();
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "writeSQLDatabaseAction", ex);
        }
        fileIO.closeBufferedWrite();
    }

    public String createUniqueFilename(String precatalog, String postcatalog) {
        int suffix = 0;
        String filename = null;
        while (true) {
            filename = precatalog + getCatalog() + postcatalog + "_" + String.valueOf(suffix) + ".sql";
            if (fileIO.exists(filename)) {
                if (++suffix > 99) {
                    suffix = 0;
                }
            } else {
                break;
            }
        }
        return filename;
    }

    public void writeVersionInfo() {
        if (generatedby != null) {
            fileIO.writeToFile("-- ClientVersion = " + generatedby + " --", 2);
        }
        if (dbversion != null) {
            fileIO.writeToFile("-- DBVersion = " + dbversion + " --", 2);
        }
    }

    public void setVersionInfo(String generator, String dbver) {
        generatedby = generator;
        dbversion = dbver;
    }

    /**
     * Write a single database table with given tablename using bulk insert, if
     * dataonly is true then its data only else include drop table
     *
     * @param tableName The name of the table
     * @param dataonly Dataonly flag
     * @param inserts The number of inserts merged into one insert statement
     * @param where The where part of a query
     */
    public void writeSQLTable(String tableName, boolean dataonly, int inserts, String where) {

        String values;
        String temp;
        String query;
        String insdelim = "";
        String valdelim;
        int records;
        int recidx = 0;
        int insertcount = 0;
        long limit = 2000;

        try {
            if (!dataonly) {
                rs = stmt.executeQuery("show create table " + getCatalog() + "." + tableName);
                rs.next();
                fileIO.writeToFile("-- Table structure for table '" + tableName + "' --", 1);
                fileIO.writeToFile("DROP TABLE IF EXISTS `" + tableName + "`;", 1);
                fileIO.writeToFile(rs.getString(2) + ";", 2);
            }

            // Do a filestream flush
            fileIO.fileFlush();

            // Get total number of records in this table
            if (where == null) {
                query = "select count(*) from " + getCatalog() + "." + tableName;
            } else {
                query = "select count(*) from " + getCatalog() + "." + tableName + " where " + where;
            }
            rs = stmt.executeQuery(query);
            logger.log(Level.INFO, "writeSQLTable {0}", query);
            rs.next();
            records = Integer.parseInt(rs.getString(1));
            // Exit if zero records
            if (records == 0) {
                return;
            }

            fileIO.writeToFile("-- Data for the table '" + tableName + "' --", 1);
            fileIO.writeToFile("lock tables `" + tableName + "` write;", 1);
            // Clear values for each record
            setProgress(0, fileIO.getWriteFile().getName(), tableName);

            for (long z = 0; z < records; z += limit) {
                // Get data resultset for this table
                if (where == null) {
                    query = "select * from " + getCatalog() + "." + tableName + " LIMIT "
                            + String.valueOf(z) + "," + String.valueOf(limit);
                } else {
                    query = "select * from " + getCatalog() + "." + tableName + " where " + where + " LIMIT "
                            + String.valueOf(z) + "," + String.valueOf(limit);
                }
                rs = stmt.executeQuery(query);
                logger.log(Level.INFO, "writeSQLTable {0}", query);
                meta = rs.getMetaData();

                while (rs.next()) {
                    setProgress(++recidx * 100 / records, null, null);
                    if (insertcount == 0) {
                        fileIO.writeToFile("insert into `" + tableName + "` values ", 0);
                        insdelim = "";
                    }
                    // Get data values from each column and format result based on column type
                    valdelim = values = "";
                    for (int i = 1; i < meta.getColumnCount() + 1; i++) {
                        switch (meta.getColumnType(i)) {
                            case java.sql.Types.BIGINT:
                            case java.sql.Types.BINARY:
                            case java.sql.Types.DOUBLE:
                            case java.sql.Types.FLOAT:
                            case java.sql.Types.INTEGER:
                            case java.sql.Types.REAL:
                            case java.sql.Types.NUMERIC:
                            case java.sql.Types.SMALLINT:
                            case java.sql.Types.TINYINT:
                                temp = rs.getString(i);
                                values += (valdelim + temp);
                                break;

                            case java.sql.Types.TIMESTAMP:
                                try {
                                    temp = rs.getString(i);
                                } catch (Exception e) {
                                    temp = "0000-00-00 00:00:00";
                                }
                                if (temp == null) {
                                    values += (valdelim + "null");
                                } else {
                                    values += (valdelim + "'" + temp + "'");
                                }
                                break;

                            default:
                                temp = rs.getString(i);
                                if (temp != null) {
                                    temp = temp.replaceAll("[']", "\\\\'");
                                    temp =
                                            temp.replaceAll("[\n]", "\\\\n");
                                    temp =
                                            temp.replaceAll("[\r]", "\\\\r");
                                    values +=
                                            (valdelim + "'" + temp + "'");
                                } else {
                                    values += (valdelim + temp);
                                }

                                break;
                        } // End of Switch

                        valdelim = ",";
                    } // End of For

                    fileIO.writeToFile(insdelim + "(" + values + ")", 0);
                    insdelim = ",";
                    // Ensure that our bulk inserts are never to large by splitting it up after a certain
                    // amount of entries, its not foolproof but it is good enough if we keep the number reasonable
                    if (++insertcount >= inserts) {
                        insertcount = 0;
                        fileIO.writeToFile(";", 1);
                        fileIO.fileFlush();
                    }

                } // End of While
            }

            if (insertcount > 0) {
                fileIO.writeToFile(";", 1);
            }
            fileIO.writeToFile("unlock tables;", 2);
            // Do a filestream flush
            fileIO.fileFlush();
        } catch (SQLException | NumberFormatException ex) {
            logger.throwing(this.getClass().getName(), "writeSQLTable", ex);
        }

    }

    /**
     *
     * @return Returns the current fileio object being used for file operations
     */
    public SimpleFileIO getFileIO() {
        return fileIO;
    }

    public void readSQLFile(String filename, boolean ignoreUseStatement) {
        fileIO.setReadFilename(filename, true);
        setProgress(0, filename, "");
        readSQLFile(fileIO.openFileInputStream(), ignoreUseStatement);
    }

    /**
     * Reads into a database from a sql file
     *
     * @param is The inputstream to be read from
     * @param ignoreUseStatement
     */
    public void readSQLFile(InputStream is, boolean ignoreUseStatement) {
        String line;
        StringBuilder sb = new StringBuilder();
        int nobytes;
        long total = 0;
        long fileLength = 1;

        if (is != null) {
            fileIO.openBufferedRead(is);
        } else {
            fileIO.openBufferedRead();
        }

        try {
            fileLength = fileIO.getReadFile().length();
        } catch (Exception ex) {
        }

        while (true) {
            line = fileIO.readFromFile();
            if (line == null) {
                break;
            }

            nobytes = line.length() + 2;
            total += nobytes;
            setProgress((int) (total * 100 / fileLength), null, null);
            line = line.trim();
            if (line.isEmpty() || line.startsWith("--") || line.startsWith("/*")) {
                continue;
            }
            if (ignoreUseStatement && line.toLowerCase().startsWith("use")) {
                continue;
            }


            sb.append(line);
            if (!line.endsWith(";")) {
                continue;
            }

            try {
                stmt.executeUpdate(sb.toString());
                logger.log(Level.INFO, "readSQLFile(InputStream is) {0}", sb.toString());
            } catch (Exception ex) {
                logger.log(Level.INFO, "readSQLFile, ERROR IN SQL,{0}", sb.toString());
            }
            sb.delete(0, sb.length());
        }
        fileIO.closeBufferedRead();
    }

    public String getDateTimeStamp() {
        SimpleDateFormat sdf = new SimpleDateFormat();
        sdf.applyPattern("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new java.util.Date());
    }

    public String getDateTimeStamp(String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat();
        sdf.applyPattern(pattern);
        return sdf.format(new java.util.Date());
    }
}
