/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.awt.event.ActionListener;
import javax.swing.Action;
import javax.swing.JButton;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class InstantAction {

    private final JButton aButton;

    /** Base Constructor
     *
     */
    public InstantAction() {
        aButton = new JButton();
    }

    public void addActionListener(ActionListener l) {
        aButton.addActionListener(l);
    }

    /** Constructor with action setting
     *
     * @param action
     */
    public InstantAction(Action action) {
        aButton = new JButton();
        setAction(action);
    }

    /** Set an action
     *
     * @param action
     */
    public void setAction(Action action) {
        aButton.setAction(action);
    }

    /** Fire an action
     *
     */
    public void fireAction() {
        aButton.doClick();
    }
}
