/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class SocketConnector {

    private static final Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    private Socket ourSocket = null;
    private PrintWriter out = null;
    private BufferedReader in = null;
    private boolean boolConnected = false;
    private long lngWait = 30000;
    private String strLineTerm = "\r";
    private String strPrompt = "\r";

    /**
     * Connect to specified host and port
     *
     * @param ahost
     * @param aport
     * @return Connection message as a string
     * @throws Exception
     */
    public String connect(String ahost, int aport) throws Exception {
        ourSocket = new Socket(ahost, aport);
        ourSocket.setSoTimeout(5000);
        in = new BufferedReader(new InputStreamReader(ourSocket.getInputStream()));
        out = new PrintWriter(ourSocket.getOutputStream(), true);
        boolConnected = true;
        logger.info("connect");
        return read(lngWait);
    }

    /**
     * Set line termination
     *
     * @param text
     */
    public void setLineTerm(String text) {
        strLineTerm = text;
    }

    /**
     * Set the default result wait period in milliseconds
     *
     * @param millis
     */
    public void setWaitPeriod(long millis) {
        lngWait = millis;
    }

    /**
     * Get the default result wait period
     *
     * @return wait period in milliseconds
     */
    public long getWaitPeriod() {
        return lngWait;
    }

    /**
     * Check for a connection
     *
     * @return true if connected
     */
    public boolean isConnected() {
        return boolConnected;
    }

    /**
     * Send text
     *
     * @param text
     * @return resulting message as a string
     */
    public String send(String text) {
        return send(text, lngWait);
    }

    /**
     * Send text and wait a specified period for result
     *
     * @param text
     * @param waitfor
     * @return result as a string
     */
    public String send(String text, long waitfor) {

        // Ensure we are connected before doing any output
        if (!boolConnected) {
            logger.log(Level.INFO, "send Not Connected {0}", text);
            return null;
        }
        String result;
        // Send our text output
        try {
            text += strLineTerm;
            // Lets clear the input buffer prior to sending
            while (in.ready()) {
                in.read();
            }
            out.print(text);
            out.flush();
            logger.log(Level.INFO, "send {0}", text);
            // Get any return text
            result = read(lngWait);
            return result;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "send " + text, ex);
        }
        return null;
    }

    private String read(long waitfor) {
        String strResult = "";
        long lngTimeout;

        if (!boolConnected) {
            logger.info("read, Not Connected");
            return null;
        }

        try {
            lngTimeout = System.currentTimeMillis() + waitfor;
            while (!in.ready()) {
                if (strPrompt.isEmpty()) {
                    break;
                }
                if (System.currentTimeMillis() >= lngTimeout) {
                    logger.info("read, Timeout");
                    return strResult;
                }
            }
            // Get any return text
            char c;
            String line = "";
            while (in.ready()) {
                c = (char) in.read();
                line += String.valueOf(c);
                if (c == '\n') {
                    strResult += line;
                    line = "";
                }
                if (strResult.contains(strPrompt)) {
                    while (in.ready()) {
                        in.read();
                    }
                    break;
                }
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "read(long waitfor)", ex);
            strResult = null;
        }
        logger.log(Level.INFO, "read {0}", strResult);
        return strResult;
    }

    /**
     * Set prompt
     *
     * @param text
     */
    public void setPrompt(String text) {
        strPrompt = text;
    }

    /**
     * Set connection timeout in milliseconds
     *
     * @param ms
     */
    public void setTimeout(int ms) {
        try {
            ourSocket.setSoTimeout(ms);
        } catch (Exception ex) {
        }
    }

    /**
     * Disconnect
     *
     * @throws IOException
     */
    public void disconnect() throws IOException {

        if (boolConnected) {
            ourSocket.close();
        }
        ourSocket = null;
        in = null;
        out = null;
        boolConnected = false;
    }
}
