/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.awt.Font;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;

/**
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class ComboBoxEditor extends DefaultCellEditor {

    JComboBox jcb;

    /**
     * Creates a new instance of ComboBoxEditor with the given values
     *
     * @param values
     */
    public ComboBoxEditor(String[] values) {
        super(new JComboBox(values));

    }

    /**
     * Returns the selected index of this editor component as an int
     *
     * @return int
     */
    public int getSelectedIndex() {
        return ((JComboBox) getComponent()).getSelectedIndex();
    }

    /**
     * Returns the selected item of this editor component as an Object
     *
     * @return Object
     */
    public Object getSelectedItem() {
        return ((JComboBox) getComponent()).getSelectedItem();
    }

    public Font getFont() {
        return ((JComboBox) getComponent()).getFont();
    }

    public void setFont(Font font) {
        ((JComboBox) getComponent()).setFont(font);
    }
}
