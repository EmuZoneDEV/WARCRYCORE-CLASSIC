/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This software is not to be shared or distributed in any form without 
 * the express written permission of the author.
 */
package lib;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class SimpleFileIO {

    private static final Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    private BufferedReader buffReader;
    private BufferedWriter buffWriter;
    private FileOutputStream foutStream;
    private FileInputStream finStream;
    private File readFile;
    private File writeFile;
    private final String separator;
    private String defPath = "";
    private File[] fileList;
    private String myFilter = "";
    private ZipOutputStream zos;

    /**
     * Base constructor
     */
    public SimpleFileIO() {
        // We need this rigmarole for cross platform compatibility
        separator = System.getProperty("file.separator");
        //       if (separator.compareTo("\\") == 0) {
        //           separator = "\\\\";
        //       }
    }

    public String getSeparator() {
        return separator;
    }

    /**
     * Set the filename of the file to be written to, the default filepath if
     * set is prefixed to the filename
     *
     * @param filename
     */
    public void setWriteFilename(String filename) {
        setWriteFilename(filename, true);
    }

    /**
     * Set the filename of the file to be written to, if usedefpath true then
     * the default filepath if set is prefixed to the filename
     *
     * @param filename
     * @param usedefpath
     */
    public void setWriteFilename(String filename, boolean usedefpath) {
        try {
            if (filename == null) {
                writeFile = null;
                return;
            }
            if (usedefpath && !defPath.isEmpty()) {
                writeFile = new File(defPath + separator + filename);
            } else {
                writeFile = new File(filename);
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "setWriteFilename(String filename, boolean usedefpath)", ex);
        }
    }

    /**
     * Set the filename of the file to be read from, the default filepath if set
     * is prefixed to the filename
     *
     * @param filename
     */
    public void setReadFilename(String filename) {
        setReadFilename(filename, true);
    }

    /**
     * Set the filename of the file to be read from, if usedefpath true then
     * default path is prefixed to the filename
     *
     * @param filename
     * @param usedefpath
     */
    public void setReadFilename(String filename, boolean usedefpath) {
        try {
            if (filename == null) {
                readFile = null;
                return;
            }
            if (usedefpath && !defPath.isEmpty()) {
                readFile = new File(defPath + separator + filename);
            } else {
                readFile = new File(filename);
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "setReadFilename(String filename, boolean usedefpath)", ex);
        }

    }

    /**
     * Returns just the filename being written to, the path is not included
     *
     * @return Returns filename as String
     */
    public String getWriteFilename() {
        return writeFile.getName();
    }

    /**
     * Returns just the filename being read from, the path is not included
     *
     * @return Returns filename as String
     */
    public String getReadFilename() {
        return readFile.getName();
    }

    /**
     * Gets the read file absolute filepath
     *
     * @return Absolute filepath
     */
    public String getReadFilePath() {

        if (readFile == null) {
            return System.getProperty("user.dir");
        }
        String absolute = readFile.getAbsolutePath();
        String filename = readFile.getName();
        if (absolute.contains(filename)) {
            int pos = absolute.indexOf(filename);
            absolute = absolute.substring(1, pos);
        }
        return absolute;
    }

    /**
     * Gets the write file absolute filepath
     *
     * @return Absolute filepath
     */
    public String getWriteFilePath() {

        if (writeFile == null) {
            return System.getProperty("user.dir");
        }
        String absolute = writeFile.getAbsolutePath();
        String filename = writeFile.getName();
        if (absolute.contains(filename)) {
            int pos = absolute.indexOf(filename);
            absolute = absolute.substring(0, pos);
        }
        return absolute;
    }

    /**
     * @return Returns the File we are writing to
     */
    public File getWriteFile() {
        return writeFile;
    }

    /**
     * @return Returns the File we are reading from
     */
    public File getReadFile() {
        return readFile;
    }

    /**
     * Sets the write file
     *
     * @param f The file
     */
    public void setWriteFile(File f) {
        writeFile = f;
    }

    /**
     * Sets the read file
     *
     * @param f The file
     */
    public void setReadFile(File f) {
        readFile = f;
    }

    /**
     * Sets the file filter
     *
     * @param filter
     */
    public void setFileFilter(String filter) {
        myFilter = filter;
    }

    /**
     * Gets the current file filter
     *
     * @return Returns the filefilter
     */
    public String getFileFilter() {
        return myFilter;
    }

    /**
     * Open a zip file for output, will overwrite any existing zip file
     *
     * @param zippath File path to zip
     * @param level Compression level 0 - 9, default = 6
     * @return Boolean true if successfull
     */
    public boolean openZipForOutput(String zippath, int level) {
        try {
            zos = new ZipOutputStream(new FileOutputStream(zippath));
            if (level < 0 || level > 9) {
                level = 6;
            }
            zos.setLevel(level);
            return true;
        } catch (Exception ex) {
        }
        return false;
    }

    /**
     * Add files to a zip file
     *
     * @param srcfiles An array of Files
     * @return boolean True if successful
     */
    public boolean addFilesToZip(File... srcfiles) {
        FileInputStream in;
        if (srcfiles == null || srcfiles.length == 0) {
            return false;
        }
        try {
            for (File f : srcfiles) {
                in = new FileInputStream(f);
                // name the file inside the zip  file
                zos.putNextEntry(new ZipEntry(f.getName()));
                byte[] b = new byte[2048];
                int count;
                while ((count = in.read(b)) > 0) {
                    zos.write(b, 0, count);
                }
                in.close();
            }
            return true;
        } catch (Exception ex) {
        }
        return false;
    }

    /**
     * Close existing zip stream
     */
    public void closeZipStream() {
        try {
            zos.close();
        } catch (IOException ex) {
        }
    }

    /**
     * Extracts a zip file to a supplied location
     *
     * @param srcpath The source zip file
     * @param destpath Destination for contents of zip file
     * @return true if succesful
     */
    public boolean extractZipTo(String srcpath, String destpath) {

        FileInputStream fis;
        final int BUFFER = 2048;
        try {
            fis = new FileInputStream(srcpath);
            try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(fis))) {
                ZipEntry entry;
                while ((entry = zin.getNextEntry()) != null) {
                    int count;
                    byte data[] = new byte[BUFFER];
                    FileOutputStream fos = new FileOutputStream(destpath + separator + entry.getName());
                    try (BufferedOutputStream dest = new BufferedOutputStream(fos, 2048)) {
                        while ((count = zin.read(data, 0, BUFFER)) != -1) {
                            dest.write(data, 0, count);
                        }
                        dest.flush();
                    }
                }
            }
            return true;
        } catch (Exception ex) {
        }
        return false;
    }

    /**
     * Creates a new folder
     *
     * @param path The location of the new folder
     * @return true if succesful
     */
    public boolean createFolder(String path) {
        path = path.replaceAll("[/]", separator);
        return (new File(path).mkdirs());
    }

    /**
     * Refreshes the file list at the default filepath location based on filter
     * contents
     */
    public void refreshFileList() {
        refreshFileList(getDefaultFilePath());
    }

    /**
     * Refreshes the file list at the specified directory location based on
     * filter contents
     *
     * @param directory
     */
    public void refreshFileList(String directory) {

        File ourFile = new File(directory);
        if (myFilter.isEmpty()) {
            fileList = ourFile.listFiles();
        } else {
            fileList = ourFile.listFiles(new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    return pathname.getPath().contains(myFilter);
                }
            });
        }
    }

    /**
     * Delete folder using specified folder path
     *
     * @param folder
     * @return boolean True if successful
     */
    public boolean deleteFolder(String folder) {
        return deleteFolder(new File(folder));
    }

    /**
     * Delete folder and its contents using specified file
     *
     * @param file
     * @return boolean True if successful
     */
    public boolean deleteFolder(File file) {
        if (file.isDirectory()) {
            for (String s : file.list()) {
                boolean success = deleteFolder(new File(file, s));
                if (!success) {
                    return false;
                }
            }
        }
        return file.delete();
    }

    /**
     * Returns a list of Files
     *
     * @return File array list
     */
    public File[] getFileList() {
        return fileList;
    }

    /**
     * Returns an array of filenames, array if populated from the offset value
     * onwards
     * @param offset
     * @return array of string filenames
     */
    public String[] getListOfFilenames(int offset) {

        String filename;
        String[] result = new String[fileList.length + offset];
        try {
            for (int i = 0; i < fileList.length; i++) {
                filename = fileList[i].getName();
                result[i + offset] = filename.substring(0, filename.indexOf('.'));
            }
            return result;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "getListOfFilenames(int offset)", ex);
            return null;
        }
    }

    /**
     * Set the default file path
     *
     * @param path The default path
     */
    public void setDefaultFilePath(String path) {
        defPath = path.replaceAll("[/]", separator);
    }

    /**
     * Gets the default file path
     *
     * @return Returns default file path
     */
    public String getDefaultFilePath() {
        return defPath;
    }

    /**
     * Test to see if file exists
     *
     * @param filename The file to check for
     * @return Returns true if file exists
     */
    public boolean exists(String filename) {
        if (!defPath.isEmpty()) {
            filename = defPath + separator + filename;
        }

        return new File(filename).exists();
    }

    /**
     * Deletes the current read file
     *
     * @return Returns true if successful
     */
    public boolean deleteReadFile() {
        return readFile.delete();
    }

    /**
     *
     * @param filename
     * @return Returns true if successful
     */
    public boolean renameReadFile(String filename) {
        return readFile.renameTo(new File(filename));
    }

    /**
     * Deletes the current write file
     *
     * @return Returns true if successful
     */
    public boolean deleteWriteFile() {
        return writeFile.delete();
    }

    /**
     *
     * @param filename
     * @return Returns true if successful
     */
    public boolean renameWriteFile(String filename) {
        return writeFile.renameTo(new File(filename));
    }

    public FileInputStream openFileInputStream() {

        try {
            finStream = new FileInputStream(readFile);
            return finStream;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "openFileInputStream()", ex);
            return null;
        }

    }

    /**
     * @return Returns an inputstream
     */
    public FileInputStream getFileInputStream() {
        return finStream;
    }

    /**
     * Closes the input stream
     *
     */
    public void closeFileInputStream() {
        try {
            if (finStream != null) {
                finStream.close();
                finStream = null;
            }

        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "closeFileInputStream()", ex);
        }

    }

    /**
     * Opens a file output stream
     *
     * @return Returns Opened file output stream
     */
    public FileOutputStream openFileOutputStream() {

        try {
            foutStream = new FileOutputStream(writeFile);
            return foutStream;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "openFileOutputStream()", ex);
            return null;
        }

    }

    /**
     * @return Returns current outputstream
     */
    public FileOutputStream getFileOutputStream() {
        return foutStream;
    }

    /**
     * Closes the output stream
     *
     */
    public void closeFileOutputStream() {
        try {
            if (foutStream != null) {
                foutStream.close();
                foutStream = null;
            }

        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "closeFileOutputStream()", ex);
        }

    }

    /**
     * Opens a buffered file for write
     *
     * @return Returns BufferedWriter if file is sucessfully opened
     */
    public BufferedWriter openBufferedWrite() {

        try {
            buffWriter = new BufferedWriter(new FileWriter(writeFile));
            return buffWriter;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "openBufferedWrite()", ex);
            return null;
        }

    }

    /**
     * Opens a buffered file for append
     *
     * @return Returns BufferedWriter if file is sucessfully opened
     */
    public BufferedWriter openBufferedAppend() {

        try {
            buffWriter = new BufferedWriter(new FileWriter(writeFile, true));
            return buffWriter;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "openBufferedAppend()", ex);
            return null;
        }

    }

    /**
     * Opens a buffered file for read
     *
     * @return Returns BufferedReader if file is sucessfully opened
     */
    public BufferedReader openBufferedRead() {

        try {
            buffReader = new BufferedReader(new FileReader(readFile));
            return buffReader;
        } catch (Exception ex) {
            return null;
        }

    }

    /**
     * Use this if you need access to a file within a jar
     *
     * @param is
     * @return Returns a buffered reader
     */
    public BufferedReader openBufferedRead(InputStream is) {

        try {
            buffReader = new BufferedReader(new InputStreamReader(is));
            return buffReader;
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "openBufferedRead(InputStream is)", ex);
            return null;
        }

    }

    /**
     * Closes the buffered write file
     *
     */
    public void closeBufferedWrite() {

        try {
            if (buffWriter != null) {
                buffWriter.flush();
                buffWriter.close();
                buffWriter = null;
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "closeBufferedWrite()", ex);
        }

    }

    /**
     * Closes the buffered read file
     *
     */
    public void closeBufferedRead() {

        try {
            if (buffReader != null) {
                buffReader.close();
                buffReader = null;
            }

        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "closeBufferedRead()", ex);
        }

    }

    /**
     * Read from previously opened input file
     *
     * @return Returns a single line from a file
     */
    public String readFromFile() {
        try {
            return buffReader.readLine();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "readFromFile()", ex);
            return null;
        }
    }

    /**
     * Read from previously opened input file
     *
     * @return Returns the entire contents from a file
     */
    public String readEntireFile() {
        return readEntireFile(1024);
    }

    /**
     * Read from previously opened input file
     *
     * @param buffsize Buffer size
     * @return Returns the entire contents from a file
     */
    public String readEntireFile(int buffsize) {

        char[] cb = new char[buffsize];
        StringBuilder sb = new StringBuilder();
        int bytes;
        try {
            while (buffReader.ready()) {
                bytes = buffReader.read(cb);
                sb.append(cb, 0, bytes);
            }
            return sb.toString();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "readEntireFile()", ex);
        }
        return null;
    }

    /**
     * Write to a previously opened output file
     *
     * @param data The data to be written
     * @param newlines The number of newlines to generate
     */
    public void writeToFile(String data, int newlines) {

        try {
            buffWriter.write(data);
            while (newlines > 0) {
                buffWriter.newLine();
                newlines--;
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "writeToFile(" + data + "," + String.valueOf(newlines) + ")", ex);
        }

    }

    /**
     * Copy a single file
     */
    public void copy() {
        FileReader frInput;
        FileWriter fwOutput;
        try {
            frInput = new FileReader(readFile);
            fwOutput = new FileWriter(writeFile);
            int intWord;
            while ((intWord = frInput.read()) != -1) {
                fwOutput.write(intWord);
            }
            frInput.close();
            fwOutput.close();
        } catch (Exception ex) {
            logger.log(Level.INFO, "copy() {0} {1}", new Object[]{ex.getMessage(), readFile.getAbsolutePath()});
        }
    }

    /**
     * Copy multiple files from one folder to another
     *
     * @param from
     * @param to
     */
    public void copyAll(String from, String to) {
        try {
            File ourFile = new File(from);
            for (File f : ourFile.listFiles()) {
                setReadFilename(f.getAbsolutePath());
                setWriteFilename(to + f.getName());
                copy();
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "copyAll()", ex);
        }
    }

    /**
     * Flushes the contents of the filebuffers to harddisk
     *
     */
    public void fileFlush() {
        try {
            buffWriter.flush();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "fileFlush()", ex);
        }

    }
}
