/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.io.InputStream;
import java.util.regex.Pattern;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class CSVToHashString {

    private final SimpleFileIO sfiCSV = new SimpleFileIO();

    public CSVToHashString() {
    }

    public void setDefaultFilePath(String path) {
        sfiCSV.setDefaultFilePath(path);
    }

    public HashString getHashStringFromFile(String filename) {
        HashString hsResult = null;
        Pattern patternRegex = Pattern.compile(",");
        String[] strPara;
        String strLine = "";
        String strTemp;

        if (!sfiCSV.exists(filename)) {
            return null;
        }
        sfiCSV.setReadFilename(filename);
        sfiCSV.openBufferedRead();
        while ((strTemp = sfiCSV.readFromFile()) != null) {
            strLine += strTemp;
        }
        if (strLine.isEmpty()) {
            return hsResult;
        }
        strPara = patternRegex.split(strLine);

        hsResult = new HashString((strPara.length / 2) + 1);
        for (int idx = 0; idx < strPara.length; idx += 2) {
            hsResult.putStringValue(strPara[idx], strPara[idx + 1]);
        }
        return hsResult;
    }

    public HashString getHashStringFromResource(String resource) {
        HashString hsResult = null;
        Pattern patternRegex = Pattern.compile(",");
        String[] strPara;
        String strLine = "";
        String strTemp;

        InputStream is = this.getClass().getResourceAsStream(resource);
        if (is == null) {
            return null;
        }
        sfiCSV.openBufferedRead(is);
        while ((strTemp = sfiCSV.readFromFile()) != null) {
            strLine += strTemp;
        }
        if (strLine.isEmpty()) {
            return hsResult;
        }
        strPara = patternRegex.split(strLine);

        hsResult = new HashString((strPara.length / 2) + 1);
        for (int idx = 0; idx < strPara.length; idx += 2) {
            hsResult.putStringValue(strPara[idx], strPara[idx + 1]);
        }
        return hsResult;
    }
}
