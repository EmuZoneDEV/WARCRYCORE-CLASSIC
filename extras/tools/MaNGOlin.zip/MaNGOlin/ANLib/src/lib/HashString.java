/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class HashString extends Hashtable<String, String> {

    private Hashtable<String, String> htLookup = null;
    private Enumeration en = null;
    private final ArrayList<String> listSequenced = new ArrayList<>();
    private ArrayList<String> listSort = null;
    private ArrayList<Long> listSortLong = null;
    private String strLongestValue = "";
    private int intValueLength = 0;

    public HashString() {
        super();
        htLookup = new Hashtable<>();
    }

    public HashString(int i, float l) {
        super(i, l);
        htLookup = new Hashtable<>(i, l);
    }

    public HashString(int i) {
        super(i);
        htLookup = new Hashtable<>(i);
    }

    /** Returns all keys
     *
     * @param sorted set true for sorted results
     * @return String array containing keys
     */
    public String[] getAllKeys(boolean sorted) {

        listSort = new ArrayList<>(htLookup.size());
        en = keys();
        while (en.hasMoreElements()) {
            listSort.add((String) en.nextElement());
        }
        if (sorted) {
            Collections.sort(listSort);
        }
        return (String[]) listSort.toArray(new String[listSort.size()]);
    }

    /** Returns all keys
     *
     * @param sorted set true for sorted results
     * @return Long array containing keys
     */
    public Long[] getAllNumericalKeys(boolean sorted) {

        listSortLong = new ArrayList<>(htLookup.size());
        en = keys();
        while (en.hasMoreElements()) {
            listSortLong.add(new Long((String) en.nextElement()));
        }
        if (sorted) {
            Collections.sort(listSortLong);
        }
        return (Long[]) listSortLong.toArray(new Long[listSortLong.size()]);
    }

    /** Returns all values
     *
     * @param sorted set true for sorted results
     * @return String array containing values
     */
    public String[] getAllValues(boolean sorted) {

        if (sorted) {
            listSort = new ArrayList<>(htLookup.size());
            en = htLookup.keys();
            while (en.hasMoreElements()) {
                listSort.add((String) en.nextElement());
            }
            Collections.sort(listSort);
            return (String[]) listSort.toArray(new String[listSort.size()]);
        } else {
            return (String[]) listSequenced.toArray(new String[listSequenced.size()]);
        }
    }

    /** Stores a Value against a given Key
     *
     * @param Key
     * @param Value
     */
    public void putStringValue(String Key, String Value) {
        int intValueLen;
        put(Key, Value);
        htLookup.put(Value, Key);
        listSequenced.add(Value);
        intValueLen = Value.length();
        if (intValueLen > intValueLength) {
            intValueLength = intValueLen;
            strLongestValue = Value;
        }
    }

    /**
     *
     * @return Returns the longest value
     */
    public String getLongestValue() {
        return strLongestValue;
    }

    /** Returns the key based on the Value
     *
     * @param Value
     * @return The key
     */
    public String getKey(String Value) {
        return htLookup.get(Value);
    }

    public String lookupToString() {
        return htLookup.toString();
    }
}
