/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Vector;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class DBFileTableModel extends FileTableModel {

    private final String[] colNames = {"Filename", "Client Version", "DB Version", "Last Modified"};
    private Vector<Object> cache = new Vector<>(0);
    private String[] record;
    private SimpleFileIO ourFileIO = null;

    /**
     * Creates a new instance of FileTableModel
     */
    public DBFileTableModel() {
        super();
    }

    /**
     * Returns the Object at a given row,col within the TableModel
     *
     * @param row The row index
     * @param col The column index
     * @return Returns the object value
     */
    @Override
    public Object getValueAt(int row, int col) {
        return ((String[]) (cache.get(row)))[col];
    }

    /**
     * Returns the column name as a String at column
     *
     * @param column The column index
     * @return Returns the column name
     */
    @Override
    public String getColumnName(int column) {
        if (getFileList() == null) {
            return null;
        }
        return colNames[column];
    }

    /**
     * Return the total number of columns stored within this TableModel
     *
     * @return Returns the column count
     */
    @Override
    public int getColumnCount() {
        if (getFileList() == null) {
            return 0;
        }
        return colNames.length;
    }

    /**
     * Refreshes the table
     */
    @Override
    public void refreshTable() {

        ourFileIO = new SimpleFileIO();
        File[] fileList = getFileList();
        cache = new Vector<>(0);
        String[] versionInfo;
        for (int i = 0; i < fileList.length; i++) {
            versionInfo = getVersionInfo(fileList[i]);
            record = new String[4];
            record[0] = fileList[i].getName();
            record[1] = versionInfo[0];
            record[2] = versionInfo[1];
            record[3] = getDateFormat().format(new Date(fileList[i].lastModified()));
            cache.add(record);
        }
        // Our table has changed so fire of a changed event
        fireTableChanged(null);
    }

    /**
     * Get the DB version from our SQL file
     *
     * @param ourFile The File
     * @return Returns the version info if found, else returns "Not Found"
     */
    private String[] getVersionInfo(File ourFile) {
        String[] result = new String[2];
        String temp;
        int start;
        try {
            ourFileIO.setReadFilename(ourFile.getCanonicalPath());
            ourFileIO.openBufferedRead();
            temp = ourFileIO.readFromFile();
            start = temp.indexOf("/* ClientVersion = ");
            if (start != -1) {
                temp = temp.substring(19, temp.length() - 2);
            } else {
                temp = "Not Found";
            }
            result[0] = temp;

            ourFileIO.readFromFile();

            temp = ourFileIO.readFromFile();
            start = temp.indexOf("/* DBVersion = ");
            if (start != -1) {
                temp = temp.substring(15, temp.length() - 2);
            } else {
                temp = "Not Found";
            }
            result[1] = temp;
            ourFileIO.closeBufferedRead();
            return result;
        } catch (IOException ex) {
            return null;
        }
    }
}
