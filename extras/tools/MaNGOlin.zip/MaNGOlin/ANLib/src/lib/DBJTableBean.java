/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.awt.FontMetrics;
import java.sql.ResultSet;
import javax.swing.event.TableModelEvent;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableRowSorter;

/**
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class DBJTableBean extends javax.swing.JTable {

    private DBTableModel dbTableModel = new DBTableModel();
    private Object tempObject;
    private TextBoxEditor defEditor;
    private TableCellRenderer defRender;
    private int minHeight;
    private TableRowSorter<DBTableModel> sorter;
    private boolean boolAutoColumn = false;
    private boolean boolRetainSelections = true;
    private int[] srows = {};

    /**
     * Creates class
     */
    public DBJTableBean() {
        initComponents();
        defEditor = new TextBoxEditor("");
        defRender = getDefaultRenderer(String.class);
        dbTableModel.addTableModelListener(new javax.swing.event.TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                if (e != null) {
                    return;
                }
                if (boolAutoColumn) {
                    autoAdjustColumnWidth();
                }
                if (boolRetainSelections) {
                    for (int i : srows) {
                        if (i > (getRowCount() - 1)) {
                            continue;
                        }
                        addRowSelectionInterval(i, i);
                    }
                }
            }
        });
        setModel(dbTableModel);
        sorter = new TableRowSorter<>(dbTableModel);
        setRowSorter(sorter);
    }

    /**
     * Returns this tables table model
     *
     * @return DBTableModel
     */
    @Override
    public DBTableModel getModel() {
        return dbTableModel;
    }

    /**
     * Returns the TableCellEditor for given row and col
     *
     * @return TableCellEditor
     */
    @Override
    public TableCellEditor getCellEditor(int row, int column) {

        if (dbTableModel == null) {
            return defEditor;
        }
        tempObject = dbTableModel.getCellEditorAt(column);
        // Get the default editor for specific classes
        if (tempObject == null || tempObject instanceof String) {
            return defEditor;
        }

        // Else return the specified editor stored in our db tablemodel
        return (TableCellEditor) tempObject;
    }

    /**
     * Returns the TableCellRenderer for given row and col
     *
     * @return TableCellRenderer
     */
    @Override
    public TableCellRenderer getCellRenderer(int row, int column) {

        if (dbTableModel == null) {
            return defRender;
        }
        tempObject = dbTableModel.getCellRendererAt(column);
        if (tempObject == null || tempObject instanceof String[] || tempObject instanceof HashString) {
            return defRender;
        }
        return (TableCellRenderer) tempObject;
    }

    /**
     * Set the minimum row height
     *
     * @param min
     */
    public void setMinRowHeight(int min) {
        minHeight = min;
        if (getRowHeight() < minHeight) {
            setRowHeight(minHeight);
        }
    }

    /**
     * Adjust the row height based on table font
     */
    public void autoAdjustRowHeight() {
        FontMetrics ourFontMetrics = getFontMetrics(getFont());
        if (minHeight > ourFontMetrics.getHeight()) {
            setRowHeight(minHeight);
        } else {
            setRowHeight(ourFontMetrics.getHeight() + (ourFontMetrics.getHeight() / 2));
        }
    }

    /**
     * Remember row selection after model update
     *
     * @param enabled
     */
    public void setSelectionRetention(boolean enabled) {
        boolRetainSelections = enabled;
    }

    /**
     * Adjust column widths based on font metrics
     */
    private void autoAdjustColumnWidth() {

        String strTemp;
        int intWidth;
        int intWidth2;
        FontMetrics fontMetricsTable = getFontMetrics(getFont());
        FontMetrics fontMetricsHeader = getFontMetrics(getTableHeader().getFont());
        for (int i = 0; i < getColumnCount(); i++) {
            intWidth = fontMetricsHeader.stringWidth(getColumnName(i) + "__");
            strTemp = dbTableModel.getLongestString(i);
            intWidth2 = fontMetricsTable.stringWidth(strTemp + "_");
            if (intWidth < intWidth2) {
                intWidth = intWidth2;
            }
            getColumn(getColumnName(i)).setMinWidth(intWidth);
            getColumn(getColumnName(i)).setPreferredWidth(intWidth);
            getColumn(getColumnName(i)).setMaxWidth(intWidth * 10);
        }

    }

    /**
     * This is an ease of use method, it accesses the dbtablemodel setResultSet
     * and provides selection retention
     *
     * @param rs
     */
    public void setResultSet(ResultSet rs) {
        srows = getSelectedRows();
        getModel().setResultSet(rs);
    }

    /**
     * Enables the combo editor on a specified column name with values taken
     * from a string array
     * @param name
     * @param render
     * @param values
     */
    public void enableComboEditor(String name, boolean render, String... values) {

        HashString hs = new HashString();
        for (int i = 0; i < values.length; i++) {
            hs.putStringValue(String.valueOf(i), values[i]);
        }
        enableComboEditor(name, render, hs);
    }

    /**
     * Enables the combo editor on a specified column name with values taken
     * from a HashString
     * @param name
     * @param render
     * @param hs
     */
    public void enableComboEditor(String name, boolean render, HashString hs) {

        int col = dbTableModel.findColumn(name);
        String[] values = hs.getAllValues(true);

        ComboBoxEditor myEditor = new ComboBoxEditor(values);
        myEditor.getComponent().setFont(this.getFont());
        dbTableModel.setComboEditorAt(myEditor, col);
        enableTextReplacement(name, hs);
        if (render) {
            ComboBoxRenderer myRender = new ComboBoxRenderer(values);
            //         myRender.setFont(this.getFont());
            dbTableModel.setRenderer(myRender, col);
        }
    }

    /**
     * Enable the text editor on a specified column name
     * @param name
     */
    public void enableTextEditor(String name) {
        int col = dbTableModel.findColumn(name);
        dbTableModel.setTextEditorAt(col);
        defEditor.setFont(this.getFont());
    }

    /**
     * Enable text rendering on a numeric field with given column name and
     * values taken from a string array
     *
     * @param name
     * @param values
     */
    public void enableNumericReplacement(String name, String... values) {

        HashString hs = new HashString();
        for (int i = 0; i < values.length; i++) {
            hs.putStringValue(String.valueOf(i), values[i]);
        }
        enableTextReplacement(name, hs);
    }

    /**
     * Enable text replacement on a given column name with values taken from a
     * HashString
     * @param name
     * @param hString
     */
    public void enableTextReplacement(String name, HashString hString) {
        if (hString == null) {
            return;
        }
        int col = dbTableModel.findColumn(name);
        dbTableModel.setAssociatedHash(col, hString);
    }

    /**
     * Set auto column adjust enabled/disabled
     *
     * @param enabled
     */
    public void setAutoColumnEnabled(boolean enabled) {
        boolAutoColumn = enabled;
    }

    /**
     * Check to see if auto column adjust is enabled
     *
     * @return boolean
     */
    public boolean isAutoColumnEnabled() {
        return boolAutoColumn;
    }

    /**
     * Returns the selected item at a specified column
     *
     * @param col
     * @return Object
     */
    public Object getSelectedItem(int col) {
        int row = getSelectedRow();
        return getValueAt(row, col);
    }

    /**
     * Returns the selected item at a specified column name
     *
     * @param colname
     * @return String
     */
    public String getSelectedItemAsString(String colname) {
        return getSelectedItem(colname).toString();
    }

    /**
     * Returns the selected item at a specified column name
     *
     * @param colname
     * @return Object
     */
    public Object getSelectedItem(String colname) {
        int row = getSelectedRow();
        int col;
        for (col = 0; col < getColumnCount(); col++) {
            if (getColumnName(col).compareTo(colname) == 0) {
                break;
            }
        }
        return getValueAt(row, col);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
